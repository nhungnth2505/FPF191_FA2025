# 📍 GPS Verification Test - Cần Thơ vs FPT University

## 🎯 Vấn Đề
Bạn ở Cần Thơ (10.014681, 105.733623) nhưng vẫn check-in thành công cho sự kiện ở FPT University TP.HCM (10.762622, 106.660172).

## 📊 Khoảng Cách
```
Cần Thơ: 10.014681, 105.733623
FPT University: 10.762622, 106.660172
Khoảng cách: 131.096km
Bán kính cho phép: 0.1km (100m)
Kết quả: SHOULD BE BLOCKED ❌
```

## 🔧 Đã Sửa

### **Vấn đề cũ:**
- **Manual Check-in form** không có GPS verification
- Chỉ **GPS Check-in form** mới có GPS verification
- User có thể bypass GPS bằng cách dùng Manual form

### **Giải pháp:**
- **Thêm GPS fields** vào Manual Check-in form
- **Auto-get GPS location** cho cả 2 forms
- **GPS verification** áp dụng cho tất cả check-in

## 🧪 Test Cases

### **Test Case 1: GPS Check-in từ Cần Thơ**

**Bước 1: Truy cập QR Check-in**
```
URL: http://localhost:3000/qr-checkin
```

**Bước 2: GPS Check-in Form**
- [ ] **GPS coordinates** tự động lấy: 10.014681, 105.733623
- [ ] **Address** hiển thị: "Phường An Bình, Thành phố Cần Thơ"

**Bước 3: Điền thông tin**
```
Event ID: d9c29291-5766-443f-aa7f-fcf6ca1412f6
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
```

**Bước 4: Submit GPS Check-in**
- [ ] Click **"GPS Check-in"** button
- [ ] **Expected**: "Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: 131.096km (cho phép: 0.1km)"
- [ ] **Check-in bị từ chối** ❌

---

### **Test Case 2: Manual Check-in từ Cần Thơ**

**Bước 1: Manual Check-in Form**
- [ ] **GPS coordinates** tự động lấy: 10.014681, 105.733623
- [ ] **Hidden fields** được set: latitude, longitude

**Bước 2: Điền thông tin**
```
Event ID: d9c29291-5766-443f-aa7f-fcf6ca1412f6
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
```

**Bước 3: Submit Manual Check-in**
- [ ] Click **"Check-in"** button
- [ ] **Expected**: "Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: 131.096km (cho phép: 0.1km)"
- [ ] **Check-in bị từ chối** ❌

---

### **Test Case 3: Check-in từ FPT University (Success)**

**Bước 1: Fake GPS Location**
- [ ] Mở **Developer Tools** (F12)
- [ ] Vào **Console** tab
- [ ] Chạy lệnh:
```javascript
// Fake GPS to FPT University
document.getElementById('gps-latitude').value = '10.762622';
document.getElementById('gps-longitude').value = '106.660172';
document.getElementById('manual-latitude').value = '10.762622';
document.getElementById('manual-longitude').value = '106.660172';
```

**Bước 2: Submit Check-in**
- [ ] Click **"Check-in"** button
- [ ] **Expected**: "GPS verification thành công! Khoảng cách: 0.000km"
- [ ] **Expected**: "Check-in thành công!"
- [ ] **Check-in thành công** ✅

---

## 📱 Real GPS Test

### **Test từ Cần Thơ (Real Location)**
1. **Mở website trên mobile**
2. **Vào QR Check-in page**
3. **Cho phép GPS access**
4. **Điền Event ID và User ID**
5. **Click "Check-in"**
6. **Kiểm tra**: Check-in bị từ chối với message về khoảng cách

### **Test từ FPT University (Real Location)**
1. **Đi đến FPT University**
2. **Mở website trên mobile**
3. **Vào QR Check-in page**
4. **Cho phép GPS access**
5. **Điền Event ID và User ID**
6. **Click "Check-in"**
7. **Kiểm tra**: Check-in thành công

---

## 🔧 Technical Details

### **GPS Verification Logic**
```python
# Backend verification
if latitude and longitude and event.latitude and event.longitude:
    user_lat = float(latitude)
    user_lon = float(longitude)
    event_lat = float(event.latitude)
    event_lon = float(event.longitude)
    
    # Check within 100m radius
    if not GPSLocation.is_within_radius(user_lat, user_lon, event_lat, event_lon, 0.1):
        distance = GPSLocation.calculate_distance(user_lat, user_lon, event_lat, event_lon)
        flash(f'Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: {distance:.3f}km (cho phép: 0.1km)', 'error')
        return redirect(url_for('qr_checkin'))
```

### **Frontend GPS Auto-Get**
```javascript
// Auto-get GPS for both forms
navigator.geolocation.getCurrentPosition(
    function(position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        
        // Set GPS for both forms
        document.getElementById('gps-latitude').value = lat;
        document.getElementById('gps-longitude').value = lng;
        document.getElementById('manual-latitude').value = lat;
        document.getElementById('manual-longitude').value = lng;
    }
);
```

---

## 🎯 Expected Results

### **From Cần Thơ (131km away)**
```
❌ Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: 131.096km (cho phép: 0.1km)
❌ Check-in bị từ chối
```

### **From FPT University (0km away)**
```
✅ GPS verification thành công! Khoảng cách: 0.000km
✅ Check-in thành công!
```

### **From 50m away (within radius)**
```
✅ GPS verification thành công! Khoảng cách: 0.050km
✅ Check-in thành công!
```

---

## 🚀 Quick Test Commands

### **Test Distance Calculation**
```bash
python -c "
from mobile_features import GPSLocation
distance = GPSLocation.calculate_distance(10.014681, 105.733623, 10.762622, 106.660172)
print(f'Distance: {distance:.3f}km')
print(f'Should be blocked: {distance > 0.1}')
"
```

### **Test GPS Verification**
```bash
python -c "
from mobile_features import GPSLocation
result = GPSLocation.is_within_radius(10.014681, 105.733623, 10.762622, 106.660172, 0.1)
print(f'Within radius: {result}')
"
```

---

**🎯 Mục tiêu: GPS verification hoạt động chính xác, chặn check-in từ xa!**









