# 📍 GPS Điểm Danh Test - Hướng Dẫn Thực Hành

## 🎯 Mục Đích
Test tính năng GPS điểm danh trong hệ thống quản lý sự kiện campus.

---

## 📋 Test Cases GPS Điểm Danh

### ✅ **Test 1: Setup GPS Location**

**Bước 1: Truy cập GPS Location**
```
URL: http://localhost:3000/gps-location
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
```

**Bước 2: Thiết lập vị trí GPS**
- [ ] Click "Lấy vị trí hiện tại" 
- [ ] Cho phép browser access location
- [ ] Hoặc click trên bản đồ để chọn vị trí
- [ ] Click "Lưu vị trí"

**Expected Result:**
- [ ] Vị trí GPS được lưu thành công
- [ ] Flash message hiển thị: "Đã cập nhật vị trí GPS"

---

### ✅ **Test 2: Tạo Sự Kiện với GPS**

**Bước 1: Tạo sự kiện**
```
URL: http://localhost:3000/create-event
```

**Bước 2: Điền thông tin sự kiện**
```
Tên sự kiện: "GPS Test Event"
Mô tả: "Test GPS điểm danh"
Ngày: 2024-12-01
Giờ: 10:00
Địa điểm: "FPT University"
Số lượng: 100
```

**Bước 3: Thêm GPS coordinates**
```
Latitude: 10.762622
Longitude: 106.660172
```

**Expected Result:**
- [ ] Sự kiện được tạo thành công
- [ ] GPS coordinates được lưu

---

### ✅ **Test 3: GPS Check-in Success**

**Bước 1: Setup vị trí user**
- [ ] User location: `10.762622, 106.660172` (FPT University)
- [ ] Event location: `10.762622, 106.660172` (Same location)
- [ ] Distance: 0km (within 100m radius)

**Bước 2: Thực hiện check-in**
```
URL: http://localhost:3000/qr-checkin
Event ID: [ID của sự kiện vừa tạo]
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
```

**Expected Result:**
- [ ] GPS verification: PASS
- [ ] Check-in thành công
- [ ] Message: "Check-in thành công!"

---

### ✅ **Test 4: GPS Check-in Failure**

**Bước 1: Setup vị trí user xa event**
- [ ] User location: `10.760622, 106.660172` (200m South)
- [ ] Event location: `10.762622, 106.660172` (FPT University)
- [ ] Distance: ~200m (outside 100m radius)

**Bước 2: Thực hiện check-in**
```
URL: http://localhost:3000/qr-checkin
Event ID: [ID của sự kiện]
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
```

**Expected Result:**
- [ ] GPS verification: FAIL
- [ ] Check-in bị từ chối
- [ ] Message: "Bạn phải ở vị trí sự kiện để check-in"

---

## 🧪 Test Data GPS

### **FPT University Coordinates**
```
Latitude: 10.762622
Longitude: 106.660172
Address: FPT University, D1 Street, Hi-Tech Park, Thu Duc City
```

### **Test Locations**

**✅ Within 100m (PASS)**
```
Location 1: 10.763122, 106.660172 (50m North)
Location 2: 10.762122, 106.660172 (50m South)  
Location 3: 10.762622, 106.660672 (50m East)
Location 4: 10.762622, 106.659672 (50m West)
```

**❌ Outside 100m (FAIL)**
```
Location 1: 10.760622, 106.660172 (200m South)
Location 2: 10.764622, 106.660172 (200m North)
Location 3: 10.762622, 106.662172 (200m East)
Location 4: 10.762622, 106.658172 (200m West)
```

---

## 📱 Mobile Test Scenarios

### **Scenario 1: Real GPS Test**
1. **Mở website trên mobile**
2. **Vào GPS Location page**
3. **Click "Lấy vị trí hiện tại"**
4. **Đi đến FPT University**
5. **Thực hiện check-in**

### **Scenario 2: Manual Location Test**
1. **Vào GPS Location page**
2. **Click trên bản đồ tại FPT University**
3. **Lưu vị trí**
4. **Thực hiện check-in**

---

## 🔧 Technical Test Points

### **GPS Accuracy Test**
```
Test Case: Distance calculation accuracy
Method: Compare calculated vs actual distance
Expected: Error < 5m for distances < 1km
```

### **Performance Test**
```
Test Case: GPS check-in response time
Method: Measure time from submit to response
Expected: < 2 seconds
```

### **Error Handling Test**
```
Test Case: GPS permission denied
Method: Deny browser location permission
Expected: Fallback to manual location selection
```

---

## 📊 Test Results Template

```
GPS Điểm Danh Test Results
Date: ___________
Tester: ___________
Browser: ___________
Device: ___________

Test 1 - GPS Setup: [ ] PASS [ ] FAIL
Test 2 - Create Event: [ ] PASS [ ] FAIL  
Test 3 - GPS Check-in Success: [ ] PASS [ ] FAIL
Test 4 - GPS Check-in Failure: [ ] PASS [ ] FAIL

Issues Found:
1. ________________
2. ________________
3. ________________

Overall Result: [ ] PASS [ ] FAIL
```

---

## 🚀 Quick Test Commands

### **Start Server**
```bash
cd D:\asspfp
python app.py
```

### **Test GPS Page**
```bash
# Test GPS location page loads
curl -I http://localhost:3000/gps-location
```

### **Test GPS API**
```bash
# Test distance calculation
python -c "
from mobile_features import GPSLocation
distance = GPSLocation.calculate_distance(10.762622, 106.660172, 10.763122, 106.660172)
print(f'Distance: {distance:.3f}km')
"
```

---

## 💡 Tips for Testing

### **Browser Settings**
- [ ] Enable location services
- [ ] Allow location access for localhost
- [ ] Use HTTPS if possible (better GPS support)

### **Mobile Testing**
- [ ] Test on actual mobile device
- [ ] Check GPS accuracy on mobile
- [ ] Test with different network conditions

### **Edge Cases**
- [ ] Test with GPS disabled
- [ ] Test with poor GPS signal
- [ ] Test with invalid coordinates
- [ ] Test with very large distances

---

**🎯 Mục tiêu: Đảm bảo GPS điểm danh hoạt động chính xác và đáng tin cậy!**









