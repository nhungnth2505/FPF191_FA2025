# TỔNG QUAN CÁC CLASS

## 📊 THỐNG KÊ
- **19 class** trong **5 file**
- **2 phiên bản**: Cơ bản + Nâng cao

---

## 🏗️ DANH SÁCH CLASS

| **Class** | **Mục đích** | **File** |
|-----------|--------------|----------|
| `User` | Người dùng cơ bản | ass.py |
| `Admin` | Quản trị viên | ass.py |
| `EventOrganizer` | Người tổ chức | ass.py |
| `Student` | Sinh viên | ass.py |
| `Visitor` | Khách tham quan | ass.py |
| `Event` | Sự kiện cơ bản | ass.py |
| `EventManager` | Quản lý hệ thống | ass.py |
| `EventManagementSystem` | Ứng dụng chính | ass.py |
| `EnhancedUser` | Người dùng nâng cao | enhanced_ass.py |
| `EnhancedAdmin` | Admin nâng cao | enhanced_ass.py |
| `EnhancedEventOrganizer` | Organizer nâng cao | enhanced_ass.py |
| `EnhancedStudent` | Sinh viên nâng cao | enhanced_ass.py |
| `EnhancedEvent` | Sự kiện với QR/GPS | enhanced_ass.py |
| `EnhancedEventManager` | Quản lý nâng cao | enhanced_ass.py |
| `EnhancedEventManagementSystem` | Ứng dụng nâng cao | enhanced_ass.py |
| `Colors` | Màu sắc terminal | enhanced_ui.py |
| `EnhancedUI` | Giao diện đẹp | enhanced_ui.py |
| `SimpleAIAssistant` | Trợ lý AI | ai_assistant.py |
| `EventCategory` | Phân loại sự kiện | quick_enhancements.py |

---

## 🎯 PHÂN LOẠI

### 👥 **User (8 class)**
- Quản lý người dùng với phân quyền

### 📅 **Event (3 class)**  
- Quản lý sự kiện và phân loại

### 🏢 **System (4 class)**
- Quản lý trung tâm và ứng dụng

### 🎨 **UI (2 class)**
- Giao diện người dùng

### 🤖 **AI (1 class)**
- Trợ lý thông minh

### 📂 **Category (1 class)**
- Phân loại sự kiện

---

## ⚡ TÍNH NĂNG

**Cơ bản**: Quản lý user, event, phân quyền  
**Nâng cao**: Mobile, QR, GPS, AI Assistant  
**UI**: Màu sắc, menu đẹp, thông báo  

---

## 🔄 KẾ THỪA

```
User → Admin/Organizer/Student/Visitor
EnhancedUser → EnhancedAdmin/Organizer/Student
```

**Kết luận**: 19 class hỗ trợ quản lý sự kiện từ cơ bản đến nâng cao với mobile, AI, GPS.



