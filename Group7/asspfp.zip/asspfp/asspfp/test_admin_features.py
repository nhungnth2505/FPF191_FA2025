#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script để kiểm tra tính năng Admin
"""

import requests
import json
from datetime import datetime, timedelta

# URL của ứng dụng
BASE_URL = "http://localhost:5000"

def test_admin_login():
    """Test đăng nhập với vai trò Admin"""
    print("🔐 Testing Admin Login...")
    
    # Tạo admin account trước
    create_admin_url = f"{BASE_URL}/create-admin"
    try:
        response = requests.get(create_admin_url)
        if response.status_code == 200:
            print("✅ Admin account created successfully")
            # Extract admin ID from response (simplified)
            admin_id = "admin_001"  # This would need to be extracted from response
            print(f"📋 Admin ID: {admin_id}")
            return admin_id
        else:
            print(f"❌ Failed to create admin: {response.status_code}")
            return None
    except Exception as e:
        print(f"❌ Error creating admin: {e}")
        return None

def test_login(admin_id):
    """Test đăng nhập"""
    print(f"\n🔑 Testing login with Admin ID: {admin_id}")
    
    login_url = f"{BASE_URL}/login"
    login_data = {
        'user_id': admin_id
    }
    
    try:
        response = requests.post(login_url, data=login_data)
        if response.status_code == 200:
            print("✅ Login successful")
            return True
        else:
            print(f"❌ Login failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Login error: {e}")
        return False

def test_dashboard_access():
    """Test truy cập dashboard"""
    print("\n📊 Testing Dashboard Access...")
    
    dashboard_url = f"{BASE_URL}/dashboard"
    
    try:
        response = requests.get(dashboard_url)
        if response.status_code == 200:
            print("✅ Dashboard access successful")
            return True
        else:
            print(f"❌ Dashboard access failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Dashboard access error: {e}")
        return False

def test_events_view():
    """Test xem danh sách sự kiện"""
    print("\n📅 Testing Events View...")
    
    events_url = f"{BASE_URL}/events"
    
    try:
        response = requests.get(events_url)
        if response.status_code == 200:
            print("✅ Events view successful")
            return True
        else:
            print(f"❌ Events view failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Events view error: {e}")
        return False

def test_create_event():
    """Test tạo sự kiện mới"""
    print("\n➕ Testing Create Event...")
    
    create_event_url = f"{BASE_URL}/events/create"
    
    # Test GET request (form)
    try:
        response = requests.get(create_event_url)
        if response.status_code == 200:
            print("✅ Create event form accessible")
        else:
            print(f"❌ Create event form failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Create event form error: {e}")
        return False
    
    # Test POST request (create event)
    event_data = {
        'name': 'Test Event Admin',
        'description': 'Test event created by admin',
        'date': (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d'),
        'time': '14:00',
        'location': 'Test Location',
        'max_capacity': 50,
        'category': 'tech'
    }
    
    try:
        response = requests.post(create_event_url, data=event_data)
        if response.status_code == 200:
            print("✅ Event creation successful")
            return True
        else:
            print(f"❌ Event creation failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Event creation error: {e}")
        return False

def test_edit_event():
    """Test sửa sự kiện"""
    print("\n✏️ Testing Edit Event...")
    
    # Giả sử có event với ID test_event_001
    event_id = "test_event_001"
    edit_form_url = f"{BASE_URL}/edit-event/{event_id}"
    
    try:
        response = requests.get(edit_form_url)
        if response.status_code == 200:
            print("✅ Edit event form accessible")
        else:
            print(f"❌ Edit event form failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Edit event form error: {e}")
        return False
    
    # Test POST request (update event)
    update_data = {
        'name': 'Updated Test Event',
        'description': 'Updated description',
        'date': (datetime.now() + timedelta(days=8)).strftime('%Y-%m-%d'),
        'time': '15:00',
        'location': 'Updated Location',
        'max_capacity': 60,
        'category': 'academic'
    }
    
    try:
        response = requests.post(edit_form_url, data=update_data)
        if response.status_code == 200:
            print("✅ Event update successful")
            return True
        else:
            print(f"❌ Event update failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Event update error: {e}")
        return False

def main():
    """Chạy tất cả tests"""
    print("🚀 Starting Admin Features Test")
    print("=" * 50)
    
    # Test 1: Tạo admin account
    admin_id = test_admin_login()
    if not admin_id:
        print("❌ Cannot proceed without admin account")
        return
    
    # Test 2: Đăng nhập
    if not test_login(admin_id):
        print("❌ Cannot proceed without login")
        return
    
    # Test 3: Truy cập dashboard
    test_dashboard_access()
    
    # Test 4: Xem sự kiện
    test_events_view()
    
    # Test 5: Tạo sự kiện
    test_create_event()
    
    # Test 6: Sửa sự kiện
    test_edit_event()
    
    print("\n" + "=" * 50)
    print("🎉 Admin Features Test Completed!")

if __name__ == "__main__":
    main()

