# GIẢI THÍCH CHI TIẾT TỪNG CLASS TRONG HỆ THỐNG QUẢN LÝ SỰ KIỆN

## 1. HỆ THỐNG CƠ BẢN (ass.py)

### 1.1 User (Abstract Base Class)
```python
class User(ABC):
    def __init__(self, user_id: str, name: str, email: str):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.role = self.__class__.__name__
    
    @abstractmethod
    def get_permissions(self) -> List[str]:
        pass
    
    def has_permission(self, permission: str) -> bool:
        return permission in self.get_permissions()
```

**Giải thích chi tiết:**
- **Mục đích**: Lớp cơ sở trừu tượng cho tất cả loại người dùng
- **Thiết kế**: Sử dụng Abstract Base Class (ABC) để đảm bảo tất cả subclass phải implement `get_permissions()`
- **Tính năng chính**:
  - Quản lý thông tin cơ bản: ID, tên, email
  - Hệ thống phân quyền động thông qua `has_permission()`
  - Tự động xác định role từ tên class
- **Lợi ích**: Đảm bảo tính nhất quán trong hệ thống phân quyền

### 1.2 Admin
```python
class Admin(User):
    def get_permissions(self) -> List[str]:
        return [
            "create_event", "update_event", "delete_event", "view_all_events",
            "view_all_attendees", "manage_users", "view_statistics", "export_data",
            "search_events", "register_for_events", "view_registered_events", "view_event_details"
        ]
```

**Giải thích chi tiết:**
- **Kế thừa**: User
- **Quyền hạn**: Toàn quyền hệ thống (12 permissions)
- **Tính năng**: Có thể tạo, sửa, xóa sự kiện; quản lý người dùng; xem thống kê; xuất dữ liệu
- **Use case**: Quản trị viên hệ thống, người có quyền cao nhất

### 1.3 EventOrganizer
```python
class EventOrganizer(User):
    def __init__(self, user_id: str, name: str, email: str):
        super().__init__(user_id, name, email)
        self.managed_events: List[str] = []
    
    def get_permissions(self) -> List[str]:
        return [
            "view_managed_events", "manage_attendees", "view_event_details",
            "register_attendees", "view_statistics"
        ]
    
    def add_managed_event(self, event_id: str):
        if event_id not in self.managed_events:
            self.managed_events.append(event_id)
```

**Giải thích chi tiết:**
- **Kế thừa**: User
- **Đặc điểm riêng**: Có danh sách `managed_events` để theo dõi sự kiện được giao
- **Quyền hạn**: Chỉ quản lý sự kiện được giao (5 permissions)
- **Tính năng**: Có thể thêm sự kiện vào danh sách quản lý
- **Use case**: Người tổ chức sự kiện, giảng viên

### 1.4 Student & Visitor
```python
class Student(User):
    def get_permissions(self) -> List[str]:
        return [
            "search_events", "register_for_events", "view_registered_events",
            "view_event_details"
        ]

class Visitor(User):
    def get_permissions(self) -> List[str]:
        return [
            "search_events", "register_for_events", "view_registered_events",
            "view_event_details"
        ]
```

**Giải thích chi tiết:**
- **Kế thừa**: User
- **Quyền hạn**: Cơ bản (4 permissions giống nhau)
- **Tính năng**: Tìm kiếm, đăng ký, xem sự kiện
- **Khác biệt**: Student và Visitor có quyền giống nhau, có thể phân biệt trong tương lai
- **Use case**: Sinh viên, khách tham quan

### 1.5 Event
```python
class Event:
    def __init__(self, event_id: str, name: str, description: str, date: str, 
                 time: str, location: str, max_capacity: int, organizer_id: str):
        self.event_id = event_id
        self.name = name
        self.description = description
        self.date = date
        self.time = time
        self.location = location
        self.max_capacity = max_capacity
        self.organizer_id = organizer_id
        self.attendees: List[str] = []
        self.created_at = datetime.now().isoformat()
    
    def add_attendee(self, user_id: str) -> bool:
        if len(self.attendees) < self.max_capacity and user_id not in self.attendees:
            self.attendees.append(user_id)
            return True
        return False
    
    def is_full(self) -> bool:
        return len(self.attendees) >= self.max_capacity
    
    def get_available_spots(self) -> int:
        return max(0, self.max_capacity - len(self.attendees))
```

**Giải thích chi tiết:**
- **Mục đích**: Đại diện cho một sự kiện trong hệ thống
- **Thuộc tính chính**:
  - Thông tin cơ bản: tên, mô tả, ngày, giờ, địa điểm
  - Quản lý sức chứa: `max_capacity`, `attendees`
  - Liên kết: `organizer_id` để biết ai tạo sự kiện
- **Tính năng**:
  - `add_attendee()`: Thêm người tham dự (kiểm tra capacity và duplicate)
  - `is_full()`: Kiểm tra sự kiện đã đầy chưa
  - `get_available_spots()`: Tính số chỗ còn trống
- **Business Logic**: Đảm bảo không vượt quá sức chứa và không trùng lặp người tham dự

### 1.6 EventManager
```python
class EventManager:
    def __init__(self):
        self.events: Dict[str, Event] = {}
        self.users: Dict[str, User] = {}
        self.current_user: Optional[User] = None
        self.data_file = "event_data.json"
        self.load_data()
    
    def register_user(self, user_type: str, name: str, email: str) -> str:
        user_id = str(uuid.uuid4())
        
        if user_type.lower() == 'admin':
            user = Admin(user_id, name, email)
        elif user_type.lower() == 'organizer':
            user = EventOrganizer(user_id, name, email)
        # ... other user types
        
        self.users[user_id] = user
        return user_id
```

**Giải thích chi tiết:**
- **Mục đích**: Quản lý trung tâm của toàn bộ hệ thống
- **Thuộc tính**:
  - `events`: Dictionary lưu trữ tất cả sự kiện
  - `users`: Dictionary lưu trữ tất cả người dùng
  - `current_user`: Người dùng hiện tại đang đăng nhập
  - `data_file`: File JSON để lưu trữ dữ liệu
- **Tính năng chính**:
  - **CRUD Operations**: Tạo, đọc, cập nhật, xóa sự kiện và người dùng
  - **Authentication**: Đăng ký, đăng nhập người dùng
  - **Data Persistence**: Lưu/tải dữ liệu từ JSON
  - **Permission Control**: Kiểm tra quyền trước khi thực hiện hành động
- **Design Pattern**: Repository Pattern - tập trung tất cả logic truy cập dữ liệu

### 1.7 EventManagementSystem
```python
class EventManagementSystem:
    def __init__(self):
        self.manager = EventManager()
        self.running = True
    
    def display_menu(self):
        if not self.manager.current_user:
            # Show guest menu
        else:
            # Show role-based menu
    
    def run(self):
        while self.running:
            self.display_menu()
            choice = input("Enter your choice: ")
            # Handle user choice
```

**Giải thích chi tiết:**
- **Mục đích**: Giao diện ứng dụng chính, điều khiển luồng chương trình
- **Thiết kế**: MVC Pattern - Controller layer
- **Tính năng**:
  - **Menu System**: Hiển thị menu khác nhau theo vai trò
  - **User Interaction**: Xử lý input từ người dùng
  - **Business Logic Delegation**: Ủy quyền logic cho EventManager
  - **Error Handling**: Xử lý lỗi và hiển thị thông báo
- **Lifecycle**: Vòng lặp chính của ứng dụng

---

## 2. HỆ THỐNG NÂNG CAO (enhanced_ass.py)

### 2.1 EnhancedUser (Abstract Base Class)
```python
class EnhancedUser(ABC):
    def __init__(self, user_id: str, name: str, email: str, phone: str = ""):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.phone = phone
        self.role = self.__class__.__name__
        self.qr_code = None
        self.gps_location = None
    
    def generate_user_qr(self):
        return None
    
    def set_location(self, latitude: float, longitude: float):
        if not MOBILE_ENABLED:
            return
        self.gps_location = {"lat": latitude, "lon": longitude}
```

**Giải thích chi tiết:**
- **Nâng cấp từ User**: Thêm phone, QR code, GPS location
- **Mobile Features**: Tích hợp QR code và GPS cho mobile app
- **Conditional Features**: Chỉ kích hoạt mobile features khi `MOBILE_ENABLED = True`
- **Tính năng mới**:
  - `generate_user_qr()`: Tạo QR code cho người dùng
  - `set_location()`: Thiết lập vị trí GPS
- **Use case**: Chuẩn bị cho ứng dụng mobile

### 2.2 EnhancedAdmin, EnhancedEventOrganizer, EnhancedStudent
```python
class EnhancedAdmin(EnhancedUser):
    def get_permissions(self) -> List[str]:
        return [
            "create_event", "update_event", "delete_event", "view_all_events",
            "view_all_attendees", "manage_users", "view_statistics", "export_data",
            "search_events", "register_for_events", "view_registered_events", 
            "view_event_details"
        ]
```

**Giải thích chi tiết:**
- **Kế thừa**: EnhancedUser (có mobile features)
- **Quyền hạn**: Giống như Admin cơ bản nhưng với khả năng mobile
- **Tính năng mới**: Có thể sử dụng QR code, GPS cho quản lý
- **Mobile Integration**: Hỗ trợ check-in qua QR, tìm sự kiện gần

### 2.3 EnhancedEvent
```python
class EnhancedEvent:
    def __init__(self, event_id: str, name: str, description: str, date: str, 
                 time: str, location: str, max_capacity: int, organizer_id: str,
                 latitude: float = None, longitude: float = None, category: str = "general"):
        # ... basic attributes
        self.latitude = latitude
        self.longitude = longitude
        self.category = category
        self.qr_code = None
    
    def generate_qr_code(self) -> str:
        qr_data = {
            "event_id": self.event_id,
            "event_name": self.name,
            "date": self.date,
            "time": self.time,
            "location": self.location,
            "type": "event_checkin"
        }
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(json.dumps(qr_data))
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        qr_filename = f"qr_event_{self.event_id}.png"
        img.save(qr_filename)
        
        self.qr_code = qr_filename
        return qr_filename
```

**Giải thích chi tiết:**
- **Nâng cấp từ Event**: Thêm GPS coordinates, category, QR code
- **Mobile Features**:
  - **GPS Integration**: `latitude`, `longitude` cho location-based services
  - **QR Code Generation**: Tự động tạo QR code cho check-in
  - **Category System**: Phân loại sự kiện (tech, academic, sports, etc.)
- **QR Code Logic**:
  - Tạo QR code chứa thông tin sự kiện
  - Lưu QR code thành file PNG
  - Sử dụng thư viện `qrcode` để tạo mã
- **Use case**: Hỗ trợ mobile check-in, tìm sự kiện gần

### 2.4 EnhancedEventManager
```python
class EnhancedEventManager:
    def __init__(self):
        self.events: Dict[str, EnhancedEvent] = {}
        self.users: Dict[str, EnhancedUser] = {}
        self.current_user: Optional[EnhancedUser] = None
        self.data_file = "enhanced_event_data.json"
        self.mobile_manager = MobileEventManager() if MOBILE_ENABLED else None
        self.check_in_system = MobileCheckIn() if MOBILE_ENABLED else None
        self.ui = EnhancedUI()
        self.load_data()
    
    def scan_qr_checkin(self, qr_data: str) -> bool:
        try:
            data = json.loads(qr_data)
            if data.get("type") != "event_checkin":
                return False
            
            event_id = data.get("event_id")
            if not event_id or event_id not in self.events:
                return False
            
            event = self.events[event_id]
            if self.current_user.user_id in event.attendees:
                return False  # Already checked in
            
            if len(event.attendees) >= event.max_capacity:
                return False  # Event is full
            
            event.attendees.append(self.current_user.user_id)
            return True
            
        except Exception as e:
            print(f"Error scanning QR code: {e}")
            return False
    
    def find_nearby_events(self, user_lat: float, user_lon: float, radius: float = 5.0):
        nearby_events = []
        for event in self.events.values():
            if event.latitude and event.longitude:
                distance = GPSLocation.calculate_distance(
                    user_lat, user_lon, event.latitude, event.longitude
                )
                if distance <= radius:
                    nearby_events.append({
                        'event': event,
                        'distance': round(distance, 2)
                    })
        
        nearby_events.sort(key=lambda x: x['distance'])
        return nearby_events
```

**Giải thích chi tiết:**
- **Nâng cấp từ EventManager**: Thêm mobile features và enhanced UI
- **Mobile Integration**:
  - `mobile_manager`: Quản lý tính năng mobile
  - `check_in_system`: Hệ thống check-in mobile
  - `ui`: Giao diện nâng cao với màu sắc
- **Tính năng mới**:
  - **QR Code Check-in**: `scan_qr_checkin()` - quét QR code để check-in
  - **Location-based Search**: `find_nearby_events()` - tìm sự kiện gần
  - **GPS Verification**: Xác thực vị trí khi check-in
- **Business Logic**:
  - Kiểm tra QR code hợp lệ
  - Xác thực người dùng chưa check-in
  - Kiểm tra sức chứa sự kiện
  - Tính toán khoảng cách GPS
- **Error Handling**: Xử lý lỗi khi scan QR, tính toán GPS

### 2.5 EnhancedEventManagementSystem
```python
class EnhancedEventManagementSystem:
    def __init__(self):
        self.manager = EnhancedEventManager()
        self.running = True
        self.ui = EnhancedUI()
    
    def display_enhanced_menu(self):
        if not self.manager.current_user:
            self.ui.display_main_menu()
            return
        
        user = self.manager.current_user
        self.ui.display_welcome_message(user.name, user.role)
        
        if isinstance(user, EnhancedAdmin):
            self.ui.display_admin_menu()
        elif isinstance(user, EnhancedEventOrganizer):
            self.ui.display_student_menu()
        else:  # Student
            self.ui.display_student_menu()
    
    def handle_qr_checkin(self):
        self.ui.display_info_message("📱 QR Code Check-in")
        print("Nhập dữ liệu QR code (JSON format):")
        print("Ví dụ: {\"event_id\":\"...\", \"type\":\"event_checkin\"}")
        
        qr_data = input("QR Data: ").strip()
        
        if not qr_data:
            self.ui.display_error_message("Vui lòng nhập dữ liệu QR code!")
            return
        
        try:
            success = self.manager.scan_qr_checkin(qr_data)
            if success:
                self.ui.display_success_message("✅ Check-in thành công!")
            else:
                self.ui.display_error_message("❌ Check-in thất bại!")
        except Exception as e:
            self.ui.display_error_message(f"Lỗi: {e}")
```

**Giải thích chi tiết:**
- **Nâng cấp từ EventManagementSystem**: Thêm enhanced UI và mobile features
- **Enhanced UI Integration**:
  - Sử dụng `EnhancedUI` cho giao diện đẹp
  - Menu động với màu sắc và emoji
  - Thông báo có màu sắc (success, error, warning, info)
- **Mobile Features**:
  - **QR Check-in**: Xử lý check-in qua QR code
  - **GPS Location**: Thiết lập và sử dụng vị trí GPS
  - **Nearby Events**: Tìm sự kiện gần
- **User Experience**:
  - Giao diện thân thiện với emoji và màu sắc
  - Hướng dẫn rõ ràng cho người dùng
  - Xử lý lỗi thông minh
- **Workflow Integration**: Tích hợp AI Assistant và mobile features

---

## 3. GIAO DIỆN NÂNG CAO (enhanced_ui.py)

### 3.1 Colors
```python
class Colors:
    """ANSI color codes for terminal"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'
```

**Giải thích chi tiết:**
- **Mục đích**: Quản lý màu sắc ANSI cho terminal
- **Thiết kế**: Static class với constants
- **Tính năng**: Cung cấp mã màu ANSI cho terminal
- **Use case**: Tạo giao diện đẹp mắt với màu sắc

### 3.2 EnhancedUI
```python
class EnhancedUI:
    @staticmethod
    def display_header():
        header = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════════╗{Colors.END}
{Colors.CYAN}║    {Colors.BOLD}{Colors.YELLOW}🎓 CAMPUS EVENT MANAGEMENT SYSTEM 🎓{Colors.END}{Colors.CYAN}                                    ║{Colors.END}
{Colors.CYAN}║    {Colors.GREEN}✨ Enhanced Version with Beautiful UI ✨{Colors.END}{Colors.CYAN}                                        ║{Colors.END}
{Colors.CYAN}╚══════════════════════════════════════════════════════════════════════════════╝{Colors.END}
        """
        print(header)
    
    @staticmethod
    def display_event(event, index=None):
        if event.is_full():
            status_color = Colors.RED
            status_icon = "🔴"
            status_text = "FULL"
        elif event.get_available_spots() <= 5:
            status_color = Colors.YELLOW
            status_icon = "🟡"
            status_text = "ALMOST FULL"
        else:
            status_color = Colors.GREEN
            status_icon = "🟢"
            status_text = "AVAILABLE"
        
        print(f"{Colors.CYAN}┌─ Event #{index} ─────────────────────────────────────────────────────────────┐{Colors.END}")
        print(f"{Colors.CYAN}│{Colors.END} {Colors.BOLD}📅 {event.name}{Colors.END}")
        print(f"{Colors.CYAN}│{Colors.END} 📝 {event.description}")
        print(f"{Colors.CYAN}│{Colors.END} 📅 Date: {event.date} at {event.time}")
        print(f"{Colors.CYAN}│{Colors.END} 📍 Location: {event.location}")
        print(f"{Colors.CYAN}│{Colors.END} 👥 Capacity: {event.get_attendance_count()}/{event.max_capacity}")
        print(f"{Colors.CYAN}│{Colors.END} {status_color}{status_icon} Status: {status_text}{Colors.END}")
        print(f"{Colors.CYAN}└─────────────────────────────────────────────────────────────────────────────┘{Colors.END}")
```

**Giải thích chi tiết:**
- **Mục đích**: Giao diện người dùng nâng cao với màu sắc và emoji
- **Thiết kế**: Static methods để dễ sử dụng
- **Tính năng chính**:
  - **Beautiful Headers**: Header đẹp với ASCII art và màu sắc
  - **Dynamic Menus**: Menu khác nhau theo vai trò người dùng
  - **Smart Event Display**: Hiển thị sự kiện với trạng thái màu sắc
  - **Status Indicators**: Icon và màu sắc cho trạng thái sự kiện
  - **Progress Bars**: Thanh tiến trình cho loading
  - **Color-coded Messages**: Thông báo có màu sắc (success, error, warning, info)
- **User Experience**:
  - Giao diện trực quan với emoji
  - Màu sắc giúp phân biệt trạng thái
  - ASCII art tạo cảm giác chuyên nghiệp
- **Responsive Design**: Tự động điều chỉnh theo nội dung

---

## 4. AI ASSISTANT (ai_assistant.py)

### 4.1 SimpleAIAssistant
```python
class SimpleAIAssistant:
    def __init__(self, get_all_events_callable):
        self.get_all_events = get_all_events_callable
    
    def answer(self, question: str) -> str:
        q = self._normalize(question)
        
        # Greetings
        if any(greeting in q for greeting in ["hello", "hi", "xin chao", "chao", "hey"]):
            return "Xin chào! Tôi là AI Assistant của hệ thống quản lý sự kiện..."
        
        # FAQs
        if "dang ky" in q or "register" in q:
            return "Vào Student menu → Register for Event, chọn sự kiện và xác nhận."
        
        # Recommendations
        if "gợi ý" in q or "suggest" in q or "recommend" in q:
            return self._recommend(keyword=kw)
        
        # Date filtering
        if any(x in q for x in ["hôm nay", "today", "tuần này", "this week"]):
            return self._filter_by_relative_date(q)
    
    def _normalize(self, text: str) -> str:
        if text is None:
            return ""
        t = str(text).strip().lower()
        t = t.replace('"', '').replace("'", "")
        # Strip Unicode diacritics
        t = unicodedata.normalize('NFD', t)
        t = ''.join(ch for ch in t if unicodedata.category(ch) != 'Mn')
        return t
```

**Giải thích chi tiết:**
- **Mục đích**: Trợ lý AI đơn giản không cần thư viện ngoài
- **Thiết kế**: Rule-based system với pattern matching
- **Tính năng chính**:
  - **Vietnamese Support**: Xử lý tiếng Việt có dấu
  - **FAQ System**: Trả lời câu hỏi thường gặp
  - **Event Recommendations**: Gợi ý sự kiện dựa trên từ khóa
  - **Date Filtering**: Tìm sự kiện theo ngày (hôm nay, tuần này, etc.)
  - **Keyword Search**: Tìm kiếm sự kiện theo từ khóa
- **Text Processing**:
  - `_normalize()`: Chuẩn hóa text, loại bỏ dấu tiếng Việt
  - Pattern matching: Nhận diện ý định người dùng
  - Context awareness: Hiểu ngữ cảnh câu hỏi
- **Integration**: Tích hợp với hệ thống thông qua callback function
- **Use case**: Hỗ trợ người dùng tìm kiếm và đăng ký sự kiện

---

## 5. PHÂN TÍCH KIẾN TRÚC TỔNG THỂ

### 5.1 Design Patterns Sử Dụng

#### Abstract Factory Pattern
```python
# User Factory
if user_type.lower() == 'admin':
    user = Admin(user_id, name, email)
elif user_type.lower() == 'organizer':
    user = EventOrganizer(user_id, name, email)
```

#### Repository Pattern
```python
class EventManager:
    def __init__(self):
        self.events: Dict[str, Event] = {}
        self.users: Dict[str, User] = {}
```

#### MVC Pattern
- **Model**: Event, User classes
- **View**: EnhancedUI class
- **Controller**: EventManagementSystem class

#### Strategy Pattern
```python
def display_enhanced_menu(self):
    if isinstance(user, EnhancedAdmin):
        self.ui.display_admin_menu()
    elif isinstance(user, EnhancedEventOrganizer):
        self.ui.display_student_menu()
    else:  # Student
        self.ui.display_student_menu()
```

### 5.2 SOLID Principles

#### Single Responsibility Principle (SRP)
- Mỗi class có một trách nhiệm duy nhất
- User: Quản lý thông tin người dùng
- Event: Quản lý thông tin sự kiện
- EventManager: Quản lý business logic

#### Open/Closed Principle (OCP)
- Mở rộng thông qua kế thừa
- Đóng với sửa đổi thông qua abstract classes

#### Liskov Substitution Principle (LSP)
- Subclass có thể thay thế base class
- EnhancedUser có thể thay thế User

#### Interface Segregation Principle (ISP)
- Abstract methods chỉ định nghĩa những gì cần thiết
- Không force implement methods không cần

#### Dependency Inversion Principle (DIP)
- Depend on abstractions, not concretions
- EventManager depends on User abstract class

### 5.3 Mobile Integration Strategy

#### Conditional Features
```python
MOBILE_ENABLED = False

if MOBILE_ENABLED:
    from mobile_features import MobileEventManager
else:
    # Lightweight stubs
    class MobileEventManager:
        pass
```

#### QR Code Integration
```python
def generate_qr_code(self) -> str:
    qr_data = {
        "event_id": self.event_id,
        "event_name": self.name,
        "type": "event_checkin"
    }
    # Generate QR code
```

#### GPS Location Services
```python
def find_nearby_events(self, user_lat: float, user_lon: float, radius: float = 5.0):
    for event in self.events.values():
        if event.latitude and event.longitude:
            distance = GPSLocation.calculate_distance(
                user_lat, user_lon, event.latitude, event.longitude
            )
```

---

## 6. KẾT LUẬN

Hệ thống được thiết kế theo kiến trúc hướng đối tượng chặt chẽ với:

1. **19 class** được tổ chức rõ ràng theo chức năng
2. **Kế thừa** hiệu quả từ abstract base classes
3. **Mobile integration** sẵn sàng cho ứng dụng di động
4. **AI Assistant** hỗ trợ người dùng thông minh
5. **Enhanced UI** tạo trải nghiệm người dùng tốt
6. **SOLID principles** đảm bảo code chất lượng cao
7. **Design patterns** giúp code dễ maintain và extend

Kiến trúc này cho phép hệ thống mở rộng dễ dàng và tích hợp các tính năng mới trong tương lai.

