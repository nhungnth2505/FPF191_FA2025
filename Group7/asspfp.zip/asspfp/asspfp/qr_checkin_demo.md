# 📱 QR Check-in System Demo Guide

## 🎯 **Tính năng mới đã thêm:**

### **1. Admin tạo sự kiện → Tự động tạo QR code**
- Khi admin/organizer tạo sự kiện, hệ thống tự động tạo QR code
- QR code chứa thông tin sự kiện (ID, tên, ngày, giờ, địa điểm)
- File QR code được lưu với tên: `qr_event_[event_id].png`

### **2. User quét QR code → Check-in**
- Student có thể quét QR code để check-in vào sự kiện
- Hệ thống kiểm tra: đã đăng ký chưa, sự kiện còn chỗ không
- Check-in thành công → Thêm vào danh sách attendees

---

## 🧪 **Cách test QR Check-in System:**

### **Bước 1: Tạo sự kiện với Admin**
```bash
python enhanced_ass.py
```
1. Chọn **2** (Login)
2. Đăng nhập Admin: `admin` / `admin123`
3. Chọn **1** (Create Event)
4. Điền thông tin sự kiện:
   - Name: `Python Workshop`
   - Description: `Learn Python programming`
   - Date: `2025-12-20`
   - Time: `14:00`
   - Location: `Room A101`
   - Max Capacity: `30`
   - Category: `tech`
5. **Kết quả**: Sẽ hiển thị "Event created successfully! QR code: qr_event_[id].png"

### **Bước 2: Đăng ký Student**
1. Chọn **6** (Logout)
2. Chọn **1** (Register New User)
3. Chọn **student**
4. Điền thông tin:
   - Name: `Test Student`
   - Email: `student@test.com`
   - Phone: `0123456789`
5. **Lưu lại Student ID** được hiển thị

### **Bước 3: Đăng nhập Student và test QR Check-in**
1. Chọn **2** (Login)
2. Nhập Student ID từ bước 2
3. Chọn **5** (📱 QR Check-in)
4. Nhập dữ liệu QR code (copy từ file QR đã tạo):

**Ví dụ QR data:**
```json
{"event_id":"9ad1c4cf-ad6f-4fa5-9799-c4d6d0471c93","event_name":"Python Workshop","date":"2025-12-20","time":"14:00","location":"Room A101","type":"event_checkin"}
```

5. **Kết quả**: "✅ Check-in thành công!"

### **Bước 4: Kiểm tra kết quả**
1. Chọn **3** (📋 View My Events)
2. Sẽ thấy sự kiện "Python Workshop" trong danh sách đã đăng ký

---

## 📋 **Test Cases:**

### **✅ Test thành công:**
- Tạo sự kiện → QR code được tạo
- Quét QR code hợp lệ → Check-in thành công
- Kiểm tra danh sách events → Hiển thị sự kiện đã check-in

### **❌ Test lỗi:**
- Quét QR code không hợp lệ → "Check-in thất bại"
- Check-in 2 lần → "Check-in thất bại" (đã check-in rồi)
- Sự kiện đã đầy → "Check-in thất bại" (sự kiện đã đầy)

---

## 🔧 **Troubleshooting:**

### **Nếu QR code không được tạo:**
- Kiểm tra thư viện qrcode đã cài đặt: `pip install qrcode[pil]`
- Kiểm tra quyền ghi file trong thư mục

### **Nếu check-in thất bại:**
- Kiểm tra format JSON của QR data
- Đảm bảo `type` = "event_checkin"
- Kiểm tra `event_id` có tồn tại không

### **Nếu không thấy menu QR Check-in:**
- Đảm bảo đang đăng nhập với role Student
- Menu option 5 sẽ hiển thị "📱 QR Check-in"

---

## 📁 **Files được tạo:**
- `qr_event_[event_id].png` - File QR code cho mỗi sự kiện
- `enhanced_event_data.json` - Dữ liệu sự kiện (bao gồm QR filename)

---

## 🎉 **Kết quả mong đợi:**
✅ Admin tạo sự kiện → QR code tự động tạo  
✅ Student quét QR → Check-in thành công  
✅ Hệ thống lưu trữ thông tin check-in  
✅ UI thân thiện với emoji và màu sắc  

**Chúc bạn test thành công! 🚀**
