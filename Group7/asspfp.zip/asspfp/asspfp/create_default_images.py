#!/usr/bin/env python3
"""
Script to create beautiful default event images for different categories
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_gradient_background(width, height, color1, color2):
    """Create a gradient background"""
    image = Image.new('RGB', (width, height))
    draw = ImageDraw.Draw(image)
    
    for y in range(height):
        # Calculate gradient ratio
        ratio = y / height
        r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
        g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
        b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
        draw.line([(0, y), (width, y)], fill=(r, g, b))
    
    return image

def create_tech_event_image():
    """Create tech event image"""
    width, height = 400, 200
    # Blue to purple gradient
    color1 = (102, 126, 234)  # #667eea
    color2 = (118, 75, 162)   # #764ba2
    
    img = create_gradient_background(width, height, color1, color2)
    draw = ImageDraw.Draw(img)
    
    # Draw laptop icon
    center_x, center_y = width // 2, height // 2 - 20
    
    # Laptop base
    laptop_width, laptop_height = 80, 50
    draw.rectangle([center_x - laptop_width//2, center_y - laptop_height//2, 
                   center_x + laptop_width//2, center_y + laptop_height//2], 
                   fill=(255, 255, 255, 200), outline=(255, 255, 255))
    
    # Screen
    screen_width, screen_height = 60, 40
    draw.rectangle([center_x - screen_width//2, center_y - screen_height//2, 
                   center_x + screen_width//2, center_y - 5], 
                   fill=(102, 126, 234))
    
    # Screen lines
    for i in range(3):
        y = center_y - 15 + i * 8
        draw.line([(center_x - 20, y), (center_x + 20, y)], fill=(255, 255, 255), width=2)
    
    # Dots below
    for i in range(3):
        x = center_x - 15 + i * 15
        draw.ellipse([x-3, center_y + 15, x+3, center_y + 21], fill=(255, 255, 255))
    
    # Title
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    
    text = "TECH EVENT"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_x = (width - text_width) // 2
    text_y = center_y + 40
    draw.text((text_x, text_y), text, fill=(255, 255, 255), font=font)
    
    return img

def create_sports_event_image():
    """Create sports event image"""
    width, height = 400, 200
    # Pink to red gradient
    color1 = (240, 147, 251)  # #f093fb
    color2 = (245, 87, 108)   # #f5576c
    
    img = create_gradient_background(width, height, color1, color2)
    draw = ImageDraw.Draw(img)
    
    center_x, center_y = width // 2, height // 2 - 20
    
    # Draw running figure
    # Head
    draw.ellipse([center_x - 8, center_y - 25, center_x + 8, center_y - 9], fill=(255, 255, 255))
    
    # Body
    draw.ellipse([center_x - 6, center_y - 8, center_x + 6, center_y + 8], fill=(255, 255, 255))
    
    # Arms and legs (running pose)
    draw.line([(center_x - 6, center_y - 5), (center_x - 15, center_y + 5)], fill=(255, 255, 255), width=3)
    draw.line([(center_x + 6, center_y - 5), (center_x + 15, center_y + 5)], fill=(255, 255, 255), width=3)
    draw.line([(center_x - 6, center_y + 8), (center_x - 12, center_y + 20)], fill=(255, 255, 255), width=3)
    draw.line([(center_x + 6, center_y + 8), (center_x + 12, center_y + 20)], fill=(255, 255, 255), width=3)
    
    # Title
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    
    text = "SPORTS EVENT"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_x = (width - text_width) // 2
    text_y = center_y + 40
    draw.text((text_x, text_y), text, fill=(255, 255, 255), font=font)
    
    return img

def create_academic_event_image():
    """Create academic event image"""
    width, height = 400, 200
    # Blue gradient
    color1 = (79, 172, 254)   # #4facfe
    color2 = (0, 242, 254)    # #00f2fe
    
    img = create_gradient_background(width, height, color1, color2)
    draw = ImageDraw.Draw(img)
    
    center_x, center_y = width // 2, height // 2 - 20
    
    # Draw graduation cap
    # Cap base
    draw.rectangle([center_x - 30, center_y - 20, center_x + 30, center_y - 5], fill=(255, 255, 255))
    
    # Cap top
    draw.polygon([(center_x - 25, center_y - 20), (center_x + 25, center_y - 20), 
                 (center_x + 20, center_y - 30), (center_x - 20, center_y - 30)], fill=(79, 172, 254))
    
    # Tassel
    draw.line([(center_x + 20, center_y - 30), (center_x + 25, center_y - 35)], fill=(255, 255, 255), width=2)
    draw.ellipse([(center_x + 23, center_y - 37), (center_x + 27, center_y - 33)], fill=(255, 255, 255))
    
    # Title
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    
    text = "ACADEMIC EVENT"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_x = (width - text_width) // 2
    text_y = center_y + 40
    draw.text((text_x, text_y), text, fill=(255, 255, 255), font=font)
    
    return img

def create_social_event_image():
    """Create social event image"""
    width, height = 400, 200
    # Green gradient
    color1 = (67, 233, 123)   # #43e97b
    color2 = (56, 249, 215)   # #38f9d7
    
    img = create_gradient_background(width, height, color1, color2)
    draw = ImageDraw.Draw(img)
    
    center_x, center_y = width // 2, height // 2 - 20
    
    # Draw people icons
    # Person 1
    draw.ellipse([center_x - 20, center_y - 15, center_x - 10, center_y - 5], fill=(255, 255, 255))
    draw.ellipse([center_x - 18, center_y - 8, center_x - 12, center_y - 2], fill=(255, 255, 255))
    
    # Person 2
    draw.ellipse([center_x - 5, center_y - 20, center_x + 5, center_y - 10], fill=(255, 255, 255))
    draw.ellipse([center_x - 3, center_y - 13, center_x + 3, center_y - 7], fill=(255, 255, 255))
    
    # Person 3
    draw.ellipse([center_x + 10, center_y - 15, center_x + 20, center_y - 5], fill=(255, 255, 255))
    draw.ellipse([center_x + 12, center_y - 8, center_x + 18, center_y - 2], fill=(255, 255, 255))
    
    # Title
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    
    text = "SOCIAL EVENT"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_x = (width - text_width) // 2
    text_y = center_y + 40
    draw.text((text_x, text_y), text, fill=(255, 255, 255), font=font)
    
    return img

def create_general_event_image():
    """Create general event image"""
    width, height = 400, 200
    # Blue to purple gradient
    color1 = (102, 126, 234)  # #667eea
    color2 = (118, 75, 162)   # #764ba2
    
    img = create_gradient_background(width, height, color1, color2)
    draw = ImageDraw.Draw(img)
    
    center_x, center_y = width // 2, height // 2 - 20
    
    # Draw calendar icon
    # Calendar base
    draw.rectangle([center_x - 25, center_y - 15, center_x + 25, center_y + 15], fill=(255, 255, 255))
    
    # Calendar header
    draw.rectangle([center_x - 25, center_y - 15, center_x + 25, center_y - 5], fill=(102, 126, 234))
    
    # Calendar rings
    draw.ellipse([(center_x - 20, center_y - 12), (center_x - 16, center_y - 8)], fill=(255, 255, 255))
    draw.ellipse([(center_x + 16, center_y - 12), (center_x + 20, center_y - 8)], fill=(255, 255, 255))
    
    # Calendar grid
    for i in range(3):
        for j in range(4):
            x = center_x - 15 + j * 8
            y = center_y - 2 + i * 5
            draw.ellipse([(x-1, y-1), (x+1, y+1)], fill=(102, 126, 234))
    
    # Title
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except:
        font = ImageFont.load_default()
    
    text = "EVENT"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_x = (width - text_width) // 2
    text_y = center_y + 40
    draw.text((text_x, text_y), text, fill=(255, 255, 255), font=font)
    
    return img

def main():
    """Create all default event images"""
    print("Creating default event images...")
    
    # Create images
    images = {
        'tech-event.png': create_tech_event_image(),
        'sports-event.png': create_sports_event_image(),
        'academic-event.png': create_academic_event_image(),
        'social-event.png': create_social_event_image(),
        'general-event.png': create_general_event_image()
    }
    
    # Save images
    for filename, img in images.items():
        img.save(filename)
        print(f"Created {filename}")
    
    print("All default event images created successfully!")

if __name__ == "__main__":
    main()









