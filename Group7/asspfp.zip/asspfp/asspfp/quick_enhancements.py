"""
Quick Enhancement Features for Campus Event Management System
Có thể implement ngay trong 30 phút
"""

# 1. Enhanced Event Display with Colors
def display_event_with_colors(event):
    """Display event with color coding"""
    status_colors = {
        'available': '\033[92m',  # Green
        'full': '\033[91m',       # Red  
        'almost_full': '\033[93m' # Yellow
    }
    
    if event.is_full():
        color = status_colors['full']
        status = "FULL"
    elif event.get_available_spots() <= 5:
        color = status_colors['almost_full']
        status = "ALMOST FULL"
    else:
        color = status_colors['available']
        status = "AVAILABLE"
    
    print(f"{color}📅 {event.name} - {event.date} at {event.time}")
    print(f"   📍 {event.location}")
    print(f"   👥 {event.get_attendance_count()}/{event.max_capacity} ({status})")
    print(f"   🎯 Available spots: {event.get_available_spots()}")
    print("\033[0m")  # Reset color

# 2. Enhanced Statistics with Emojis
def display_enhanced_statistics(stats):
    """Display statistics with visual enhancements"""
    print("\n" + "="*60)
    print("📊 SYSTEM STATISTICS DASHBOARD")
    print("="*60)
    print(f"📅 Total Events: {stats['total_events']}")
    print(f"👥 Total Attendees: {stats['total_attendees']}")
    print(f"📈 Average Attendance: {stats['average_attendance']}")
    
    if stats['highest_attendance']:
        print(f"🏆 Most Popular: {stats['highest_attendance']}")
    if stats['lowest_attendance']:
        print(f"📉 Least Popular: {stats['lowest_attendance']}")
    
    # Calculate additional metrics
    if stats['total_events'] > 0:
        utilization = (stats['total_attendees'] / (stats['total_events'] * 50)) * 100
        print(f"📊 Capacity Utilization: {utilization:.1f}%")
    
    print("="*60)

# 3. Event Categories
class EventCategory:
    def __init__(self, name, description, icon):
        self.name = name
        self.description = description
        self.icon = icon

# Pre-defined categories
EVENT_CATEGORIES = {
    'academic': EventCategory('Academic', 'Educational events', '🎓'),
    'sports': EventCategory('Sports', 'Physical activities', '⚽'),
    'social': EventCategory('Social', 'Social gatherings', '🎉'),
    'tech': EventCategory('Technology', 'Tech-related events', '💻'),
    'cultural': EventCategory('Cultural', 'Cultural events', '🎭'),
    'workshop': EventCategory('Workshop', 'Hands-on learning', '🔧')
}

# 4. Enhanced Event Creation with Categories
def create_event_with_category(name, description, date, time, location, capacity, category):
    """Create event with category information"""
    # Add category validation
    if category not in EVENT_CATEGORIES:
        raise ValueError(f"Invalid category. Available: {list(EVENT_CATEGORIES.keys())}")
    
    # Enhanced validation
    if not name or len(name) < 3:
        raise ValueError("Event name must be at least 3 characters")
    
    if capacity <= 0 or capacity > 1000:
        raise ValueError("Capacity must be between 1 and 1000")
    
    # Create event with category
    event_data = {
        'name': name,
        'description': description,
        'date': date,
        'time': time,
        'location': location,
        'capacity': capacity,
        'category': category,
        'icon': EVENT_CATEGORIES[category].icon
    }
    
    return event_data

# 5. Smart Search with Filters
def smart_search_events(query="", category="", date_range=None, capacity_min=None):
    """Enhanced search with multiple filters"""
    results = []
    
    # This would integrate with the main EventManager
    # For now, showing the enhanced search logic
    
    search_criteria = {
        'text': query.lower(),
        'category': category,
        'date_range': date_range,
        'min_capacity': capacity_min
    }
    
    return results

# 6. Event Popularity Ranking
def calculate_event_popularity(events):
    """Calculate popularity score for events"""
    popularity_scores = {}
    
    for event in events:
        # Calculate popularity based on multiple factors
        attendance_rate = event.get_attendance_count() / event.max_capacity
        days_until_event = calculate_days_until(event.date)
        
        # Popularity formula
        popularity = (attendance_rate * 0.7) + (1 / max(days_until_event, 1) * 0.3)
        popularity_scores[event.event_id] = popularity
    
    return popularity_scores

def calculate_days_until(event_date):
    """Calculate days until event"""
    from datetime import datetime
    try:
        event_dt = datetime.strptime(event_date, "%Y-%m-%d")
        today = datetime.now()
        return (event_dt - today).days
    except:
        return 999  # Far future if date parsing fails

# 7. Enhanced User Experience
def display_welcome_banner():
    """Display enhanced welcome banner"""
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║                                                              ║
    ║    🎓 CAMPUS EVENT MANAGEMENT SYSTEM 🎓                     ║
    ║                                                              ║
    ║    ✨ Enhanced Version with Advanced Features ✨            ║
    ║                                                              ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)

def display_menu_with_icons():
    """Display menu with icons"""
    menu = """
    🏠 MAIN MENU
    ┌─────────────────────────────────────┐
    │ 1️⃣  Register new user              │
    │ 2️⃣  Login                          │
    │ 3️⃣  View system info               │
    │ 4️⃣  Exit                          │
    └─────────────────────────────────────┘
    """
    print(menu)

# 8. Data Export Enhancements
def export_to_multiple_formats(data, formats=['csv', 'json', 'txt']):
    """Export data to multiple formats"""
    results = {}
    
    for format_type in formats:
        if format_type == 'csv':
            results['csv'] = export_to_csv(data)
        elif format_type == 'json':
            results['json'] = export_to_json(data)
        elif format_type == 'txt':
            results['txt'] = export_to_txt(data)
    
    return results

def export_to_txt(data):
    """Export to human-readable text format"""
    output = "CAMPUS EVENT MANAGEMENT SYSTEM REPORT\n"
    output += "=" * 50 + "\n\n"
    
    for event in data.get('events', []):
        output += f"Event: {event['name']}\n"
        output += f"Date: {event['date']} at {event['time']}\n"
        output += f"Location: {event['location']}\n"
        output += f"Capacity: {event['max_capacity']}\n"
        output += f"Attendees: {len(event.get('attendees', []))}\n"
        output += "-" * 30 + "\n"
    
    return output

# 9. Notification System
def send_notification(message, notification_type="info"):
    """Send notification with type"""
    icons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    }
    
    icon = icons.get(notification_type, 'ℹ️')
    print(f"{icon} {message}")

# 10. Enhanced Error Handling
def handle_error_with_suggestion(error, context=""):
    """Provide helpful error messages with suggestions"""
    error_suggestions = {
        'PermissionError': "💡 Try logging in with a different account or contact admin",
        'ValueError': "💡 Check your input format and try again",
        'KeyError': "💡 The requested item might not exist",
        'FileNotFoundError': "💡 The file might be missing or corrupted"
    }
    
    error_type = type(error).__name__
    suggestion = error_suggestions.get(error_type, "💡 Please try again or contact support")
    
    print(f"❌ Error: {error}")
    print(f"{suggestion}")
    if context:
        print(f"📍 Context: {context}")

# Example usage of enhancements
if __name__ == "__main__":
    print("🚀 Quick Enhancement Features Demo")
    print("These features can be integrated into the main system easily!")
    
    # Demo enhanced display
    display_welcome_banner()
    display_menu_with_icons()
    
    # Demo notifications
    send_notification("System started successfully!", "success")
    send_notification("New event created!", "info")
    send_notification("Warning: Low disk space", "warning")


















