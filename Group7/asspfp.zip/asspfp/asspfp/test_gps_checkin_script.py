#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import requests
import json

def test_gps_checkin():
    """Test GPS check-in from Can Tho location"""
    
    print("=== GPS Check-in Test ===")
    print("Testing check-in from Can Tho (10.014681, 105.733623)")
    print("To FPT University event (10.762622, 106.660172)")
    print("Expected: Should be BLOCKED (131km distance)")
    print()
    
    # Test data
    url = "http://localhost:3000/qr-checkin"
    
    # Can Tho coordinates
    can_tho_lat = "10.014681"
    can_tho_lon = "105.733623"
    
    # Event and user data
    event_id = "d9c29291-5766-443f-aa7f-fcf6ca1412f6"
    user_id = "39eb0cc1-d1c5-49ed-8efa-7e84d8b66254"
    
    # Test data
    data = {
        'event_id': event_id,
        'user_id': user_id,
        'latitude': can_tho_lat,
        'longitude': can_tho_lon
    }
    
    print(f"Event ID: {event_id}")
    print(f"User ID: {user_id}")
    print(f"GPS Location: {can_tho_lat}, {can_tho_lon}")
    print()
    
    try:
        # Send POST request
        response = requests.post(url, data=data)
        
        print(f"Response Status: {response.status_code}")
        print(f"Response URL: {response.url}")
        
        # Check if redirected (should be redirected back to qr-checkin)
        if response.status_code == 200:
            print("[SUCCESS] Request successful")
            
            # Check if redirected to login (no session)
            if "/login" in response.url:
                print("[INFO] Redirected to login - no session")
                print("[INFO] Need to login first to test GPS check-in")
            else:
                # Check response content for flash messages
                content = response.text
                if "Bạn phải ở vị trí sự kiện để check-in" in content:
                    print("[SUCCESS] GPS verification working - Check-in BLOCKED!")
                elif "Check-in thành công" in content:
                    print("[ERROR] GPS verification FAILED - Check-in allowed!")
                else:
                    print("[WARNING] Unknown response - check server logs")
                
        else:
            print(f"[ERROR] Request failed: {response.status_code}")
            
    except Exception as e:
        print(f"[ERROR] Error: {str(e)}")

if __name__ == "__main__":
    test_gps_checkin()
