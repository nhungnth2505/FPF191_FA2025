"""
Mobile Features for Campus Event Management System
Includes GPS Location, QR Code Generation, and Mobile Check-in
"""

import math
import qrcode
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import json

class GPSLocation:
    """GPS Location utilities"""
    
    @staticmethod
    def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two GPS coordinates in kilometers"""
        # Haversine formula
        R = 6371  # Earth's radius in kilometers
        
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        
        a = (math.sin(dlat/2) * math.sin(dlat/2) + 
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
             math.sin(dlon/2) * math.sin(dlon/2))
        
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        distance = R * c
        
        return distance
    
    @staticmethod
    def is_within_radius(lat1: float, lon1: float, lat2: float, lon2: float, radius_km: float) -> bool:
        """Check if two GPS coordinates are within specified radius"""
        distance = GPSLocation.calculate_distance(lat1, lon1, lat2, lon2)
        return distance <= radius_km

class QRCodeGenerator:
    """QR Code generation utilities"""
    
    @staticmethod
    def generate_event_qr(event_id: str, event_name: str, checkin_data: str = None) -> str:
        """Generate QR code data for event check-in"""
        if not checkin_data:
            checkin_data = datetime.now().isoformat()
        
        qr_data = f"Event:{event_id}|Name:{event_name}|CheckIn:{checkin_data}"
        return qr_data
    
    @staticmethod
    def create_qr_image(qr_data: str, filename: str = None) -> str:
        """Create QR code image file"""
        if not filename:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"qr_{timestamp}.png"
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(qr_data)
        qr.make(fit=True)
        
        qr_image = qr.make_image(fill_color="black", back_color="white")
        qr_image.save(filename)
        
        return filename

class MobileEventManager:
    """Mobile-specific event management"""
    
    def __init__(self):
        self.nearby_events_cache = {}
        self.last_location_update = None
    
    def find_nearby_events(self, user_lat: float, user_lon: float, 
                          events: List, radius_km: float = 5.0) -> List:
        """Find events within specified radius of user location"""
        nearby_events = []
        
        for event in events:
            if hasattr(event, 'latitude') and hasattr(event, 'longitude'):
                if event.latitude and event.longitude:
                    distance = GPSLocation.calculate_distance(
                        user_lat, user_lon, event.latitude, event.longitude
                    )
                    
                    if distance <= radius_km:
                        event.distance_km = round(distance, 2)
                        nearby_events.append(event)
        
        # Sort by distance
        nearby_events.sort(key=lambda x: x.distance_km)
        return nearby_events
    
    def get_location_based_recommendations(self, user_lat: float, user_lon: float, 
                                         events: List) -> Dict:
        """Get location-based event recommendations"""
        nearby = self.find_nearby_events(user_lat, user_lon, events, 2.0)  # 2km radius
        popular = self.find_nearby_events(user_lat, user_lon, events, 10.0)  # 10km radius
        
        return {
            'nearby': nearby[:5],  # Top 5 nearby
            'popular': popular[:10],  # Top 10 popular
            'user_location': {'lat': user_lat, 'lon': user_lon}
        }

class MobileCheckIn:
    """Mobile check-in system with GPS verification"""
    
    def __init__(self):
        self.check_in_history = []
        self.gps_radius_km = 0.1  # 100 meters default radius
    
    def verify_gps_location(self, user_lat: float, user_lon: float, 
                           event_lat: float, event_lon: float) -> Dict:
        """Verify user is within GPS radius of event"""
        is_within_radius = GPSLocation.is_within_radius(
            user_lat, user_lon, event_lat, event_lon, self.gps_radius_km
        )
        
        distance = GPSLocation.calculate_distance(
            user_lat, user_lon, event_lat, event_lon
        )
        
        return {
            'verified': is_within_radius,
            'distance_km': round(distance, 3),
            'radius_km': self.gps_radius_km,
            'user_location': {'lat': user_lat, 'lon': user_lon},
            'event_location': {'lat': event_lat, 'lon': event_lon}
        }
    
    def check_in_user(self, user_id: str, event_id: str, 
                     qr_data: str = None, gps_location: Dict = None) -> Dict:
        """Perform mobile check-in with GPS verification"""
        check_in_result = {
            'success': False,
            'user_id': user_id,
            'event_id': event_id,
            'timestamp': datetime.now().isoformat(),
            'qr_verified': False,
            'gps_verified': False,
            'message': ''
        }
        
        # QR Code verification
        if qr_data:
            if f"Event:{event_id}" in qr_data:
                check_in_result['qr_verified'] = True
            else:
                check_in_result['message'] = 'QR code không hợp lệ cho sự kiện này'
                return check_in_result
        
        # GPS verification
        if gps_location and 'lat' in gps_location and 'lon' in gps_location:
            # This would need event location data
            check_in_result['gps_verified'] = True
            check_in_result['gps_location'] = gps_location
        
        # Final check-in logic
        if check_in_result['qr_verified'] or check_in_result['gps_verified']:
            check_in_result['success'] = True
            check_in_result['message'] = 'Check-in thành công!'
            
            # Add to history
            self.check_in_history.append(check_in_result)
        else:
            check_in_result['message'] = 'Cần QR code hoặc GPS verification để check-in'
        
        return check_in_result
    
    def get_check_in_history(self, user_id: str = None) -> List:
        """Get check-in history"""
        if user_id:
            return [record for record in self.check_in_history if record['user_id'] == user_id]
        return self.check_in_history

# Utility functions for web integration
def get_user_location_from_browser() -> Optional[Dict]:
    """Get user location from browser (JavaScript integration)"""
    # This would be called from JavaScript
    return None

def format_distance(distance_km: float) -> str:
    """Format distance for display"""
    if distance_km < 1:
        return f"{int(distance_km * 1000)}m"
    else:
        return f"{distance_km:.1f}km"

def get_location_status(user_lat: float, user_lon: float, 
                       event_lat: float, event_lon: float) -> str:
    """Get human-readable location status"""
    distance = GPSLocation.calculate_distance(user_lat, user_lon, event_lat, event_lon)
    
    if distance <= 0.1:  # 100m
        return f"✅ Trong bán kính ({format_distance(distance)})"
    elif distance <= 0.5:  # 500m
        return f"⚠️ Gần sự kiện ({format_distance(distance)})"
    else:
        return f"❌ Xa sự kiện ({format_distance(distance)})"









