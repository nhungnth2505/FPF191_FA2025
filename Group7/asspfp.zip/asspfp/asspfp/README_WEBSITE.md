# 🌐 Campus Event Management System - Web Version

## 📋 Tổng quan
Website quản lý sự kiện campus chạy trên **localhost:3000** với đầy đủ tính năng:
- 🤖 **AI Assistant** - Trợ lý thông minh
- 📱 **Mobile Ready** - Tối ưu di động  
- 🔲 **QR Code** - Check-in tự động
- 📊 **Analytics** - Thống kê chi tiết
- 🎨 **Beautiful UI** - Giao diện đẹp mắt

---

## 🚀 Cách chạy website

### 1. Cài đặt nhanh (Tự động)
```bash
python run_website.py
```

### 2. Cài đặt thủ công
```bash
# Cài đặt dependencies
pip install -r requirements.txt

# Chạy website
python app.py
```

### 3. Truy cập website
- **URL**: http://localhost:3000
- **Port**: 3000
- **Host**: 0.0.0.0 (có thể truy cập từ máy khác)

---

## 📁 Cấu trúc thư mục

```
📦 Website Structure
├── 📄 app.py                 # Flask app chính
├── 📄 run_website.py         # Script chạy tự động
├── 📄 requirements.txt      # Dependencies
├── 📁 templates/             # HTML templates
│   ├── 📄 base.html         # Template cơ sở
│   ├── 📄 index.html        # Trang chủ
│   ├── 📄 login.html        # Đăng nhập
│   ├── 📄 register.html     # Đăng ký
│   ├── 📄 events.html       # Danh sách sự kiện
│   └── 📄 ai_assistant.html # AI Assistant
├── 📁 static/               # Static files
│   ├── 📁 css/
│   │   └── 📄 style.css     # Custom styles
│   └── 📁 js/
│       └── 📄 main.js       # JavaScript
└── 📁 enhanced_ass.py       # Core classes
```

---

## 🎯 Tính năng chính

### 👥 **User Management**
- **Admin**: Toàn quyền hệ thống
- **Organizer**: Tạo và quản lý sự kiện
- **Student**: Tham gia sự kiện
- **Phân quyền**: Role-based access control

### 📅 **Event Management**
- **Tạo sự kiện**: Với GPS, QR code
- **Tìm kiếm**: Theo tên, ngày, địa điểm
- **Đăng ký**: Tự động kiểm tra capacity
- **Check-in**: QR code verification

### 🤖 **AI Assistant**
- **Chat interface**: Giao diện chat đẹp
- **Smart search**: Tìm kiếm thông minh
- **Recommendations**: Gợi ý sự kiện
- **FAQ**: Trả lời câu hỏi thường gặp

### 📱 **Mobile Features**
- **Responsive**: Tối ưu mobile
- **QR Code**: Tự động tạo và scan
- **GPS**: Location-based search
- **Touch-friendly**: Giao diện cảm ứng

---

## 🛠️ API Endpoints

### **Main Routes**
- `GET /` - Trang chủ
- `GET /login` - Đăng nhập
- `POST /login` - Xử lý đăng nhập
- `GET /register` - Đăng ký
- `POST /register` - Xử lý đăng ký
- `GET /dashboard` - Trang chính
- `GET /events` - Danh sách sự kiện
- `GET /events/create` - Tạo sự kiện
- `POST /events/create` - Xử lý tạo sự kiện
- `GET /events/<id>` - Chi tiết sự kiện
- `POST /events/<id>/register` - Đăng ký sự kiện
- `GET /my-events` - Sự kiện đã đăng ký
- `GET /statistics` - Thống kê
- `GET /ai-assistant` - AI Assistant
- `POST /ai-assistant` - Chat với AI
- `GET /qr-checkin` - QR Check-in
- `POST /qr-checkin` - Xử lý check-in
- `GET /logout` - Đăng xuất

### **API Endpoints**
- `GET /api/events` - JSON danh sách sự kiện
- `POST /api/ai-chat` - Chat với AI (JSON)

---

## 🎨 Giao diện

### **Design Features**
- **Bootstrap 5**: Framework CSS hiện đại
- **Font Awesome**: Icons đẹp mắt
- **Gradient**: Màu sắc gradient
- **Responsive**: Tối ưu mọi thiết bị
- **Dark Mode**: Hỗ trợ chế độ tối
- **Animations**: Hiệu ứng mượt mà

### **Color Scheme**
- **Primary**: #0d6efd (Blue)
- **Success**: #198754 (Green)  
- **Warning**: #ffc107 (Yellow)
- **Danger**: #dc3545 (Red)
- **Info**: #0dcaf0 (Cyan)

---

## 🔧 Cấu hình

### **Environment Variables**
```bash
export FLASK_APP=app.py
export FLASK_ENV=development
export FLASK_DEBUG=True
```

### **Port Configuration**
```python
# Thay đổi port trong app.py
app.run(host='0.0.0.0', port=3000, debug=True)
```

---

## 🐛 Troubleshooting

### **Lỗi thường gặp**

1. **Port 3000 đã được sử dụng**
   ```bash
   # Tìm process sử dụng port 3000
   netstat -ano | findstr :3000
   
   # Kill process
   taskkill /PID <PID> /F
   ```

2. **ModuleNotFoundError**
   ```bash
   # Cài đặt lại dependencies
   pip install -r requirements.txt
   ```

3. **Template not found**
   ```bash
   # Kiểm tra cấu trúc thư mục
   ls -la templates/
   ```

4. **Database connection error**
   ```bash
   # Kiểm tra file enhanced_event_data.json
   ls -la *.json
   ```

---

## 📊 Performance

### **Optimization**
- **Static files**: CDN cho CSS/JS
- **Caching**: Browser caching
- **Compression**: Gzip compression
- **Database**: JSON file optimization

### **Monitoring**
- **Debug mode**: Flask debug toolbar
- **Logging**: Console logging
- **Error handling**: Graceful error handling

---

## 🔒 Security

### **Security Features**
- **Session management**: Flask sessions
- **CSRF protection**: Form tokens
- **Input validation**: Server-side validation
- **SQL injection**: Parameterized queries
- **XSS protection**: Template escaping

---

## 📈 Roadmap

### **Version 2.0**
- [ ] Database integration (PostgreSQL)
- [ ] Real-time notifications
- [ ] Advanced analytics
- [ ] Mobile app (React Native)
- [ ] API documentation (Swagger)

### **Version 3.0**
- [ ] Microservices architecture
- [ ] Docker containerization
- [ ] Kubernetes deployment
- [ ] CI/CD pipeline
- [ ] Monitoring & logging

---

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

---

## 📄 License

MIT License - Xem file LICENSE để biết thêm chi tiết.

---

## 👥 Support

- **Email**: support@campus-events.com
- **GitHub**: https://github.com/campus-events
- **Documentation**: https://docs.campus-events.com

---

**🎓 Campus Event Management System - Web Version**  
*Powered by Flask, AI, and Modern Web Technologies*



