# 📍 Test GPS Check-in - Hướng Dẫn Test

## 🎯 Mục Đích
Test GPS check-in functionality và xem flash messages.

---

## 🧪 Test Cases

### **Test Case 1: GPS Check-in Success**

**Bước 1: Truy cập QR Check-in**
```
URL: http://localhost:3000/qr-checkin
```

**Bước 2: GPS Check-in Form**
- [ ] **GPS Check-in section** hiển thị bên trái
- [ ] **"Đang kiểm tra vị trí..."** xuất hiện
- [ ] **GPS coordinates** được lấy tự động
- [ ] **GPS Check-in form** hiển thị

**Bước 3: Điền thông tin**
```
Event ID: d9c29291-5766-443f-aa7f-fcf6ca1412f6
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
GPS: 10.762622, 106.660172 (FPT University)
```

**Bước 4: Submit GPS Check-in**
- [ ] Click **"GPS Check-in"** button
- [ ] **Flash message** hiển thị: "GPS verification thành công! Khoảng cách: 0.000km"
- [ ] **Flash message** hiển thị: "Check-in thành công!"

---

### **Test Case 2: GPS Check-in Failure**

**Bước 1: Thay đổi GPS coordinates**
- [ ] Mở **Developer Tools** (F12)
- [ ] Vào **Console** tab
- [ ] Chạy lệnh:
```javascript
document.getElementById('gps-latitude').value = '10.760622';
document.getElementById('gps-longitude').value = '106.660172';
```

**Bước 2: Submit GPS Check-in**
- [ ] Click **"GPS Check-in"** button
- [ ] **Flash message** hiển thị: "Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: 0.200km (cho phép: 0.1km)"

---

### **Test Case 3: Manual Check-in**

**Bước 1: Manual Check-in Form**
- [ ] **Manual Check-in section** hiển thị bên phải
- [ ] **Event ID field** để nhập ID sự kiện
- [ ] **User ID field** để nhập ID người dùng

**Bước 2: Điền thông tin**
```
Event ID: d9c29291-5766-443f-aa7f-fcf6ca1412f6
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
```

**Bước 3: Submit Manual Check-in**
- [ ] Click **"Check-in"** button
- [ ] **Flash message** hiển thị: "Check-in thành công!"

---

## 📊 Expected Results

### **GPS Check-in Success**
```
✅ GPS verification thành công! Khoảng cách: 0.000km
✅ Check-in thành công!
```

### **GPS Check-in Failure**
```
❌ Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: 0.200km (cho phép: 0.1km)
```

### **Manual Check-in Success**
```
✅ Check-in thành công!
```

### **Error Cases**
```
❌ ID sự kiện không hợp lệ!
❌ ID người dùng không hợp lệ!
❌ Bạn đã check-in sự kiện này rồi!
❌ Sự kiện đã đầy!
```

---

## 🔧 Debug Information

### **Event IDs Available**
```
d9c29291-5766-443f-aa7f-fcf6ca1412f6 (JAVA_02L [Group21_Lainoma])
3f98c165-f7f0-4900-a780-c50dce11977f (GPS Test Event)
f3325419-cc2a-4a1e-af3a-3bfa7f5410b8 ([CT25_CPL_JAVA_02]_[Group2]_[cinema])
```

### **User IDs Available**
```
39eb0cc1-d1c5-49ed-8efa-7e84d8b66254 (Admin - caovanr)
d93deb36-55f7-4970-b374-8b7b312d4362 (Event Organizer)
```

### **GPS Coordinates**
```
FPT University: 10.762622, 106.660172
100m North: 10.763622, 106.660172
200m South: 10.760622, 106.660172
```

---

## 🚀 Quick Test Commands

### **Test GPS Check-in**
```bash
# Test QR check-in page
curl -I http://localhost:3000/qr-checkin

# Test GPS location page
curl -I http://localhost:3000/gps-location
```

### **Test GPS API**
```bash
# Test distance calculation
python -c "
from mobile_features import GPSLocation
distance = GPSLocation.calculate_distance(10.762622, 106.660172, 10.760622, 106.660172)
print(f'Distance: {distance:.3f}km')
"
```

---

## 📱 Mobile Test

### **Real GPS Test**
1. **Mở website trên mobile**
2. **Vào QR Check-in page**
3. **Click "Lấy vị trí hiện tại"**
4. **Cho phép GPS access**
5. **Điền Event ID và User ID**
6. **Click "GPS Check-in"**
7. **Kiểm tra flash messages**

---

## 🎯 Test Checklist

### **GPS Features**
- [ ] GPS coordinates hiển thị trong QR Code section
- [ ] GPS Check-in form hoạt động
- [ ] Current location button hoạt động
- [ ] GPS verification hoạt động
- [ ] Distance calculation chính xác
- [ ] Flash messages hiển thị đúng

### **Manual Check-in**
- [ ] Manual check-in form hoạt động
- [ ] Event ID validation
- [ ] User ID validation
- [ ] Check-in logic hoạt động
- [ ] Flash messages hiển thị đúng

### **Error Handling**
- [ ] GPS permission denied
- [ ] Invalid Event ID
- [ ] Invalid User ID
- [ ] Already checked in
- [ ] Event full

---

**🎯 Mục tiêu: GPS check-in hoạt động hoàn hảo với flash messages rõ ràng!**



