#!/usr/bin/env python3
"""
Campus Event Management System - Web Version
Chạy website trên localhost:3000

Hướng dẫn sử dụng:
1. Cài đặt dependencies: pip install -r requirements.txt
2. Chạy website: python run_website.py
3. Truy cập: http://localhost:3000
"""

import os
import sys
import subprocess
from pathlib import Path

def check_python_version():
    """Kiểm tra phiên bản Python"""
    if sys.version_info < (3, 7):
        print("❌ Cần Python 3.7 trở lên!")
        print(f"Phiên bản hiện tại: {sys.version}")
        return False
    print(f"✅ Python version: {sys.version}")
    return True

def install_requirements():
    """Cài đặt requirements"""
    print("📦 Đang cài đặt dependencies...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Cài đặt dependencies thành công!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Lỗi cài đặt dependencies: {e}")
        return False

def create_directories():
    """Tạo các thư mục cần thiết"""
    directories = [
        "templates",
        "static/css", 
        "static/js",
        "static/images",
        "uploads"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"📁 Tạo thư mục: {directory}")

def check_files():
    """Kiểm tra các file cần thiết"""
    required_files = [
        "app.py",
        "enhanced_ass.py", 
        "ai_assistant.py",
        "enhanced_ui.py",
        "templates/base.html",
        "templates/index.html",
        "static/css/style.css",
        "static/js/main.js"
    ]
    
    missing_files = []
    for file in required_files:
        if not Path(file).exists():
            missing_files.append(file)
    
    if missing_files:
        print("❌ Thiếu các file sau:")
        for file in missing_files:
            print(f"   - {file}")
        return False
    
    print("✅ Tất cả file cần thiết đã có!")
    return True

def run_website():
    """Chạy website"""
    print("\n🚀 Khởi động Campus Event Management System...")
    print("=" * 60)
    print("🎓 Hệ thống quản lý sự kiện campus với AI Assistant")
    print("📱 Truy cập: http://localhost:3000")
    print("🤖 Tính năng: AI Assistant, QR Code, Mobile Ready")
    print("=" * 60)
    print("\n💡 Hướng dẫn sử dụng:")
    print("1. Đăng ký tài khoản mới hoặc sử dụng tài khoản demo")
    print("2. Tạo sự kiện (Admin/Organizer)")
    print("3. Tìm kiếm và đăng ký sự kiện (Student)")
    print("4. Sử dụng AI Assistant để được hỗ trợ")
    print("5. Check-in bằng QR code")
    print("\n🛑 Nhấn Ctrl+C để dừng server")
    print("=" * 60)
    
    try:
        # Import và chạy Flask app
        from app import app
        app.run(host='0.0.0.0', port=3000, debug=True)
    except KeyboardInterrupt:
        print("\n\n👋 Đã dừng server. Tạm biệt!")
    except Exception as e:
        print(f"\n❌ Lỗi khởi động server: {e}")
        print("💡 Hãy kiểm tra lại các file và dependencies")

def main():
    """Hàm chính"""
    print("🎓 Campus Event Management System - Web Version")
    print("=" * 50)
    
    # Kiểm tra Python version
    if not check_python_version():
        return
    
    # Tạo thư mục
    create_directories()
    
    # Kiểm tra file
    if not check_files():
        print("\n❌ Vui lòng đảm bảo tất cả file cần thiết đã có!")
        return
    
    # Cài đặt requirements
    if not install_requirements():
        print("\n❌ Không thể cài đặt dependencies!")
        return
    
    # Chạy website
    run_website()

if __name__ == "__main__":
    main()



