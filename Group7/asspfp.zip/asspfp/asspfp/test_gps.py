#!/usr/bin/env python3
"""
GPS Test Script for Campus Event Management System
Tests GPS location features, distance calculation, and check-in verification
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from mobile_features import GPSLocation, MobileCheckIn, MobileEventManager
from enhanced_ass import EnhancedEventManager, EnhancedEvent, EnhancedStudent
import json

def print_header(title):
    """Print formatted header"""
    print(f"\n{'='*60}")
    print(f"[TEST] {title}")
    print(f"{'='*60}")

def print_test(test_name, result, details=""):
    """Print test result"""
    status = "[PASS]" if result else "[FAIL]"
    print(f"{status} {test_name}")
    if details:
        print(f"    -> {details}")

def test_gps_distance_calculation():
    """Test GPS distance calculation accuracy"""
    print_header("GPS Distance Calculation Tests")
    
    # Test Case 1: Same location (0km)
    distance1 = GPSLocation.calculate_distance(10.762622, 106.660172, 10.762622, 106.660172)
    print_test("Same location distance", abs(distance1) < 0.001, f"Distance: {distance1:.6f}km")
    
    # Test Case 2: 100m North (should be ~0.1km)
    distance2 = GPSLocation.calculate_distance(10.762622, 106.660172, 10.763622, 106.660172)
    print_test("100m North distance", 0.10 < distance2 < 0.12, f"Distance: {distance2:.3f}km")
    
    # Test Case 3: 200m South (should be ~0.2km)
    distance3 = GPSLocation.calculate_distance(10.762622, 106.660172, 10.761622, 106.660172)
    print_test("200m South distance", 0.20 < distance3 < 0.23, f"Distance: {distance3:.3f}km")
    
    # Test Case 4: 150m East (should be ~0.15km)
    distance4 = GPSLocation.calculate_distance(10.762622, 106.660172, 10.762622, 106.661172)
    print_test("150m East distance", 0.10 < distance4 < 0.12, f"Distance: {distance4:.3f}km")

def test_gps_radius_verification():
    """Test GPS radius verification"""
    print_header("GPS Radius Verification Tests")
    
    # Test Case 1: Within 100m radius (should PASS) - use smaller distance
    within_radius = GPSLocation.is_within_radius(10.762622, 106.660172, 10.763122, 106.660172, 0.1)
    print_test("Within 100m radius", within_radius, "Should PASS - within radius")
    
    # Test Case 2: Outside 100m radius (should FAIL)
    outside_radius = GPSLocation.is_within_radius(10.762622, 106.660172, 10.761622, 106.660172, 0.1)
    print_test("Outside 100m radius", not outside_radius, "Should FAIL - outside radius")
    
    # Test Case 3: Exactly at radius boundary
    boundary_radius = GPSLocation.is_within_radius(10.762622, 106.660172, 10.763122, 106.660172, 0.1)
    print_test("At radius boundary", boundary_radius, "Should PASS - at boundary")

def test_mobile_checkin():
    """Test mobile check-in with GPS verification"""
    print_header("Mobile Check-in Tests")
    
    mobile_checkin = MobileCheckIn()
    
    # Test Case 1: GPS verification success
    gps_result = mobile_checkin.verify_gps_location(
        user_lat=10.762622, user_lon=106.660172,  # User at FPT University
        event_lat=10.763122, event_lon=106.660172  # Event 50m North
    )
    print_test("GPS verification success", gps_result['verified'], 
               f"Distance: {gps_result['distance_km']:.3f}km")
    
    # Test Case 2: GPS verification failure
    gps_result_fail = mobile_checkin.verify_gps_location(
        user_lat=10.762622, user_lon=106.660172,  # User at FPT University
        event_lat=10.760622, event_lon=106.660172  # Event 200m South
    )
    print_test("GPS verification failure", not gps_result_fail['verified'], 
               f"Distance: {gps_result_fail['distance_km']:.3f}km")
    
    # Test Case 3: Check-in with GPS
    checkin_result = mobile_checkin.check_in_user(
        user_id="test_user_123",
        event_id="test_event_456",
        gps_location={"lat": 10.762622, "lon": 106.660172}
    )
    print_test("Check-in with GPS", checkin_result['gps_verified'], 
               f"Success: {checkin_result['success']}")

def test_mobile_event_manager():
    """Test mobile event manager features"""
    print_header("Mobile Event Manager Tests")
    
    mobile_manager = MobileEventManager()
    
    # Create test events
    events = [
        type('Event', (), {
            'event_id': 'event1',
            'name': 'Event at FPT University',
            'latitude': 10.762622,
            'longitude': 106.660172
        })(),
        type('Event', (), {
            'event_id': 'event2', 
            'name': 'Event 1km North',
            'latitude': 10.772622,
            'longitude': 106.660172
        })(),
        type('Event', (), {
            'event_id': 'event3',
            'name': 'Event 5km South', 
            'latitude': 10.712622,
            'longitude': 106.660172
        })()
    ]
    
    # Test Case 1: Find nearby events (2km radius)
    nearby_events = mobile_manager.find_nearby_events(10.762622, 106.660172, events, 2.0)
    print_test("Find nearby events (2km)", len(nearby_events) == 2, 
               f"Found {len(nearby_events)} events")
    
    # Test Case 2: Find popular events (10km radius)
    popular_events = mobile_manager.find_nearby_events(10.762622, 106.660172, events, 10.0)
    print_test("Find popular events (10km)", len(popular_events) == 3, 
               f"Found {len(popular_events)} events")
    
    # Test Case 3: Location-based recommendations
    recommendations = mobile_manager.get_location_based_recommendations(10.762622, 106.660172, events)
    print_test("Location-based recommendations", 
               len(recommendations['nearby']) > 0 and len(recommendations['popular']) > 0,
               f"Nearby: {len(recommendations['nearby'])}, Popular: {len(recommendations['popular'])}")

def test_gps_integration():
    """Test GPS integration with event management system"""
    print_header("GPS Integration Tests")
    
    # Initialize event manager
    event_manager = EnhancedEventManager()
    
    # Create test user
    test_user = EnhancedStudent("test_user_gps", "GPS Test User", "gps@test.com", "0123456789")
    test_user.set_location(10.762622, 106.660172)  # FPT University
    
    # Test Case 1: User location setting
    has_location = hasattr(test_user, 'gps_location') and test_user.gps_location is not None
    print_test("User location setting", has_location, 
               f"Location: {test_user.gps_location}")
    
    # Test Case 2: Create event with GPS (need to login as admin first)
    event_manager.login("39eb0cc1-d1c5-49ed-8efa-7e84d8b66254")  # Login as admin
    event_id = event_manager.create_event(
        name="GPS Test Event",
        description="Test event for GPS functionality",
        date="2024-12-01",
        time="10:00",
        location="FPT University",
        max_capacity=100,
        latitude=10.763622,  # 100m North of user
        longitude=106.660172,
        category="test"
    )
    print_test("Create event with GPS", event_id is not None, f"Event ID: {event_id}")
    
    # Test Case 3: Find events near user
    if event_id and event_id in event_manager.events:
        event = event_manager.events[event_id]
        # Use mobile manager to find nearby events
        mobile_manager = MobileEventManager()
        nearby_events = mobile_manager.find_nearby_events(10.762622, 106.660172, list(event_manager.events.values()), 2.0)
        print_test("Find events near user", len(nearby_events) > 0, 
                   f"Found {len(nearby_events)} nearby events")

def test_gps_error_handling():
    """Test GPS error handling"""
    print_header("GPS Error Handling Tests")
    
    # Test Case 1: Invalid coordinates
    try:
        distance = GPSLocation.calculate_distance(999, 999, 10.762622, 106.660172)
        print_test("Invalid coordinates handling", False, "Should raise error")
    except Exception as e:
        print_test("Invalid coordinates handling", True, f"Error caught: {type(e).__name__}")
    
    # Test Case 2: None coordinates
    try:
        distance = GPSLocation.calculate_distance(None, None, 10.762622, 106.660172)
        print_test("None coordinates handling", False, "Should raise error")
    except Exception as e:
        print_test("None coordinates handling", True, f"Error caught: {type(e).__name__}")
    
    # Test Case 3: Zero radius
    within_zero_radius = GPSLocation.is_within_radius(10.762622, 106.660172, 10.763622, 106.660172, 0)
    print_test("Zero radius handling", not within_zero_radius, "Should fail with zero radius")

def run_performance_tests():
    """Run GPS performance tests"""
    print_header("GPS Performance Tests")
    
    import time
    
    # Test Case 1: Distance calculation performance
    start_time = time.time()
    for i in range(1000):
        GPSLocation.calculate_distance(10.762622, 106.660172, 10.763622, 106.660172)
    end_time = time.time()
    calculation_time = (end_time - start_time) * 1000  # Convert to ms
    print_test("Distance calculation performance", calculation_time < 100, 
               f"1000 calculations in {calculation_time:.2f}ms")
    
    # Test Case 2: Radius verification performance
    start_time = time.time()
    for i in range(1000):
        GPSLocation.is_within_radius(10.762622, 106.660172, 10.763622, 106.660172, 0.1)
    end_time = time.time()
    verification_time = (end_time - start_time) * 1000  # Convert to ms
    print_test("Radius verification performance", verification_time < 50, 
               f"1000 verifications in {verification_time:.2f}ms")

def main():
    """Run all GPS tests"""
    print("[START] GPS Test Suite for Campus Event Management System")
    print("=" * 80)
    
    try:
        # Run all test suites
        test_gps_distance_calculation()
        test_gps_radius_verification()
        test_mobile_checkin()
        test_mobile_event_manager()
        test_gps_integration()
        test_gps_error_handling()
        run_performance_tests()
        
        print_header("Test Summary")
        print("[SUCCESS] All GPS tests completed!")
        print("[INFO] Check individual test results above")
        print("[INFO] For web testing, visit: http://localhost:3000/gps-location")
        
    except Exception as e:
        print(f"[ERROR] Test suite failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
