# 📍 GPS Demo Test - Hướng Dẫn Test GPS Check-in

## 🎯 Mục Đích
Demo và test tính năng GPS check-in trong hệ thống quản lý sự kiện campus.

---

## 🚀 Quick Demo GPS Check-in

### **Bước 1: Truy cập QR Check-in Page**
```
URL: http://localhost:3000/qr-checkin
```

### **Bước 2: GPS Check-in Section**
- [ ] **GPS Check-in card** hiển thị ở bên trái
- [ ] **"Đang kiểm tra vị trí..."** xuất hiện
- [ ] **"Lấy vị trí hiện tại"** button hoạt động
- [ ] **GPS coordinates** hiển thị sau khi lấy vị trí
- [ ] **Address** hiển thị từ reverse geocoding

### **Bước 3: Test GPS Check-in**

**Test Case 1: GPS Check-in Success (Same Location)**
```
Event ID: d9c29291-5766-443f-aa7f-fcf6ca1412f6
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
GPS: 10.762622, 106.660172 (FPT University)
Expected: GPS verification PASS, Check-in SUCCESS
```

**Test Case 2: GPS Check-in Failure (Different Location)**
```
Event ID: d9c29291-5766-443f-aa7f-fcf6ca1412f6
User ID: 39eb0cc1-d1c5-49ed-8efa-7e84d8b66254
GPS: 10.760622, 106.660172 (200m South)
Expected: GPS verification FAIL, Check-in DENIED
```

---

## 📱 GPS Features Demo

### **1. GPS Location Display**
- [ ] **GPS coordinates** hiển thị trong QR Code section
- [ ] **Format**: `GPS: 10.762622, 106.660172`
- [ ] **Icon**: Map marker icon

### **2. GPS Check-in Form**
- [ ] **Event ID field** để nhập ID sự kiện
- [ ] **User ID field** để nhập ID người dùng
- [ ] **Hidden GPS fields** (latitude, longitude)
- [ ] **GPS Check-in button** để submit

### **3. GPS Verification**
- [ ] **Distance calculation** chính xác
- [ ] **100m radius check** hoạt động
- [ ] **Success message** khi trong radius
- [ ] **Error message** khi ngoài radius

---

## 🧪 Test Scenarios

### **Scenario 1: Real GPS Test**
1. **Mở QR Check-in page**
2. **Click "Lấy vị trí hiện tại"**
3. **Cho phép browser access location**
4. **Nhập Event ID và User ID**
5. **Click "GPS Check-in"**
6. **Kiểm tra kết quả**

### **Scenario 2: Manual GPS Test**
1. **Mở QR Check-in page**
2. **Click "Lấy vị trí hiện tại"**
3. **Nhập Event ID và User ID**
4. **Thay đổi GPS coordinates trong form (F12)**
5. **Click "GPS Check-in"**
6. **Kiểm tra GPS verification**

### **Scenario 3: GPS Permission Test**
1. **Mở QR Check-in page**
2. **Deny GPS permission**
3. **Kiểm tra error message**
4. **Allow GPS permission**
5. **Kiểm tra GPS hoạt động**

---

## 📊 Expected Results

### **GPS Check-in Success**
```
Message: "GPS verification thành công! Khoảng cách: 0.000km"
Message: "Check-in thành công!"
Status: SUCCESS
```

### **GPS Check-in Failure**
```
Message: "Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: 0.200km (cho phép: 0.1km)"
Status: FAILED
```

### **GPS Permission Denied**
```
Message: "Bạn đã từ chối quyền truy cập vị trí."
Status: ERROR
```

---

## 🔧 Technical Details

### **GPS Coordinates**
```
FPT University: 10.762622, 106.660172
100m North: 10.763622, 106.660172
200m South: 10.760622, 106.660172
```

### **Distance Calculation**
```
Haversine formula: Accurate distance between GPS coordinates
Radius check: 100m (0.1km) tolerance
Performance: < 3ms for calculation
```

### **Browser Compatibility**
```
Chrome: ✅ Full GPS support
Firefox: ✅ Full GPS support
Safari: ✅ Full GPS support
Edge: ✅ Full GPS support
```

---

## 🎯 Demo Checklist

### **GPS Location Features**
- [ ] GPS coordinates hiển thị trong event details
- [ ] GPS coordinates hiển thị trong QR check-in
- [ ] GPS location picker hoạt động
- [ ] Current location button hoạt động
- [ ] Reverse geocoding hiển thị address

### **GPS Check-in Features**
- [ ] GPS verification hoạt động
- [ ] Distance calculation chính xác
- [ ] Radius check (100m) hoạt động
- [ ] Success/Error messages hiển thị đúng
- [ ] Check-in logic hoạt động với GPS

### **Error Handling**
- [ ] GPS permission denied handling
- [ ] Invalid coordinates handling
- [ ] Network error handling
- [ ] Browser compatibility

---

## 🚀 Quick Commands

### **Test GPS Page**
```bash
# Test GPS location page
curl -I http://localhost:3000/gps-location

# Test QR check-in page
curl -I http://localhost:3000/qr-checkin
```

### **Test GPS API**
```bash
# Test distance calculation
python -c "
from mobile_features import GPSLocation
distance = GPSLocation.calculate_distance(10.762622, 106.660172, 10.763622, 106.660172)
print(f'Distance: {distance:.3f}km')
"
```

---

**🎯 Mục tiêu: Demo GPS check-in hoạt động hoàn hảo với verification chính xác!**









