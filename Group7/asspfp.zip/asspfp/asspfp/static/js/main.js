// Campus Event Management System - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Loading states for buttons
    const submitButtons = document.querySelectorAll('button[type="submit"]');
    submitButtons.forEach(button => {
        button.addEventListener('click', function() {
            const originalText = this.innerHTML;
            this.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Đang xử lý...';
            this.disabled = true;
            
            // Re-enable after 3 seconds (fallback)
            setTimeout(() => {
                this.innerHTML = originalText;
                this.disabled = false;
            }, 3000);
        });
    });

    // Dynamic stats loading
    loadStats();
    
    // Real-time updates
    setInterval(loadStats, 30000); // Update every 30 seconds
});

// Load system statistics
function loadStats() {
    fetch('/api/events')
        .then(response => response.json())
        .then(data => {
            updateStats(data);
        })
        .catch(error => {
            console.log('Error loading stats:', error);
        });
}

// Update statistics display
function updateStats(events) {
    const totalEvents = events.length;
    const totalAttendees = events.reduce((sum, event) => {
        return sum + parseInt(event.capacity.split('/')[0]);
    }, 0);
    
    // Update stats if elements exist
    const eventCount = document.querySelector('.stat-item:nth-child(1) h4');
    const attendeeCount = document.querySelector('.stat-item:nth-child(2) h4');
    
    if (eventCount) eventCount.textContent = totalEvents;
    if (attendeeCount) attendeeCount.textContent = totalAttendees;
}

// AI Chat functionality
function initAIChat() {
    const chatContainer = document.getElementById('chat-container');
    const chatForm = document.getElementById('chat-form');
    const questionInput = document.getElementById('question');
    
    if (!chatContainer || !chatForm || !questionInput) return;
    
    // Quick question buttons
    const quickButtons = document.querySelectorAll('.quick-question');
    quickButtons.forEach(button => {
        button.addEventListener('click', function() {
            const question = this.getAttribute('data-question');
            questionInput.value = question;
            chatForm.submit();
        });
    });
    
    // Form submission with AJAX
    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const question = questionInput.value.trim();
        
        if (question) {
            addUserMessage(question);
            sendToAI(question);
            questionInput.value = '';
        }
    });
}

// Add user message to chat
function addUserMessage(message) {
    const chatContainer = document.getElementById('chat-container');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message user-message mb-3';
    messageDiv.innerHTML = `
        <div class="d-flex align-items-start justify-content-end">
            <div class="flex-grow-1 text-end">
                <div class="bg-primary text-white p-3 rounded">
                    <strong>Bạn:</strong> ${message}
                </div>
            </div>
            <div class="bg-secondary text-white rounded-circle p-2 ms-3">
                <i class="fas fa-user"></i>
            </div>
        </div>
    `;
    chatContainer.appendChild(messageDiv);
    scrollToBottom();
}

// Send question to AI
function sendToAI(question) {
    fetch('/api/ai-chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question: question })
    })
    .then(response => response.json())
    .then(data => {
        addBotMessage(data.response);
    })
    .catch(error => {
        addBotMessage('Xin lỗi, có lỗi xảy ra khi kết nối với AI Assistant.');
    });
}

// Add bot message to chat
function addBotMessage(message) {
    const chatContainer = document.getElementById('chat-container');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message bot-message mb-3';
    messageDiv.innerHTML = `
        <div class="d-flex align-items-start">
            <div class="bg-primary text-white rounded-circle p-2 me-3">
                <i class="fas fa-robot"></i>
            </div>
            <div class="flex-grow-1">
                <div class="bg-light p-3 rounded">
                    <strong>AI Assistant:</strong> ${message.replace(/\n/g, '<br>')}
                </div>
            </div>
        </div>
    `;
    chatContainer.appendChild(messageDiv);
    scrollToBottom();
}

// Scroll chat to bottom
function scrollToBottom() {
    const chatContainer = document.getElementById('chat-container');
    if (chatContainer) {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
}

// Event registration with confirmation
function registerForEvent(eventId) {
    if (confirm('Bạn có chắc chắn muốn đăng ký tham gia sự kiện này?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/events/${eventId}/register`;
        
        const submitButton = document.createElement('button');
        submitButton.type = 'submit';
        submitButton.style.display = 'none';
        
        form.appendChild(submitButton);
        document.body.appendChild(form);
        form.submit();
    }
}

// QR Code generation
function generateQRCode(eventId) {
    const button = document.querySelector(`[data-event-id="${eventId}"]`);
    if (button) {
        const originalText = button.innerHTML;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Đang tạo...';
        button.disabled = true;
        
        // The actual QR generation is handled by the server
        window.location.href = `/generate-qr/${eventId}`;
    }
}

// Search functionality
function initSearch() {
    const searchInput = document.getElementById('search');
    const dateInput = document.getElementById('date');
    
    if (searchInput) {
        searchInput.addEventListener('input', debounce(function() {
            performSearch();
        }, 300));
    }
    
    if (dateInput) {
        dateInput.addEventListener('change', function() {
            performSearch();
        });
    }
}

// Perform search
function performSearch() {
    const searchQuery = document.getElementById('search')?.value || '';
    const dateFilter = document.getElementById('date')?.value || '';
    
    const url = new URL(window.location);
    url.searchParams.set('search', searchQuery);
    url.searchParams.set('date', dateFilter);
    
    window.location.href = url.toString();
}

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize search on page load
document.addEventListener('DOMContentLoaded', function() {
    initSearch();
    initAIChat();
});

// Export functions for global use
window.registerForEvent = registerForEvent;
window.generateQRCode = generateQRCode;

