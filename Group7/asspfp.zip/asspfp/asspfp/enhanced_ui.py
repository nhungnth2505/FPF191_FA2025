"""
Enhanced UI for Campus Event Management System
Giao diện đẹp hơn với màu sắc, emoji và ASCII art
"""

import os
import sys
from datetime import datetime

class Colors:
    """ANSI color codes for terminal"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

class EnhancedUI:
    """Enhanced User Interface with colors and styling"""
    
    @staticmethod
    def clear_screen():
        """Clear the terminal screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    @staticmethod
    def display_header():
        """Display beautiful header"""
        header = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════════╗{Colors.END}
{Colors.CYAN}║                                                                              ║{Colors.END}
{Colors.CYAN}║    {Colors.BOLD}{Colors.YELLOW}🎓 CAMPUS EVENT MANAGEMENT SYSTEM 🎓{Colors.END}{Colors.CYAN}                                    ║{Colors.END}
{Colors.CYAN}║                                                                              ║{Colors.END}
{Colors.CYAN}║    {Colors.GREEN}✨ Enhanced Version with Beautiful UI ✨{Colors.END}{Colors.CYAN}                                        ║{Colors.END}
{Colors.CYAN}║                                                                              ║{Colors.END}
{Colors.CYAN}║    {Colors.MAGENTA}🎨 Beautiful Interface • 🚀 Core Features{Colors.END}{Colors.CYAN}                          ║{Colors.END}
{Colors.CYAN}║                                                                              ║{Colors.END}
{Colors.CYAN}╚══════════════════════════════════════════════════════════════════════════════╝{Colors.END}
        """
        print(header)
    
    @staticmethod
    def display_welcome_message(user_name="", role=""):
        """Display personalized welcome message"""
        if user_name and role:
            welcome = f"""
{Colors.GREEN}🎉 Welcome back, {Colors.BOLD}{user_name}{Colors.END}{Colors.GREEN}!{Colors.END}
{Colors.BLUE}👤 Role: {Colors.BOLD}{role}{Colors.END}
{Colors.CYAN}⏰ Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Colors.END}
            """
        else:
            welcome = f"""
{Colors.GREEN}🎉 Welcome to Campus Event Management System!{Colors.END}
{Colors.CYAN}⏰ Current time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Colors.END}
            """
        print(welcome)
    
    @staticmethod
    def display_main_menu():
        """Display beautiful main menu"""
        menu = f"""
{Colors.CYAN}┌─────────────────────────────────────────────────────────────────────────────┐{Colors.END}
{Colors.CYAN}│                           {Colors.BOLD}🏠 MAIN MENU{Colors.END}{Colors.CYAN}                                    │{Colors.END}
{Colors.CYAN}├─────────────────────────────────────────────────────────────────────────────┤{Colors.END}
{Colors.CYAN}│                                                                             │{Colors.END}
{Colors.CYAN}│  {Colors.GREEN}1️⃣  {Colors.BOLD}Register new user{Colors.END}{Colors.CYAN}                                               │{Colors.END}
{Colors.CYAN}│  {Colors.BLUE}2️⃣  {Colors.BOLD}Login{Colors.END}{Colors.CYAN}                                                           │{Colors.END}
{Colors.CYAN}│  {Colors.YELLOW}3️⃣  {Colors.BOLD}View system info{Colors.END}{Colors.CYAN}                                               │{Colors.END}
{Colors.CYAN}│  {Colors.MAGENTA}4️⃣  {Colors.BOLD}🤖 AI Assistant{Colors.END}{Colors.CYAN}                                                │{Colors.END}
{Colors.CYAN}│  {Colors.RED}5️⃣  {Colors.BOLD}Exit{Colors.END}{Colors.CYAN}                                                             │{Colors.END}
{Colors.CYAN}│                                                                             │{Colors.END}
{Colors.CYAN}└─────────────────────────────────────────────────────────────────────────────┘{Colors.END}
        """
        print(menu)
    
    @staticmethod
    def display_admin_menu():
        """Display admin menu with styling"""
        menu = f"""
{Colors.MAGENTA}┌─────────────────────────────────────────────────────────────────────────────┐{Colors.END}
{Colors.MAGENTA}│                        {Colors.BOLD}👑 ADMIN DASHBOARD{Colors.END}{Colors.MAGENTA}                                    │{Colors.END}
{Colors.MAGENTA}├─────────────────────────────────────────────────────────────────────────────┤{Colors.END}
{Colors.MAGENTA}│                                                                             │{Colors.END}
{Colors.MAGENTA}│  {Colors.GREEN}1️⃣  {Colors.BOLD}📅 Create Event{Colors.END}{Colors.MAGENTA}                                               │{Colors.END}
{Colors.MAGENTA}│  {Colors.BLUE}2️⃣  {Colors.BOLD}✏️  Update Event{Colors.END}{Colors.MAGENTA}                                               │{Colors.END}
{Colors.MAGENTA}│  {Colors.RED}3️⃣  {Colors.BOLD}🗑️  Delete Event{Colors.END}{Colors.MAGENTA}                                               │{Colors.END}
{Colors.MAGENTA}│  {Colors.CYAN}4️⃣  {Colors.BOLD}👁️  View All Events{Colors.END}{Colors.MAGENTA}                                             │{Colors.END}
{Colors.MAGENTA}│  {Colors.YELLOW}5️⃣  {Colors.BOLD}📊 View Statistics{Colors.END}{Colors.MAGENTA}                                             │{Colors.END}
{Colors.MAGENTA}│  {Colors.GREEN}6️⃣  {Colors.BOLD}📤 Export Data{Colors.END}{Colors.MAGENTA}                                               │{Colors.END}
{Colors.MAGENTA}│  {Colors.BLUE}7️⃣  {Colors.BOLD}👤 Logout{Colors.END}{Colors.MAGENTA}                                                 │{Colors.END}
{Colors.MAGENTA}│  {Colors.RED}8️⃣  {Colors.BOLD}🚪 Exit{Colors.END}{Colors.MAGENTA}                                                   │{Colors.END}
{Colors.MAGENTA}│                                                                             │{Colors.END}
{Colors.MAGENTA}└─────────────────────────────────────────────────────────────────────────────┘{Colors.END}
        """
        print(menu)
    
    @staticmethod
    def display_student_menu():
        """Display student menu with styling"""
        menu = f"""
{Colors.BLUE}┌─────────────────────────────────────────────────────────────────────────────┐{Colors.END}
{Colors.BLUE}│                      {Colors.BOLD}🎓 STUDENT/VISITOR MENU{Colors.END}{Colors.BLUE}                                │{Colors.END}
{Colors.BLUE}├─────────────────────────────────────────────────────────────────────────────┤{Colors.END}
{Colors.BLUE}│                                                                             │{Colors.END}
{Colors.BLUE}│  {Colors.GREEN}1️⃣  {Colors.BOLD}🔍 Search Events{Colors.END}{Colors.BLUE}                                               │{Colors.END}
{Colors.BLUE}│  {Colors.YELLOW}2️⃣  {Colors.BOLD}📝 Register for Event{Colors.END}{Colors.BLUE}                                           │{Colors.END}
{Colors.BLUE}│  {Colors.CYAN}3️⃣  {Colors.BOLD}📋 View My Events{Colors.END}{Colors.BLUE}                                               │{Colors.END}
{Colors.BLUE}│  {Colors.MAGENTA}4️⃣  {Colors.BOLD}ℹ️  View Event Details{Colors.END}{Colors.BLUE}                                           │{Colors.END}
{Colors.BLUE}│  {Colors.WHITE}5️⃣  {Colors.BOLD}📱 QR Check-in{Colors.END}{Colors.BLUE}                                               │{Colors.END}
{Colors.BLUE}│  {Colors.RED}6️⃣  {Colors.BOLD}👤 Logout{Colors.END}{Colors.BLUE}                                                 │{Colors.END}
{Colors.BLUE}│  {Colors.RED}7️⃣  {Colors.BOLD}🚪 Exit{Colors.END}{Colors.BLUE}                                                   │{Colors.END}
{Colors.BLUE}│                                                                             │{Colors.END}
{Colors.BLUE}└─────────────────────────────────────────────────────────────────────────────┘{Colors.END}
        """
        print(menu)
    
    @staticmethod
    def display_event(event, index=None):
        """Display event with beautiful formatting"""
        # Determine status and color
        if event.is_full():
            status_color = Colors.RED
            status_icon = "🔴"
            status_text = "FULL"
        elif event.get_available_spots() <= 5:
            status_color = Colors.YELLOW
            status_icon = "🟡"
            status_text = "ALMOST FULL"
        else:
            status_color = Colors.GREEN
            status_icon = "🟢"
            status_text = "AVAILABLE"
        
        # Event display
        if index:
            print(f"{Colors.CYAN}┌─ Event #{index} ─────────────────────────────────────────────────────────────┐{Colors.END}")
        else:
            print(f"{Colors.CYAN}┌─ Event Details ─────────────────────────────────────────────────────────────┐{Colors.END}")
        
        print(f"{Colors.CYAN}│{Colors.END} {Colors.BOLD}📅 {event.name}{Colors.END}")
        print(f"{Colors.CYAN}│{Colors.END} 📝 {event.description}")
        print(f"{Colors.CYAN}│{Colors.END} 📅 Date: {event.date} at {event.time}")
        print(f"{Colors.CYAN}│{Colors.END} 📍 Location: {event.location}")
        print(f"{Colors.CYAN}│{Colors.END} 👥 Capacity: {event.get_attendance_count()}/{event.max_capacity}")
        print(f"{Colors.CYAN}│{Colors.END} {status_color}{status_icon} Status: {status_text}{Colors.END}")
        print(f"{Colors.CYAN}│{Colors.END} 🎯 Available spots: {event.get_available_spots()}")
        print(f"{Colors.CYAN}└─────────────────────────────────────────────────────────────────────────────┘{Colors.END}")
        print()
    
    @staticmethod
    def display_statistics(stats):
        """Display statistics with beautiful formatting"""
        print(f"""
{Colors.CYAN}┌─────────────────────────────────────────────────────────────────────────────┐{Colors.END}
{Colors.CYAN}│                        {Colors.BOLD}📊 SYSTEM STATISTICS{Colors.END}{Colors.CYAN}                                    │{Colors.END}
{Colors.CYAN}├─────────────────────────────────────────────────────────────────────────────┤{Colors.END}
{Colors.CYAN}│                                                                             │{Colors.END}
{Colors.CYAN}│  {Colors.GREEN}📅 Total Events:{Colors.END} {Colors.BOLD}{stats['total_events']}{Colors.END}{Colors.CYAN}                                                      │{Colors.END}
{Colors.CYAN}│  {Colors.BLUE}👥 Total Attendees:{Colors.END} {Colors.BOLD}{stats['total_attendees']}{Colors.END}{Colors.CYAN}                                                 │{Colors.END}
{Colors.CYAN}│  {Colors.YELLOW}📈 Average Attendance:{Colors.END} {Colors.BOLD}{stats['average_attendance']}{Colors.END}{Colors.CYAN}                                            │{Colors.END}
{Colors.CYAN}│                                                                             │{Colors.END}""")
        
        if stats['highest_attendance']:
            print(f"{Colors.CYAN}│  {Colors.GREEN}🏆 Most Popular:{Colors.END} {Colors.BOLD}{stats['highest_attendance']}{Colors.END}{Colors.CYAN}                                            │{Colors.END}")
        
        if stats['lowest_attendance']:
            print(f"{Colors.CYAN}│  {Colors.RED}📉 Least Popular:{Colors.END} {Colors.BOLD}{stats['lowest_attendance']}{Colors.END}{Colors.CYAN}                                          │{Colors.END}")
        
        print(f"""{Colors.CYAN}│                                                                             │{Colors.END}
{Colors.CYAN}└─────────────────────────────────────────────────────────────────────────────┘{Colors.END}""")
    
    @staticmethod
    def display_success_message(message):
        """Display success message"""
        print(f"{Colors.GREEN}[SUCCESS] {message}{Colors.END}")
    
    @staticmethod
    def display_error_message(message):
        """Display error message"""
        print(f"{Colors.RED}[ERROR] {message}{Colors.END}")
    
    @staticmethod
    def display_warning_message(message):
        """Display warning message"""
        print(f"{Colors.YELLOW}[WARNING] {message}{Colors.END}")
    
    @staticmethod
    def display_info_message(message):
        """Display info message"""
        print(f"{Colors.BLUE}[INFO] {message}{Colors.END}")
    
    @staticmethod
    def display_loading(message="Loading..."):
        """Display loading animation"""
        import time
        chars = "|/-\\"
        for i in range(10):
            print(f"\r{Colors.CYAN}{message} {chars[i % len(chars)]}{Colors.END}", end="", flush=True)
            time.sleep(0.1)
        print(f"\r{Colors.GREEN}{message} Complete!{Colors.END}")
    
    @staticmethod
    def display_progress_bar(current, total, message=""):
        """Display progress bar"""
        percentage = int((current / total) * 100)
        bar_length = 30
        filled_length = int(bar_length * current // total)
        bar = "█" * filled_length + "░" * (bar_length - filled_length)
        
        print(f"\r{Colors.CYAN}{message} |{bar}| {percentage}% ({current}/{total}){Colors.END}", end="", flush=True)
        if current == total:
            print()

# Demo function
def demo_enhanced_ui():
    """Demo the enhanced UI features"""
    ui = EnhancedUI()
    
    # Clear screen and show header
    ui.clear_screen()
    ui.display_header()
    ui.display_welcome_message("Tuyen", "Admin")
    
    # Show menus
    ui.display_main_menu()
    ui.display_admin_menu()
    
    # Show messages
    ui.display_success_message("Event created successfully!")
    ui.display_info_message("System is running smoothly")
    ui.display_warning_message("Low disk space detected")
    
    # Show loading
    ui.display_loading("Processing data...")
    
    # Show progress bar
    for i in range(11):
        ui.display_progress_bar(i, 10, "Loading events")
        import time
        time.sleep(0.2)
    
    print("\n" + "="*60)
    print("🎉 Enhanced UI Demo Complete!")

if __name__ == "__main__":
    demo_enhanced_ui()














