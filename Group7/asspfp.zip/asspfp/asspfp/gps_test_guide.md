# 📍 GPS Test Guide - Campus Event Management System

## 🎯 Mục đích Test GPS
Kiểm tra tính năng GPS Location và GPS Check-in trong hệ thống quản lý sự kiện campus.

---

## 📋 Checklist Test GPS

### ✅ **Phase 1: Setup GPS Location**

**1.1 Truy cập GPS Location Page**
- [ ] Vào `http://localhost:3000/gps-location`
- [ ] Đăng nhập với user ID: `39eb0cc1-d1c5-49ed-8efa-7e84d8b66254`
- [ ] Kiểm tra trang GPS hiển thị đúng

**1.2 Test Interactive Map**
- [ ] Bản đồ Leaflet hiển thị (OpenStreetMap)
- [ ] Click trên bản đồ để chọn vị trí
- [ ] Tọa độ latitude/longitude cập nhật
- [ ] Địa chỉ hiển thị (reverse geocoding)

**1.3 Test Current Location**
- [ ] Click "Lấy vị trí hiện tại"
- [ ] Cho phép browser access location
- [ ] Vị trí hiện tại được lấy thành công
- [ ] Bản đồ zoom đến vị trí hiện tại

**1.4 Save GPS Location**
- [ ] Chọn vị trí trên bản đồ
- [ ] Click "Lưu vị trí"
- [ ] Flash message hiển thị thành công
- [ ] Vị trí được lưu vào user profile

---

### ✅ **Phase 2: Test GPS Check-in**

**2.1 Create Event with GPS**
- [ ] Vào "Create Event"
- [ ] Điền thông tin sự kiện
- [ ] Thêm GPS coordinates:
  - Latitude: `10.762622` (FPT University)
  - Longitude: `106.660172`
- [ ] Tạo sự kiện thành công

**2.2 Test GPS Distance Calculation**
- [ ] Vị trí user: `10.762622, 106.660172` (FPT University)
- [ ] Vị trí event: `10.762622, 106.660172` (Same location)
- [ ] Distance = 0km (should pass GPS verification)

**2.3 Test GPS Check-in Success**
- [ ] Vào QR Check-in page
- [ ] Nhập Event ID và User ID
- [ ] GPS verification should PASS (within 100m radius)
- [ ] Check-in thành công

**2.4 Test GPS Check-in Failure**
- [ ] Thay đổi user location xa event (>100m)
- [ ] Thử check-in lại
- [ ] GPS verification should FAIL
- [ ] Hiển thị error message

---

### ✅ **Phase 3: Test GPS Features**

**3.1 Test GPS Location Display**
- [ ] Vị trí hiện tại hiển thị đúng
- [ ] Button "Xem trên bản đồ" hoạt động
- [ ] Bản đồ center đúng vị trí đã lưu

**3.2 Test GPS Error Handling**
- [ ] Deny browser location permission
- [ ] Error message hiển thị đúng
- [ ] Manual location selection vẫn hoạt động

**3.3 Test GPS Integration**
- [ ] GPS location được lưu trong user data
- [ ] GPS verification trong check-in
- [ ] Distance calculation chính xác

---

## 🧪 Test Cases Chi Tiết

### **Test Case 1: GPS Location Setup**
```
Input: User clicks "Lấy vị trí hiện tại"
Expected: Browser requests location permission
Actual: [ ] PASS / [ ] FAIL
Notes: ________________
```

### **Test Case 2: Map Interaction**
```
Input: User clicks on map at coordinates (10.762622, 106.660172)
Expected: Latitude/Longitude fields update, address shows
Actual: [ ] PASS / [ ] FAIL
Notes: ________________
```

### **Test Case 3: GPS Check-in Success**
```
Input: User at same location as event (within 100m)
Expected: GPS verification PASS, check-in successful
Actual: [ ] PASS / [ ] FAIL
Notes: ________________
```

### **Test Case 4: GPS Check-in Failure**
```
Input: User at different location (>100m from event)
Expected: GPS verification FAIL, check-in denied
Actual: [ ] PASS / [ ] FAIL
Notes: ________________
```

### **Test Case 5: Distance Calculation**
```
Input: User (10.762622, 106.660172) vs Event (10.763622, 106.661172)
Expected: Distance ≈ 0.14km (should fail - >100m)
Actual: [ ] PASS / [ ] FAIL
Notes: ________________
```

---

## 📊 Test Data

### **GPS Coordinates for Testing**

**FPT University (Main Campus)**
- Latitude: `10.762622`
- Longitude: `106.660172`
- Address: "FPT University, D1 Street, Hi-Tech Park, Thu Duc City"

**Nearby Locations (for distance testing)**
- **100m North**: `10.763622, 106.660172` (should PASS)
- **200m South**: `10.761622, 106.660172` (should FAIL)
- **150m East**: `10.762622, 106.661172` (should FAIL)

### **Test User IDs**
- **Admin**: `39eb0cc1-d1c5-49ed-8efa-7e84d8b66254`
- **Event Organizer**: `d93deb36-55f7-4970-b374-8b7b312d4362`

---

## 🔧 Technical Test Points

### **Browser Compatibility**
- [ ] Chrome: GPS permission, map interaction
- [ ] Firefox: GPS permission, map interaction  
- [ ] Safari: GPS permission, map interaction
- [ ] Edge: GPS permission, map interaction

### **Mobile Testing**
- [ ] GPS accuracy on mobile device
- [ ] Touch interaction with map
- [ ] Responsive design
- [ ] GPS permission on mobile browser

### **Performance Testing**
- [ ] Map loading time
- [ ] GPS location retrieval speed
- [ ] Distance calculation performance
- [ ] Reverse geocoding response time

---

## 🐛 Common Issues & Solutions

### **Issue 1: GPS Permission Denied**
```
Problem: Browser blocks location access
Solution: 
1. Check browser settings
2. Use HTTPS (required for GPS)
3. Manual location selection as fallback
```

### **Issue 2: Map Not Loading**
```
Problem: Leaflet map doesn't display
Solution:
1. Check internet connection
2. Verify Leaflet CDN links
3. Check browser console for errors
```

### **Issue 3: GPS Check-in Always Fails**
```
Problem: GPS verification never passes
Solution:
1. Check distance calculation
2. Verify GPS coordinates format
3. Check radius settings (100m)
```

### **Issue 4: Reverse Geocoding Fails**
```
Problem: Address not showing
Solution:
1. Check Nominatim API access
2. Verify coordinates are valid
3. Handle API rate limiting
```

---

## 📈 Success Criteria

### **Functional Requirements**
- [ ] GPS location can be set and saved
- [ ] Interactive map works correctly
- [ ] GPS check-in verification works
- [ ] Distance calculation is accurate
- [ ] Error handling is proper

### **Performance Requirements**
- [ ] Map loads within 3 seconds
- [ ] GPS location retrieved within 5 seconds
- [ ] Distance calculation < 100ms
- [ ] Reverse geocoding < 2 seconds

### **User Experience Requirements**
- [ ] Intuitive map interface
- [ ] Clear error messages
- [ ] Responsive design
- [ ] Accessible on mobile

---

## 📝 Test Report Template

```
GPS Test Report - [Date]

Tester: ________________
Browser: ________________
Device: ________________

Overall Result: [ ] PASS / [ ] FAIL

Phase 1 (GPS Setup): [ ] PASS / [ ] FAIL
Phase 2 (GPS Check-in): [ ] PASS / [ ] FAIL  
Phase 3 (GPS Features): [ ] PASS / [ ] FAIL

Issues Found:
1. ________________
2. ________________
3. ________________

Recommendations:
1. ________________
2. ________________
3. ________________
```

---

## 🚀 Quick Test Commands

### **Start Server**
```bash
cd D:\asspfp
python app.py
```

### **Test GPS Location Page**
```bash
curl -I http://localhost:3000/gps-location
```

### **Test GPS API**
```bash
# Test distance calculation
python -c "
from mobile_features import GPSLocation
distance = GPSLocation.calculate_distance(10.762622, 106.660172, 10.763622, 106.660172)
print(f'Distance: {distance:.3f}km')
"
```

---

**🎯 Mục tiêu: Đảm bảo GPS Location và GPS Check-in hoạt động chính xác, đáng tin cậy và user-friendly!**



