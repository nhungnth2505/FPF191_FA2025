# Campus Event Management System - Flowchart and Documentation

## System Flowchart

```
START
  │
  ▼
┌─────────────────────────────────────┐
│     WELCOME TO EVENT SYSTEM        │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│         MAIN MENU                   │
│  ┌─────────────────────────────────┐ │
│  │ 1. Register new user           │ │
│  │ 2. Login                       │ │
│  │ 3. Exit                        │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│        USER REGISTRATION            │
│  ┌─────────────────────────────────┐ │
│  │ • Select user type:             │ │
│  │   - Admin                       │ │
│  │   - Event Organizer             │ │
│  │   - Student                     │ │
│  │   - Visitor                     │ │
│  │ • Enter name and email          │ │
│  │ • Generate unique user ID       │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│           USER LOGIN                │
│  ┌─────────────────────────────────┐ │
│  │ • Enter user ID                 │ │
│  │ • Validate credentials          │ │
│  │ • Set current user              │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│      ROLE-BASED MENU SYSTEM         │
└─────────────────────────────────────┘
  │
  ├─ ADMIN ROLE ──────────────────────┐
  │                                   │
  │ ┌─────────────────────────────────┐ │
  │ │ ADMIN MENU:                     │ │
  │ │ 1. Create Event                 │ │
  │ │ 2. Update Event                 │ │
  │ │ 3. Delete Event                 │ │
  │ │ 4. View All Events              │ │
  │ │ 5. View Statistics              │ │
  │ │ 6. Export Data                  │ │
  │ │ 7. Logout                       │ │
  │ │ 8. Exit                         │ │
  │ └─────────────────────────────────┘ │
  │                                   │
  └───────────────────────────────────┘
  │
  ├─ EVENT ORGANIZER ROLE ───────────┐
  │                                   │
  │ ┌─────────────────────────────────┐ │
  │ │ ORGANIZER MENU:                 │ │
  │ │ 1. Create Event                 │ │
  │ │ 2. View My Events               │ │
  │ │ 3. Manage Attendees             │ │
  │ │ 4. View Event Details           │ │
  │ │ 5. View Statistics              │ │
  │ │ 6. Logout                       │ │
  │ │ 7. Exit                         │ │
  │ └─────────────────────────────────┘ │
  │                                   │
  └───────────────────────────────────┘
  │
  └─ STUDENT/VISITOR ROLE ───────────┐
                                      │
    ┌─────────────────────────────────┐ │
    │ STUDENT/VISITOR MENU:           │ │
    │ 1. Search Events                │ │
    │ 2. Register for Event           │ │
    │ 3. View My Events               │ │
    │ 4. View Event Details           │ │
    │ 5. Logout                       │ │
    │ 6. Exit                         │ │
    └─────────────────────────────────┘ │
                                      │
    └───────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│        EVENT MANAGEMENT             │
│  ┌─────────────────────────────────┐ │
│  │ CREATE EVENT:                   │ │
│  │ • Validate permissions          │ │
│  │ • Input validation              │ │
│  │ • Create event object            │ │
│  │ • Save to system                │ │
│  └─────────────────────────────────┘ │
│  ┌─────────────────────────────────┐ │
│  │ UPDATE EVENT:                   │ │
│  │ • Check permissions             │ │
│  │ • Validate input                │ │
│  │ • Update event fields            │ │
│  └─────────────────────────────────┘ │
│  ┌─────────────────────────────────┐ │
│  │ DELETE EVENT:                   │ │
│  │ • Admin permission required     │ │
│  │ • Remove from system            │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│      ATTENDEE REGISTRATION          │
│  ┌─────────────────────────────────┐ │
│  │ REGISTRATION PROCESS:           │ │
│  │ • Search available events       │ │
│  │ • Select event                  │ │
│  │ • Check capacity                │ │
│  │ • Prevent duplicates            │ │
│  │ • Confirm registration          │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│        DATA PERSISTENCE             │
│  ┌─────────────────────────────────┐ │
│  │ SAVE DATA:                       │ │
│  │ • JSON format for events         │ │
│  │ • User data storage              │ │
│  │ • Auto-save on exit              │ │
│  └─────────────────────────────────┘ │
│  ┌─────────────────────────────────┐ │
│  │ EXPORT REPORTS:                  │ │
│  │ • CSV format                    │ │
│  │ • Event statistics              │ │
│  │ • Attendance data                │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│         STATISTICS & REPORTS        │
│  ┌─────────────────────────────────┐ │
│  │ CALCULATE:                      │ │
│  │ • Total attendees               │ │
│  │ • Events with highest/lowest    │ │
│  │   attendance                    │ │
│  │ • Average attendance            │ │
│  │ • Export to CSV                 │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
┌─────────────────────────────────────┐
│            EXIT                     │
│  ┌─────────────────────────────────┐ │
│  │ • Save all data                 │ │
│  │ • Close application             │ │
│  └─────────────────────────────────┘ │
└─────────────────────────────────────┘
  │
  ▼
END
```

## Class and Method Documentation

### Core Classes

#### 1. User (Abstract Base Class)
- **Purpose**: Base class for all user types with role-based permissions
- **Key Methods**:
  - `get_permissions()`: Returns list of permissions for user role
  - `has_permission(permission)`: Checks if user has specific permission

#### 2. Admin (User Subclass)
- **Purpose**: Full system access for administrators
- **Permissions**: Create/update/delete events, view all data, export reports

#### 3. EventOrganizer (User Subclass)
- **Purpose**: Limited event management for organizers
- **Permissions**: Manage their own events, view attendees, basic statistics
- **Additional**: `managed_events` list to track assigned events

#### 4. Student/Visitor (User Subclasses)
- **Purpose**: Basic event access for students and visitors
- **Permissions**: Search events, register for events, view their registrations

#### 5. Event
- **Purpose**: Represents a campus event with capacity management
- **Key Methods**:
  - `add_attendee(user_id)`: Register user if capacity allows
  - `remove_attendee(user_id)`: Unregister user
  - `is_full()`: Check if event is at capacity
  - `get_available_spots()`: Get remaining capacity
  - `to_dict()`/`from_dict()`: Serialization for data persistence

#### 6. EventManager
- **Purpose**: Main system controller managing events and users
- **Key Methods**:
  - `register_user()`: Create new users
  - `login()`: Authenticate users
  - `create_event()`: Create new events with validation
  - `update_event()`: Modify existing events
  - `delete_event()`: Remove events
  - `register_attendee()`: Register users for events
  - `search_events()`: Find events by criteria
  - `get_statistics()`: Calculate system statistics
  - `export_to_csv()`: Export data to CSV format
  - `save_data()`/`load_data()`: Data persistence

#### 7. EventManagementSystem
- **Purpose**: Main application interface and user interaction
- **Key Methods**:
  - `display_menu()`: Show role-appropriate menus
  - `run()`: Main application loop
  - `handle_*()`: Process user choices for different operations

### Key Features Implemented

1. **Role-Based Access Control**:
   - Different permission sets for each user type
   - Permission checking before operations
   - Secure authentication system

2. **Event Management**:
   - Full CRUD operations for events
   - Input validation for all fields
   - Date format validation
   - Capacity tracking

3. **Attendee Registration**:
   - Capacity checking before registration
   - Duplicate registration prevention
   - Confirmation messages
   - Easy unregistration

4. **Data Persistence**:
   - JSON format for main data storage
   - CSV export for reports
   - Automatic save on exit
   - Data loading on startup

5. **Statistics and Reporting**:
   - Total attendees calculation
   - Highest/lowest attendance events
   - Average attendance
   - CSV export functionality

6. **Input Validation**:
   - Required field checking
   - Date format validation
   - Capacity validation
   - Permission checking

7. **Error Handling**:
   - Try-catch blocks for all operations
   - User-friendly error messages
   - Graceful failure handling

### Additional Creative Features

1. **UUID-based IDs**: Unique identifiers for all entities
2. **Modular Design**: Clean separation of concerns
3. **Extensible Architecture**: Easy to add new user types or features
4. **Comprehensive Logging**: Detailed operation feedback
5. **Data Export**: Multiple format support (JSON, CSV)
6. **Search Functionality**: Text and date-based event filtering
7. **Capacity Management**: Real-time availability tracking
8. **Role-specific Menus**: Tailored interfaces for each user type

## Usage Instructions

1. **Run the System**: Execute `python ass.py`
2. **Register Users**: Create accounts for different user types
3. **Login**: Use the generated user ID to access the system
4. **Manage Events**: Create, update, and delete events based on permissions
5. **Register Attendees**: Students and visitors can register for events
6. **View Statistics**: Admins and organizers can view system statistics
7. **Export Data**: Generate CSV reports for external use

The system provides a complete solution for campus event management with professional-grade features and robust error handling.











