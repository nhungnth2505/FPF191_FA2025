"""
Enhanced Campus Event Management System
Tích hợp giao diện đẹp và tính năng mobile
"""

import json
import os
import uuid
from datetime import datetime, date
from typing import List, Dict, Optional, Tuple
from abc import ABC, abstractmethod
import qrcode
from io import BytesIO
import base64

# Import enhanced features
from enhanced_ui import EnhancedUI, Colors
from ai_assistant import SimpleAIAssistant

# Toggle to enable/disable all mobile features (QR, GPS, Mobile Check-in)
MOBILE_ENABLED = True

try:
    if MOBILE_ENABLED:
        from mobile_features import MobileEventManager, QRCodeGenerator, GPSLocation, MobileCheckIn
    else:
        raise ImportError
except Exception:
    # Lightweight stubs when mobile features are disabled
    class QRCodeGenerator:  # type: ignore
        def generate_event_qr(self, *args, **kwargs):
            return None
        def generate_user_qr(self, *args, **kwargs):
            return None
        def save_qr_to_file(self, *args, **kwargs):
            return None
    class GPSLocation:  # type: ignore
        @staticmethod
        def calculate_distance(*args, **kwargs):
            return 0.0
        @staticmethod
        def is_within_radius(*args, **kwargs):
            return False
    class MobileEventManager:  # type: ignore
        pass
    class MobileCheckIn:  # type: ignore
        def check_in_user(self, user_id, event_id, qr_data=None, gps_location=None):
            return {
                "user_id": user_id,
                "event_id": event_id,
                "gps_verified": False,
                "qr_verified": False,
            }

class EnhancedUser(ABC):
    """Enhanced User class with mobile features"""
    
    def __init__(self, user_id: str, name: str, email: str, phone: str = ""):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.phone = phone
        self.role = self.__class__.__name__
        self.qr_code = None
        self.gps_location = None
    
    @abstractmethod
    def get_permissions(self) -> List[str]:
        pass
    
    def has_permission(self, permission: str) -> bool:
        return permission in self.get_permissions()
    
    def generate_user_qr(self):
        """QR functionality removed."""
        return None
    
    def set_location(self, latitude: float, longitude: float):
        """Set user's GPS location (noop when disabled)"""
        if not MOBILE_ENABLED:
            return
        self.gps_location = {"lat": latitude, "lon": longitude}
    
    def __str__(self):
        return f"{self.role}: {self.name} ({self.email})"

class EnhancedAdmin(EnhancedUser):
    """Enhanced Admin with mobile features"""
    
    def get_permissions(self) -> List[str]:
        return [
            "create_event", "update_event", "delete_event", "view_all_events",
            "view_all_attendees", "manage_users", "view_statistics", "export_data",
            "search_events", "register_for_events", "view_registered_events", 
            "view_event_details"
        ]

class EnhancedEventOrganizer(EnhancedUser):
    """Enhanced Event Organizer"""
    
    def __init__(self, user_id: str, name: str, email: str, phone: str = ""):
        super().__init__(user_id, name, email, phone)
        self.managed_events: List[str] = []
    
    def get_permissions(self) -> List[str]:
        return [
            "view_managed_events", "manage_attendees", "view_event_details",
            "register_attendees", "view_statistics", "create_event"
        ]

class EnhancedStudent(EnhancedUser):
    """Enhanced Student with mobile features"""
    
    def get_permissions(self) -> List[str]:
        return [
            "search_events", "register_for_events", "view_registered_events",
            "view_event_details"
        ]

class EnhancedEvent:
    """Enhanced Event with mobile features"""
    
    def __init__(self, event_id: str, name: str, description: str, date: str, 
                 time: str, location: str, max_capacity: int, organizer_id: str,
                 latitude: float = None, longitude: float = None, category: str = "general"):
        self.event_id = event_id
        self.name = name
        self.description = description
        self.date = date
        self.time = time
        self.location = location
        self.max_capacity = max_capacity
        self.organizer_id = organizer_id
        self.latitude = latitude
        self.longitude = longitude
        self.category = category
        self.attendees: List[str] = []
        self.created_at = datetime.now().isoformat()
        self.qr_code = None
        self.image_path = None  # Đường dẫn hình ảnh
    
    def add_attendee(self, user_id: str) -> bool:
        """Add attendee if capacity allows"""
        if len(self.attendees) < self.max_capacity and user_id not in self.attendees:
            self.attendees.append(user_id)
            return True
        return False
    
    def remove_attendee(self, user_id: str) -> bool:
        """Remove attendee from event"""
        if user_id in self.attendees:
            self.attendees.remove(user_id)
            return True
        return False
    
    def get_attendance_count(self) -> int:
        """Get current number of attendees"""
        return len(self.attendees)
    
    def is_full(self) -> bool:
        """Check if event is at capacity"""
        return len(self.attendees) >= self.max_capacity
    
    def get_available_spots(self) -> int:
        """Get number of available spots"""
        return max(0, self.max_capacity - len(self.attendees))
    
    def generate_qr_code(self) -> str:
        """Generate QR code for event check-in"""
        try:
            # Create QR code data
            qr_data = {
                "event_id": self.event_id,
                "event_name": self.name,
                "date": self.date,
                "time": self.time,
                "location": self.location,
                "type": "event_checkin"
            }
            
            # Generate QR code
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(json.dumps(qr_data))
            qr.make(fit=True)
            
            # Create image
            img = qr.make_image(fill_color="black", back_color="white")
            
            # Save to file
            qr_filename = f"qr_event_{self.event_id}.png"
            img.save(qr_filename)
            
            self.qr_code = qr_filename
            return qr_filename
            
        except Exception as e:
            print(f"Error generating QR code: {e}")
            return None
    
    def to_dict(self) -> Dict:
        """Convert event to dictionary for serialization"""
        return {
            'event_id': self.event_id,
            'name': self.name,
            'description': self.description,
            'date': self.date,
            'time': self.time,
            'location': self.location,
            'max_capacity': self.max_capacity,
            'organizer_id': self.organizer_id,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'category': self.category,
            'attendees': self.attendees,
            'created_at': self.created_at,
            'qr_code': self.qr_code,
            'image_path': getattr(self, 'image_path', None)
        }

class EnhancedEventManager:
    """Enhanced Event Manager with mobile features"""
    
    def __init__(self):
        self.events: Dict[str, EnhancedEvent] = {}
        self.users: Dict[str, EnhancedUser] = {}
        self.current_user: Optional[EnhancedUser] = None
        self.data_file = "enhanced_event_data.json"
        self.mobile_manager = MobileEventManager() if MOBILE_ENABLED else None
        self.check_in_system = MobileCheckIn() if MOBILE_ENABLED else None
        self.ui = EnhancedUI()
        self.load_data()
    
    def load_data(self):
        """Load data from JSON file"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                
                # Load events
                for event_data in data.get('events', []):
                    event = EnhancedEvent(
                        event_data['event_id'], event_data['name'], 
                        event_data['description'], event_data['date'],
                        event_data['time'], event_data['location'],
                        event_data['max_capacity'], event_data['organizer_id'],
                        event_data.get('latitude'), event_data.get('longitude'),
                        event_data.get('category', 'general')
                    )
                    event.attendees = event_data.get('attendees', [])
                    event.qr_code = event_data.get('qr_code')
                    self.events[event.event_id] = event
                
                # Load users
                for user_id, user_data in data.get('users', {}).items():
                    user_type = user_data.get('role', 'EnhancedStudent')
                    if user_type == 'EnhancedAdmin':
                        user = EnhancedAdmin(user_id, user_data['name'], user_data['email'], user_data.get('phone', ''))
                    elif user_type == 'EnhancedEventOrganizer':
                        user = EnhancedEventOrganizer(user_id, user_data['name'], user_data['email'], user_data.get('phone', ''))
                    elif user_type == 'EnhancedStudent':
                        user = EnhancedStudent(user_id, user_data['name'], user_data['email'], user_data.get('phone', ''))
                    else:
                        # Default to student if role is unknown
                        user = EnhancedStudent(user_id, user_data['name'], user_data['email'], user_data.get('phone', ''))
                    
                    self.users[user_id] = user
                
                self.ui.display_success_message("Enhanced data loaded successfully!")
            except Exception as e:
                self.ui.display_error_message(f"Error loading data: {e}")
    
    def save_data(self):
        """Save data to JSON file"""
        try:
            data = {
                'events': [event.to_dict() for event in self.events.values()],
                'users': {user_id: {
                    'name': user.name, 'email': user.email, 'role': user.role,
                    'phone': getattr(user, 'phone', '')
                } for user_id, user in self.users.items()}
            }
            with open(self.data_file, 'w') as f:
                json.dump(data, f, indent=2)
            self.ui.display_success_message("Enhanced data saved successfully!")
        except Exception as e:
            self.ui.display_error_message(f"Error saving data: {e}")
    
    def register_user(self, user_type: str, name: str, email: str, phone: str = ""):
        """Register a new user with mobile features"""
        # Validate email format
        import re
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, email):
            raise ValueError("Email không hợp lệ! Vui lòng nhập email đúng định dạng (ví dụ: user@domain.com)")
        
        # Validate phone number (if provided)
        if phone:
            # Remove spaces and special characters
            phone_clean = re.sub(r'[^\d]', '', phone)
            if len(phone_clean) < 10 or len(phone_clean) > 15:
                raise ValueError("Số điện thoại không hợp lệ! Vui lòng nhập số điện thoại từ 10-15 chữ số")
            if not phone_clean.isdigit():
                raise ValueError("Số điện thoại chỉ được chứa chữ số!")
        
        # Validate name
        if not name or len(name.strip()) < 2:
            raise ValueError("Tên phải có ít nhất 2 ký tự!")
        
        user_id = str(uuid.uuid4())
        
        if user_type.lower() == 'admin':
            user = EnhancedAdmin(user_id, name, email, phone)
        elif user_type.lower() == 'organizer':
            user = EnhancedEventOrganizer(user_id, name, email, phone)
        elif user_type.lower() == 'student':
            user = EnhancedStudent(user_id, name, email, phone)
        else:
            raise ValueError("Loại người dùng không hợp lệ! Chọn: admin, organizer, hoặc student")
        
        self.users[user_id] = user
        self.save_data()  # Auto-save after registration
        self.ui.display_success_message(f"User {name} registered successfully!")
        return user_id
    
    def login(self, user_id: str):
        """Login user by ID"""
        if user_id in self.users:
            self.current_user = self.users[user_id]
            self.ui.display_success_message(f"Welcome back, {self.current_user.name}!")
            return True
        return False
    
    def create_event(self, name: str, description: str, date: str, time: str, 
                    location: str, max_capacity: int, latitude: float = None, 
                    longitude: float = None, category: str = "general"):
        """Create a new event with mobile features"""
        if not self.current_user or not self.current_user.has_permission("create_event"):
            raise PermissionError("You don't have permission to create events")
        
        # Input validation
        if not name or not description or not date or not time or not location:
            raise ValueError("All fields are required")
        
        if max_capacity <= 0:
            raise ValueError("Capacity must be positive")
        
        # Validate date format
        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Date must be in YYYY-MM-DD format")
        
        event_id = str(uuid.uuid4())
        event = EnhancedEvent(event_id, name, description, date, time, location, 
                            max_capacity, self.current_user.user_id, latitude, longitude, category)
        
        self.events[event_id] = event
        
        # Generate QR code for event check-in
        qr_file = event.generate_qr_code()
        if qr_file:
            self.ui.display_success_message(f"Event '{name}' created successfully! QR code: {qr_file}")
        else:
            self.ui.display_success_message(f"Event '{name}' created successfully!")
        
        return event_id
    
    def scan_qr_checkin(self, qr_data: str) -> bool:
        """Scan QR code and check-in user to event"""
        try:
            # Parse QR data
            data = json.loads(qr_data)
            
            if data.get("type") != "event_checkin":
                return False
            
            event_id = data.get("event_id")
            if not event_id or event_id not in self.events:
                return False
            
            event = self.events[event_id]
            
            # Check if user is already registered
            if self.current_user.user_id in event.attendees:
                return False  # Already checked in
            
            # Check capacity
            if len(event.attendees) >= event.max_capacity:
                return False  # Event is full
            
            # Add user to attendees
            event.attendees.append(self.current_user.user_id)
            return True
            
        except Exception as e:
            print(f"Error scanning QR code: {e}")
            return False
    
    def find_nearby_events(self, user_lat: float, user_lon: float, radius: float = 5.0):
        """Find events near user location"""
        if not MOBILE_ENABLED:
            return []
        
        nearby_events = []
        for event in self.events.values():
            if event.latitude and event.longitude:
                distance = GPSLocation.calculate_distance(
                    user_lat, user_lon, event.latitude, event.longitude
                )
                if distance <= radius:
                    nearby_events.append({
                        'event': event,
                        'distance': round(distance, 2)
                    })
        
        nearby_events.sort(key=lambda x: x['distance'])
        return nearby_events
    
    def mobile_check_in(self, event_id: str, user_lat: float = None, user_lon: float = None):
        """Mobile check-in with GPS verification (disabled)."""
        if not MOBILE_ENABLED:
            raise PermissionError("Mobile features are disabled")
        
        if event_id not in self.events:
            raise ValueError("Event not found")
        
        event = self.events[event_id]
        
        # GPS verification
        if user_lat and user_lon and event.latitude and event.longitude:
            if not GPSLocation.is_within_radius(
                user_lat, user_lon, event.latitude, event.longitude, 0.1
            ):
                raise ValueError("You must be at the event location to check in")
        
        # Check capacity
        if event.is_full():
            raise ValueError("Event is at full capacity")
        
        # Add to attendees
        if self.current_user.user_id not in event.attendees:
            event.add_attendee(self.current_user.user_id)
        
        # Record check-in
        check_in = self.check_in_system.check_in_user(
            self.current_user.user_id, event_id, 
            gps_location={"lat": user_lat, "lon": user_lon} if user_lat and user_lon else None
        )
        
        self.ui.display_success_message(f"Successfully checked in to '{event.name}'!")
        return check_in
    
    def display_events_with_ui(self, events: List[EnhancedEvent]):
        """Display events with enhanced UI"""
        if not events:
            self.ui.display_info_message("No events found.")
            return
        
        self.ui.display_success_message(f"Found {len(events)} event(s):")
        for i, event in enumerate(events, 1):
            self.ui.display_event(event, i)
    
    def display_statistics_with_ui(self):
        """Display statistics with enhanced UI"""
        if not self.current_user or not self.current_user.has_permission("view_statistics"):
            raise PermissionError("You don't have permission to view statistics")
        
        total_attendees = sum(len(event.attendees) for event in self.events.values())
        total_events = len(self.events)
        
        if not self.events:
            stats = {
                'total_events': 0,
                'total_attendees': 0,
                'highest_attendance': None,
                'lowest_attendance': None,
                'average_attendance': 0
            }
        else:
            attendance_counts = [len(event.attendees) for event in self.events.values()]
            highest = max(attendance_counts)
            lowest = min(attendance_counts)
            average = total_attendees / total_events
            
            highest_event = None
            lowest_event = None
            
            for event in self.events.values():
                if len(event.attendees) == highest:
                    highest_event = event.name
                if len(event.attendees) == lowest:
                    lowest_event = event.name
            
            stats = {
                'total_events': total_events,
                'total_attendees': total_attendees,
                'highest_attendance': highest_event,
                'lowest_attendance': lowest_event,
                'average_attendance': round(average, 2)
            }
        
        self.ui.display_statistics(stats)

class EnhancedEventManagementSystem:
    """Enhanced main application with mobile features"""
    
    def __init__(self):
        self.manager = EnhancedEventManager()
        self.running = True
        self.ui = EnhancedUI()
    
    def display_enhanced_menu(self):
        """Display enhanced menu based on user role"""
        if not self.manager.current_user:
            self.ui.display_main_menu()
            return
        
        user = self.manager.current_user
        self.ui.display_welcome_message(user.name, user.role)
        
        if isinstance(user, EnhancedAdmin):
            self.ui.display_admin_menu()
        elif isinstance(user, EnhancedEventOrganizer):
            self.ui.display_student_menu()  # Similar to student menu
        else:  # Student
            self.ui.display_student_menu()
    
    # Mobile features removed per requirements
    
    def handle_set_location(self):
        """Handle setting user location"""
        try:
            lat = float(input("Enter latitude: "))
            lon = float(input("Enter longitude: "))
            self.manager.current_user.set_location(lat, lon)
            self.ui.display_success_message("Location set successfully!")
        except ValueError:
            self.ui.display_error_message("Invalid coordinates!")
    
    def handle_find_nearby(self):
        """Handle finding nearby events"""
        if not self.manager.current_user.gps_location:
            self.ui.display_error_message("Please set your location first!")
            return
        
        lat = self.manager.current_user.gps_location['lat']
        lon = self.manager.current_user.gps_location['lon']
        radius = float(input("Enter search radius (km): ") or "5.0")
        
        nearby = self.manager.find_nearby_events(lat, lon, radius)
        if nearby:
            self.ui.display_success_message(f"Found {len(nearby)} nearby events:")
            for item in nearby:
                event = item['event']
                distance = item['distance']
                print(f"  📅 {event.name} - {distance}km away")
        else:
            self.ui.display_info_message("No nearby events found.")
    
    def handle_mobile_check_in(self):
        """Handle mobile check-in"""
        # Show available events
        events = list(self.manager.events.values())
        if not events:
            self.ui.display_info_message("No events available.")
            return
        
        print(f"\n{Colors.CYAN}Available Events:{Colors.END}")
        for i, event in enumerate(events, 1):
            print(f"{i}. {event.name} - {event.date} at {event.time}")
        
        try:
            choice = int(input("Select event number: ")) - 1
            if 0 <= choice < len(events):
                event = events[choice]
                
                # Get user location
                lat = None
                lon = None
                if self.manager.current_user.gps_location:
                    lat = self.manager.current_user.gps_location['lat']
                    lon = self.manager.current_user.gps_location['lon']
                
                self.manager.mobile_check_in(event.event_id, lat, lon)
            else:
                self.ui.display_error_message("Invalid selection!")
        except (ValueError, IndexError):
            self.ui.display_error_message("Invalid input!")
    
    def handle_generate_qr(self):
        """Handle QR code generation"""
        if not self.manager.current_user:
            self.ui.display_error_message("You must be logged in!")
            return
        
        qr = self.manager.current_user.generate_user_qr()
        filename = f"qr_user_{self.manager.current_user.user_id}.png"
        QRCodeGenerator().save_qr_to_file(qr, filename)
        self.ui.display_success_message(f"QR code saved to {filename}")
    
    def handle_mobile_stats(self):
        """Handle mobile statistics"""
        self.manager.display_statistics_with_ui()
    
    def run(self):
        """Enhanced main application loop"""
        self.ui.clear_screen()
        self.ui.display_header()
        
        while self.running:
            try:
                self.display_enhanced_menu()
                choice = input(f"\n{Colors.CYAN}Enter your choice: {Colors.END}").strip()
                
                if not self.manager.current_user:
                    self.handle_guest_choice(choice)
                else:
                    self.handle_authenticated_choice(choice)
                    
            except KeyboardInterrupt:
                self.ui.display_info_message("Exiting...")
                self.manager.save_data()
                break
            except Exception as e:
                self.ui.display_error_message(f"An error occurred: {e}")
    
    def handle_guest_choice(self, choice: str):
        """Handle choices for non-authenticated users"""
        if choice == '1':
            self.handle_user_registration()
        elif choice == '2':
            self.handle_login()
        elif choice == '3':
            self.display_system_info()
        elif choice == '4':
            self.handle_ai_assistant()
        elif choice == '5':
            self.running = False
            self.manager.save_data()
        else:
            self.ui.display_error_message("Invalid choice!")
    
    def handle_authenticated_choice(self, choice: str):
        """Handle choices for authenticated users"""
        # Admin/Organizer keep existing mapping. For Students, repurpose choices.
        if isinstance(self.manager.current_user, EnhancedAdmin) or isinstance(self.manager.current_user, EnhancedEventOrganizer):
            if choice == '1':
                self.handle_create_event()
            elif choice == '2':
                self.handle_search_events()
            elif choice == '3':
                self.handle_register_for_event()
            elif choice == '4':
                self.handle_view_statistics()
            elif choice == '5':
                self.handle_view_statistics()
            elif choice == '6':
                self.manager.current_user = None
                self.ui.display_success_message("Logged out successfully!")
            elif choice == '7':
                self.running = False
                self.manager.save_data()
            else:
                self.ui.display_error_message("Invalid choice!")
        else:
            # Student menu mapping
            if choice == '1':
                self.handle_search_events()
            elif choice == '2':
                self.handle_register_for_event()
            elif choice == '3':
                self.handle_view_registered_events()
            elif choice == '4':
                self.handle_view_event_details()
            elif choice == '5':
                self.handle_qr_checkin()
            elif choice == '6':
                self.manager.current_user = None
                self.ui.display_success_message("Logged out successfully!")
            elif choice == '7':
                self.running = False
                self.manager.save_data()
            else:
                self.ui.display_error_message("Invalid choice!")

    def handle_ai_assistant(self):
        """Interactive prompt with the simple AI assistant"""
        assistant = SimpleAIAssistant(lambda: list(self.manager.events.values()))
        self.ui.display_info_message("AI Assistant - nhập câu hỏi, gõ 'exit' để thoát")
        while True:
            q = input("🤖 Bạn hỏi: ").strip()
            if q.lower() in ("exit", "quit", "q"):
                break
            answer = assistant.answer(q)
            print(f"💬 {answer}")
    
    def handle_qr_checkin(self):
        """Handle QR code check-in"""
        self.ui.display_info_message("📱 QR Code Check-in")
        print("Nhập dữ liệu QR code (JSON format):")
        print("Ví dụ: {\"event_id\":\"...\", \"type\":\"event_checkin\"}")
        
        qr_data = input("QR Data: ").strip()
        
        if not qr_data:
            self.ui.display_error_message("Vui lòng nhập dữ liệu QR code!")
            return
        
        try:
            success = self.manager.scan_qr_checkin(qr_data)
            if success:
                self.ui.display_success_message("✅ Check-in thành công!")
            else:
                self.ui.display_error_message("❌ Check-in thất bại! Có thể bạn đã check-in rồi hoặc sự kiện đã đầy.")
        except Exception as e:
            self.ui.display_error_message(f"Lỗi: {e}")
    
    def handle_user_registration(self):
        """Handle user registration with mobile features"""
        self.ui.display_info_message("User Registration")
        
        user_types = ['admin', 'organizer', 'student']
        print(f"Available user types: {', '.join(user_types)}")
        
        user_type = input("Enter user type: ").strip().lower()
        if user_type not in user_types:
            self.ui.display_error_message("Invalid user type!")
            return
        
        name = input("Enter your name: ").strip()
        email = input("Enter your email: ").strip()
        phone = input("Enter your phone (optional): ").strip()
        
        if not name or not email:
            self.ui.display_error_message("Name and email are required!")
            return
        
        try:
            user_id = self.manager.register_user(user_type, name, email, phone)
            self.ui.display_success_message(f"User registered successfully! Your ID is: {user_id}")
        except Exception as e:
            self.ui.display_error_message(f"Registration failed: {e}")
    
    def handle_login(self):
        """Handle user login"""
        user_id = input("Enter your user ID: ").strip()
        
        if self.manager.login(user_id):
            self.ui.display_success_message("Login successful!")
        else:
            self.ui.display_error_message("Invalid user ID!")
    
    def handle_create_event(self):
        """Handle event creation with mobile features"""
        self.ui.display_info_message("Create New Event")
        
        try:
            name = input("Event name: ").strip()
            description = input("Event description: ").strip()
            date = input("Event date (YYYY-MM-DD): ").strip()
            time = input("Event time (HH:MM): ").strip()
            location = input("Event location: ").strip()
            capacity = int(input("Maximum capacity: ").strip())
            
            # Mobile features
            has_gps = input("Add GPS coordinates? (y/n): ").strip().lower() == 'y'
            lat = lon = None
            if has_gps:
                lat = float(input("Latitude: "))
                lon = float(input("Longitude: "))
            
            category = input("Event category (general/tech/sports/academic): ").strip() or "general"
            
            event_id = self.manager.create_event(name, description, date, time, location, capacity, lat, lon, category)
            self.ui.display_success_message(f"Event created successfully! Event ID: {event_id}")
            
        except ValueError as e:
            self.ui.display_error_message(f"Invalid input: {e}")
        except PermissionError as e:
            self.ui.display_error_message(f"Permission denied: {e}")
        except Exception as e:
            self.ui.display_error_message(f"Error creating event: {e}")
    
    def handle_search_events(self):
        """Handle event search"""
        query = input("Search query (leave empty for all): ").strip()
        date_filter = input("Filter by date (YYYY-MM-DD, leave empty for all): ").strip()
        
        try:
            # Simple search implementation
            events = list(self.manager.events.values())
            if query:
                events = [e for e in events if query.lower() in e.name.lower() or query.lower() in e.description.lower()]
            if date_filter:
                events = [e for e in events if e.date == date_filter]
            
            self.manager.display_events_with_ui(events)
                
        except Exception as e:
            self.ui.display_error_message(f"Error searching events: {e}")
    
    def handle_register_for_event(self):
        """Handle event registration"""
        events = list(self.manager.events.values())
        if not events:
            self.ui.display_info_message("No events available.")
            return
        
        self.ui.display_info_message("Available events:")
        for i, event in enumerate(events, 1):
            print(f"{i}. {event.name} - {event.date} at {event.time}")
        
        try:
            choice = int(input("Select event number: ")) - 1
            if 0 <= choice < len(events):
                event = events[choice]
                
                if self.manager.events[event.event_id].add_attendee(self.manager.current_user.user_id):
                    self.ui.display_success_message("Registration successful!")
                else:
                    self.ui.display_error_message("Registration failed!")
            else:
                self.ui.display_error_message("Invalid selection!")
                
        except (ValueError, IndexError):
            self.ui.display_error_message("Invalid input!")
    
    def handle_view_statistics(self):
        """Handle statistics display"""
        try:
            self.manager.display_statistics_with_ui()
        except Exception as e:
            self.ui.display_error_message(f"Error: {e}")
    
    def display_system_info(self):
        """Display system information"""
        self.ui.display_info_message("System Information")
        print(f"""
{Colors.CYAN}📊 SYSTEM INFO{Colors.END}
┌─────────────────────────┐
│ 🎓 Campus Event Manager │
│ 📱 Mobile-Ready         │
│ 🎨 Enhanced UI          │
│ 🔲 QR Code Support      │
│ 📍 GPS Location         │
│ 🚀 Advanced Features    │
└─────────────────────────┘
        """)

def test_complete_workflow():
    """Test complete workflow: QR Auto + GPS + Check-in"""
    print("🎓 TEST COMPLETE WORKFLOW IN MAIN SYSTEM")
    print("=" * 60)
    
    # Tạo manager
    manager = EnhancedEventManager()
    ui = EnhancedUI()
    
    print("\n📋 PHASE 1: TẠO HỆ THỐNG")
    print("-" * 40)
    
    # Tạo admin
    admin_id = manager.register_user("admin", "Admin User", "admin@university.edu")
    manager.login(admin_id)
    print(f"✅ Admin created: {admin_id}")
    
    # Tạo sự kiện với GPS
    event_id = manager.create_event(
        name="Python Workshop",
        description="Learn Python programming",
        date="2024-01-15",
        time="14:00-16:00",
        location="Room A101",
        max_capacity=50,  # Sửa từ capacity thành max_capacity
        latitude=10.762622,  # FPT University coordinates
        longitude=106.660172,
        category="tech"
    )
    print(f"✅ Event created: {event_id}")
    
    print("\n👤 PHASE 2: STUDENT ĐĂNG KÝ (QR TỰ ĐỘNG)")
    print("-" * 40)
    
    # Student đăng ký - QR sẽ được tạo tự động
    student_id = manager.register_user(
        user_type="student",
        name="Nguyen Van A",
        email="nguyenvana@university.edu",
        phone="0123456789"
    )
    print(f"✅ Student registered: {student_id}")
    print("✅ QR code tự động được tạo!")
    
    # Login student
    manager.login(student_id)
    student = manager.current_user
    print(f"👤 Student: {student.name}")
    print(f"📧 Email: {student.email}")
    print(f"🔑 Permissions: {student.get_permissions()}")
    
    print("\n📍 PHASE 3: SET GPS LOCATION")
    print("-" * 40)
    
    # Set GPS location cho student (simulate từ điện thoại)
    student_lat = 10.762800  # Gần sự kiện (trong bán kính 100m)
    student_lon = 106.660300
    student.set_location(student_lat, student_lon)
    print(f"📍 Student GPS: {student_lat}, {student_lon}")
    
    # Kiểm tra khoảng cách
    event = manager.events[event_id]
    distance = GPSLocation.calculate_distance(
        student_lat, student_lon,
        event.latitude, event.longitude
    )
    print(f"📏 Distance to event: {distance:.3f}km ({distance*1000:.0f}m)")
    
    if distance <= 0.1:  # 100m
        print("✅ Student is within 100m radius - GPS verification will PASS")
    else:
        print("❌ Student is outside 100m radius - GPS verification will FAIL")
    
    print("\n🔍 PHASE 4: TÌM SỰ KIỆN GẦN")
    print("-" * 40)
    
    # Tìm sự kiện gần
    nearby_events = manager.find_nearby_events(student_lat, student_lon, radius=1.0)
    print(f"📅 Found {len(nearby_events)} nearby events:")
    
    for i, item in enumerate(nearby_events, 1):
        event = item['event']
        distance = item['distance']
        print(f"  {i}. {event.name} - {distance:.3f}km away")
    
    print("\n📱 PHASE 5: MOBILE CHECK-IN")
    print("-" * 40)
    
    # Test check-in với GPS verification
    print("🔄 Attempting mobile check-in...")
    print(f"📍 Student GPS: {student_lat}, {student_lon}")
    print(f"📍 Event GPS: {event.latitude}, {event.longitude}")
    print(f"📏 Distance: {distance:.3f}km")
    
    try:
        # Mobile check-in với GPS
        check_in_result = manager.mobile_check_in(
            event_id=event_id,
            user_lat=student_lat,
            user_lon=student_lon
        )
        
        print("✅ CHECK-IN SUCCESSFUL!")
        print(f"🎯 Event: {event.name}")
        print(f"👤 Student: {student.name}")
        print(f"📍 GPS Verified: Yes")
        print(f"🔲 QR Verified: Yes")
        print(f"⏰ Timestamp: {check_in_result.get('timestamp', 'N/A')}")
        
    except Exception as e:
        print(f"❌ CHECK-IN FAILED: {e}")
        print("💡 Possible reasons:")
        print("   - Student not within 100m radius")
        print("   - Event at full capacity")
        print("   - Permission denied")
        print("   - QR code verification failed")
    
    print("\n📊 PHASE 6: VERIFICATION RESULTS")
    print("-" * 40)
    
    # Kiểm tra kết quả
    event_attendees = len(event.attendees)
    print(f"👥 Event attendees: {event_attendees}/{event.max_capacity}")
    print(f"📈 Capacity utilization: {(event_attendees/event.max_capacity)*100:.1f}%")
    
    if student.user_id in event.attendees:
        print("✅ Student successfully registered for event")
    else:
        print("❌ Student not registered for event")
    
    print("\n🎯 WORKFLOW SUMMARY")
    print("-" * 40)
    print("✅ Student registration with auto QR generation")
    print("✅ GPS location setting")
    print("✅ Nearby events discovery")
    print("✅ QR code verification")
    print("✅ GPS verification (100m radius)")
    print("✅ Mobile check-in process")
    print("✅ Event attendance tracking")
    
    print("\n🚀 WORKFLOW COMPLETED SUCCESSFULLY!")
    print("All features working: QR Auto + GPS + Check-in")
    
    return True

def main():
    """Enhanced main function"""
    system = EnhancedEventManagementSystem()
    system.run()

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        # Chạy test workflow
        test_complete_workflow()
    else:
        # Chạy hệ thống bình thường
        main()










