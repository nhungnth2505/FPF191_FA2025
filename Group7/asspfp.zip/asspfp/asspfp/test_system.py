"""
Test script for Campus Event Management System
Demonstrates key functionality and features
"""

from ass import EventManager, Admin, EventOrganizer, Student, Visitor
import json
import os

def test_system():
    """Test the event management system functionality"""
    print("="*60)
    print("CAMPUS EVENT MANAGEMENT SYSTEM - TEST DEMONSTRATION")
    print("="*60)
    
    # Initialize the system
    manager = EventManager()
    
    print("\n1. REGISTERING USERS")
    print("-" * 30)
    
    # Register different user types
    admin_id = manager.register_user('admin', 'John Admin', 'admin@campus.edu')
    organizer_id = manager.register_user('organizer', 'Jane Organizer', 'organizer@campus.edu')
    student_id = manager.register_user('student', 'Bob Student', 'student@campus.edu')
    visitor_id = manager.register_user('visitor', 'Alice Visitor', 'visitor@campus.edu')
    
    print(f"Admin ID: {admin_id}")
    print(f"Organizer ID: {organizer_id}")
    print(f"Student ID: {student_id}")
    print(f"Visitor ID: {visitor_id}")
    
    print("\n2. LOGIN AS ADMIN")
    print("-" * 25)
    manager.login(admin_id)
    print(f"Logged in as: {manager.current_user}")
    print(f"Permissions: {manager.current_user.get_permissions()}")
    
    print("\n3. CREATING EVENTS")
    print("-" * 20)
    
    # Create events as admin
    event1_id = manager.create_event(
        "Python Programming Workshop",
        "Learn Python basics and advanced concepts",
        "2024-12-15",
        "14:00",
        "Computer Lab A",
        30
    )
    print(f"Created event 1: {event1_id}")
    
    event2_id = manager.create_event(
        "Data Science Seminar",
        "Introduction to data science and machine learning",
        "2024-12-20",
        "10:00",
        "Conference Room B",
        50
    )
    print(f"Created event 2: {event2_id}")
    
    event3_id = manager.create_event(
        "Web Development Bootcamp",
        "Full-stack web development course",
        "2024-12-25",
        "09:00",
        "Tech Center",
        25
    )
    print(f"Created event 3: {event3_id}")
    
    print("\n4. LOGIN AS STUDENT")
    print("-" * 25)
    manager.login(student_id)
    print(f"Logged in as: {manager.current_user}")
    
    print("\n5. SEARCHING EVENTS")
    print("-" * 20)
    events = manager.search_events("Python")
    print(f"Found {len(events)} event(s) matching 'Python':")
    for event in events:
        print(f"  - {event}")
    
    print("\n6. REGISTERING FOR EVENTS")
    print("-" * 30)
    
    # Register student for events
    try:
        manager.register_attendee(event1_id, student_id)
        print("✓ Successfully registered for Python Workshop")
    except Exception as e:
        print(f"✗ Registration failed: {e}")
    
    try:
        manager.register_attendee(event2_id, student_id)
        print("✓ Successfully registered for Data Science Seminar")
    except Exception as e:
        print(f"✗ Registration failed: {e}")
    
    print("\n7. LOGIN AS VISITOR")
    print("-" * 25)
    manager.login(visitor_id)
    print(f"Logged in as: {manager.current_user}")
    
    # Register visitor for an event
    try:
        manager.register_attendee(event3_id, visitor_id)
        print("✓ Visitor successfully registered for Web Development Bootcamp")
    except Exception as e:
        print(f"✗ Registration failed: {e}")
    
    print("\n8. LOGIN AS ADMIN - VIEW STATISTICS")
    print("-" * 40)
    manager.login(admin_id)
    
    stats = manager.get_statistics()
    print("System Statistics:")
    print(f"  Total Events: {stats['total_events']}")
    print(f"  Total Attendees: {stats['total_attendees']}")
    print(f"  Average Attendance: {stats['average_attendance']}")
    print(f"  Highest Attendance: {stats['highest_attendance']}")
    print(f"  Lowest Attendance: {stats['lowest_attendance']}")
    
    print("\n9. EXPORT DATA TO CSV")
    print("-" * 25)
    try:
        manager.export_to_csv("test_event_report.csv")
        print("✓ Data exported to test_event_report.csv")
    except Exception as e:
        print(f"✗ Export failed: {e}")
    
    print("\n10. VIEW ALL EVENTS")
    print("-" * 20)
    # Admin has permission to view all events
    all_events = manager.search_events()
    print(f"All events in system ({len(all_events)}):")
    for i, event in enumerate(all_events, 1):
        print(f"  {i}. {event}")
        print(f"     Location: {event.location}")
        print(f"     Attendees: {event.get_attendance_count()}/{event.max_capacity}")
        print(f"     Available spots: {event.get_available_spots()}")
        print()
    
    print("\n11. TESTING CAPACITY LIMITS")
    print("-" * 30)
    
    # Try to register more students for the small event
    print("Attempting to register 30 students for Web Development Bootcamp (capacity: 25)...")
    for i in range(30):
        try:
            # Create temporary student IDs
            temp_student_id = f"temp_student_{i}"
            manager.users[temp_student_id] = Student(temp_student_id, f"Student {i}", f"student{i}@test.com")
            manager.register_attendee(event3_id, temp_student_id)
            if i < 5:  # Only show first few successes
                print(f"  ✓ Registered student {i+1}")
        except Exception as e:
            if i == 25:  # Show when capacity is reached
                print(f"  ✗ Registration {i+1} failed: {e}")
            break
    
    # Check final statistics
    final_stats = manager.get_statistics()
    print(f"\nFinal Statistics:")
    print(f"  Total Attendees: {final_stats['total_attendees']}")
    
    print("\n12. DATA PERSISTENCE TEST")
    print("-" * 30)
    
    # Save data
    manager.save_data()
    print("✓ Data saved to event_data.json")
    
    # Check if file exists
    if os.path.exists("event_data.json"):
        print("✓ Data file created successfully")
        
        # Load and display file size
        with open("event_data.json", 'r') as f:
            data = json.load(f)
        print(f"✓ File contains {len(data.get('events', []))} events")
    
    print("\n" + "="*60)
    print("TEST COMPLETED SUCCESSFULLY!")
    print("="*60)
    print("\nKey Features Demonstrated:")
    print("✓ Role-based access control")
    print("✓ Event creation and management")
    print("✓ Attendee registration with capacity checks")
    print("✓ Search functionality")
    print("✓ Statistics and reporting")
    print("✓ Data persistence (JSON)")
    print("✓ CSV export functionality")
    print("✓ Input validation and error handling")
    print("✓ Permission-based operations")
    
    print(f"\nGenerated Files:")
    print(f"  - event_data.json (main data storage)")
    print(f"  - test_event_report.csv (exported report)")
    
    print(f"\nTo run the full interactive system:")
    print(f"  python ass.py")

if __name__ == "__main__":
    test_system()
