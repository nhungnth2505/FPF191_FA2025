# Hướng dẫn Test Tính năng Admin

## Vấn đề đã được sửa:

### 1. ✅ Phân quyền Admin
- **Trước**: Chỉ `EnhancedAdmin` mới có quyền edit/delete events
- **Sau**: Cả `Admin` và `EnhancedAdmin` đều có quyền edit/delete events

### 2. ✅ Truy cập Dashboard
- **Trước**: Chỉ `EnhancedAdmin` và `EnhancedEventOrganizer` mới truy cập được dashboard
- **Sau**: Cả `Admin`, `EnhancedAdmin`, `EventOrganizer`, `EnhancedEventOrganizer` đều truy cập được

### 3. ✅ Tạo sự kiện
- **Trước**: Chỉ kiểm tra permissions, không kiểm tra role trực tiếp
- **Sau**: Kiểm tra cả permissions và role để đảm bảo Admin có thể tạo sự kiện

### 4. ✅ Hiển thị nút Edit/Delete
- **Trước**: Template chỉ hiển thị nút cho `EnhancedAdmin`
- **Sau**: Template hiển thị nút cho cả `Admin` và `EnhancedAdmin`

## Cách Test:

### Bước 1: Tạo Admin Account
1. Truy cập: `http://localhost:5000/create-admin`
2. Copy Admin ID được tạo

### Bước 2: Đăng nhập với Admin
1. Truy cập: `http://localhost:5000/login`
2. Nhập Admin ID
3. Kiểm tra redirect đến dashboard (không phải events)

### Bước 3: Test Dashboard
1. Kiểm tra có thể truy cập dashboard
2. Kiểm tra hiển thị thống kê và charts

### Bước 4: Test Xem Sự kiện
1. Truy cập: `http://localhost:5000/events`
2. Kiểm tra có nút "Tạo sự kiện mới"
3. Kiểm tra có nút Edit (✏️) và Delete (🗑️) cho mỗi sự kiện

### Bước 5: Test Tạo Sự kiện
1. Click "Tạo sự kiện mới"
2. Điền thông tin sự kiện
3. Submit và kiểm tra tạo thành công

### Bước 6: Test Edit Sự kiện
1. Click nút Edit (✏️) trên một sự kiện
2. Sửa thông tin
3. Submit và kiểm tra cập nhật thành công

### Bước 7: Test Delete Sự kiện
1. Click nút Delete (🗑️) trên một sự kiện
2. Xác nhận xóa
3. Kiểm tra sự kiện đã bị xóa

## Kết quả mong đợi:

✅ **Admin có thể:**
- Đăng nhập và được redirect đến dashboard
- Truy cập dashboard và xem thống kê
- Xem danh sách tất cả sự kiện
- Tạo sự kiện mới
- Edit bất kỳ sự kiện nào
- Delete bất kỳ sự kiện nào

❌ **Admin KHÔNG thể:**
- Truy cập các trang chỉ dành cho sinh viên
- Thực hiện các hành động không có quyền

## Debug Information:

Nếu có lỗi, kiểm tra:
1. Console logs trong browser (F12)
2. Terminal logs của Flask app
3. Session data: `session.user_role` phải là `Admin` hoặc `EnhancedAdmin`
4. Event manager permissions

## Files đã được sửa:

1. `app.py` - Logic phân quyền
2. `templates/events.html` - Hiển thị nút edit/delete
3. `templates/dashboard.html` - Đã có sẵn, không cần sửa

## Test với các Role khác:

- **Student**: Chỉ xem events, không có nút edit/delete
- **EventOrganizer**: Có thể tạo/edit events của mình, không delete được events của người khác
- **Admin**: Có thể làm tất cả (create/edit/delete mọi events)

