# 🤖 AI Assistant Demo Guide

## 📋 Hướng dẫn Demo AI Assistant từ A-Z

### 🚀 Bước 1: Khởi động hệ thống
```bash
python enhanced_ass.py
```

### 🔐 Bước 2: Đăng nhập
**Chọn role để test:**
- **Admin**: `admin` / `admin123` (có thể tạo sự kiện)
- **Student**: `student1` / `student123` (có thể đăng ký sự kiện)
- **Organizer**: `organizer1` / `organizer123` (có thể tạo sự kiện)

### 🎯 Bước 3: Chọn AI Assistant
- Chọn **option 4** từ menu chính
- Gõ `exit` để thoát AI Assistant

---

## 🧪 Test Cases - Copy & Paste

### 📝 **1. FAQ - Câu hỏi thường gặp**
```
cách đăng kí
```
**Kết quả mong đợi:** "Vào Student menu → Register for Event, chọn sự kiện và xác nhận."

```
tạo sự kiện
```
**Kết quả mong đợi:** "Đăng nhập Admin/Organizer → Create Event và điền thông tin cần thiết."

```
bao nhiêu chỗ
```
**Kết quả mong đợi:** "Mỗi thẻ sự kiện hiển thị 'Capacity: hiện_tại/tối_đa' ngay trong danh sách."

```
Python Workshop bao nhiêu chỗ
```
**Kết quả mong đợi:** "Sự kiện 'Python Workshop' có X/Y chỗ (còn Z chỗ trống)."

### 🔍 **2. Tìm kiếm sự kiện**
```
su kien
```
**Kết quả mong đợi:** Danh sách tất cả sự kiện (nếu có)

```
workshop
```
**Kết quả mong đợi:** Sự kiện có từ "workshop" trong tên/mô tả

```
tech
```
**Kết quả mong đợi:** Sự kiện liên quan đến công nghệ

```
seminar
```
**Kết quả mong đợi:** Sự kiện seminar

### 💡 **3. Gợi ý sự kiện**
```
gợi ý
```
**Kết quả mong đợi:** 3 sự kiện tốt nhất (còn chỗ, sắp diễn ra)

```
gợi ý workshop
```
**Kết quả mong đợi:** Gợi ý workshop cụ thể

```
gợi ý tech
```
**Kết quả mong đợi:** Gợi ý sự kiện công nghệ

### 📅 **4. Lịch trình**
```
hôm nay
```
**Kết quả mong đợi:** Sự kiện hôm nay

```
tuần này
```
**Kết quả mong đợi:** Sự kiện trong tuần này

```
tuần sau
```
**Kết quả mong đợi:** Sự kiện tuần sau

```
ngày 2025-12-16
```
**Kết quả mong đợi:** Sự kiện ngày cụ thể

### 👋 **5. Chào hỏi**
```
hello
```
**Kết quả mong đợi:** "Xin chào! Tôi là AI Assistant của hệ thống quản lý sự kiện..."

```
hi
```
**Kết quả mong đợi:** Lời chào và hướng dẫn sử dụng

```
xin chao
```
**Kết quả mong đợi:** Lời chào và hướng dẫn sử dụng

### ❓ **6. Câu hỏi không hiểu**

```
xyz
```
**Kết quả mong đợi:** Hướng dẫn sử dụng AI

---

## 🎬 Demo Script - Thuyết trình

### **Phần 1: Giới thiệu AI Assistant**
> "Đây là AI Assistant được tích hợp vào hệ thống quản lý sự kiện. AI có thể trả lời câu hỏi, gợi ý sự kiện và tìm kiếm thông tin."

### **Phần 2: Demo FAQ**
> "AI có thể trả lời các câu hỏi thường gặp như cách đăng ký sự kiện..."
- Nhập: `cách đăng kí`
- Kết quả: Hướng dẫn cụ thể

### **Phần 3: Demo tìm kiếm**
> "AI có thể tìm kiếm sự kiện theo từ khóa..."
- Nhập: `workshop`
- Kết quả: Danh sách workshop

### **Phần 4: Demo gợi ý**
> "AI có thể gợi ý sự kiện phù hợp..."
- Nhập: `gợi ý`
- Kết quả: 3 sự kiện tốt nhất

### **Phần 5: Demo lịch trình**
> "AI có thể tìm sự kiện theo thời gian..."
- Nhập: `hôm nay`
- Kết quả: Sự kiện hôm nay

---

## 🛠️ Troubleshooting

### **Nếu AI trả về "Không tìm thấy sự kiện":**
1. Kiểm tra có sự kiện trong hệ thống không
2. Tạo sự kiện mới với Admin/Organizer
3. Hoặc chạy test tự động: `python enhanced_ass.py test`

### **Nếu AI không hiểu câu hỏi:**
1. Thử câu hỏi đơn giản hơn
2. Sử dụng từ khóa tiếng Việt không dấu
3. Xem hướng dẫn sử dụng AI hiển thị

### **Nếu muốn test với dữ liệu mẫu:**
```bash
python enhanced_ass.py test
```
Sẽ tạo sự kiện mẫu để test AI.

---

## 📊 Kết quả Demo thành công

✅ **AI trả lời FAQ chính xác**  
✅ **AI tìm kiếm sự kiện theo từ khóa**  
✅ **AI gợi ý sự kiện phù hợp**  
✅ **AI hiểu ngày tháng tương đối**  
✅ **AI xử lý câu hỏi không hiểu một cách thân thiện**  

---

## 🎯 Tips Demo

1. **Chuẩn bị trước:** Tạo 2-3 sự kiện mẫu để demo
2. **Thứ tự demo:** FAQ → Tìm kiếm → Gợi ý → Lịch trình
3. **Giải thích:** Mỗi lần demo, giải thích AI đang làm gì
4. **Tương tác:** Hỏi khán giả muốn test câu hỏi gì
5. **Kết thúc:** Nhấn mạnh AI hoạt động offline, không cần internet

**Chúc bạn demo thành công! 🚀**
