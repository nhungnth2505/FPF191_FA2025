"""
Campus Event Management System with Role-Based Access
====================================================

A comprehensive event management system that supports:
- Role-based access control (Admin, Event Organizer, Student/Visitor)
- Event creation, management, and capacity tracking
- Attendee registration with duplicate prevention
- Data persistence and statistical reporting
- Input validation and error handling

Author: Student
Date: 2024
"""

import json
import csv
import os
from datetime import datetime, date
from typing import List, Dict, Optional, Tuple
from abc import ABC, abstractmethod
import uuid


class User(ABC):
    """Abstract base class for all user types"""
    
    def __init__(self, user_id: str, name: str, email: str):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.role = self.__class__.__name__
    
    @abstractmethod
    def get_permissions(self) -> List[str]:
        """Return list of permissions for this user role"""
        pass
    
    def has_permission(self, permission: str) -> bool:
        """Check if user has a specific permission"""
        return permission in self.get_permissions()
    
    def __str__(self):
        return f"{self.role}: {self.name} ({self.email})"


class Admin(User):
    """Admin user with full system access"""
    
    def get_permissions(self) -> List[str]:
        return [
            "create_event", "update_event", "delete_event", "view_all_events",
            "view_all_attendees", "manage_users", "view_statistics", "export_data",
            "search_events", "register_for_events", "view_registered_events", "view_event_details"
        ]


class EventOrganizer(User):
    """Event organizer with limited event management access"""
    
    def __init__(self, user_id: str, name: str, email: str):
        super().__init__(user_id, name, email)
        self.managed_events: List[str] = []  # List of event IDs they manage
    
    def get_permissions(self) -> List[str]:
        return [
            "view_managed_events", "manage_attendees", "view_event_details",
            "register_attendees", "view_statistics"
        ]
    
    def add_managed_event(self, event_id: str):
        """Add an event to the organizer's managed events"""
        if event_id not in self.managed_events:
            self.managed_events.append(event_id)


class Student(User):
    """Student user with basic event access"""
    
    def get_permissions(self) -> List[str]:
        return [
            "search_events", "register_for_events", "view_registered_events",
            "view_event_details"
        ]


class Visitor(User):
    """Visitor user with basic event access"""
    
    def get_permissions(self) -> List[str]:
        return [
            "search_events", "register_for_events", "view_registered_events",
            "view_event_details"
        ]


class Event:
    """Represents a campus event"""
    
    def __init__(self, event_id: str, name: str, description: str, date: str, 
                 time: str, location: str, max_capacity: int, organizer_id: str):
        self.event_id = event_id
        self.name = name
        self.description = description
        self.date = date
        self.time = time
        self.location = location
        self.max_capacity = max_capacity
        self.organizer_id = organizer_id
        self.attendees: List[str] = []  # List of user IDs
        self.created_at = datetime.now().isoformat()
    
    def add_attendee(self, user_id: str) -> bool:
        """Add attendee if capacity allows"""
        if len(self.attendees) < self.max_capacity and user_id not in self.attendees:
            self.attendees.append(user_id)
            return True
        return False
    
    def remove_attendee(self, user_id: str) -> bool:
        """Remove attendee from event"""
        if user_id in self.attendees:
            self.attendees.remove(user_id)
            return True
        return False
    
    def get_attendance_count(self) -> int:
        """Get current number of attendees"""
        return len(self.attendees)
    
    def is_full(self) -> bool:
        """Check if event is at capacity"""
        return len(self.attendees) >= self.max_capacity
    
    def get_available_spots(self) -> int:
        """Get number of available spots"""
        return max(0, self.max_capacity - len(self.attendees))
    
    def to_dict(self) -> Dict:
        """Convert event to dictionary for serialization"""
        return {
            'event_id': self.event_id,
            'name': self.name,
            'description': self.description,
            'date': self.date,
            'time': self.time,
            'location': self.location,
            'max_capacity': self.max_capacity,
            'organizer_id': self.organizer_id,
            'attendees': self.attendees,
            'created_at': self.created_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Event':
        """Create event from dictionary"""
        event = cls(
            data['event_id'], data['name'], data['description'],
            data['date'], data['time'], data['location'],
            data['max_capacity'], data['organizer_id']
        )
        event.attendees = data.get('attendees', [])
        event.created_at = data.get('created_at', datetime.now().isoformat())
        return event
    
    def __str__(self):
        return f"{self.name} - {self.date} at {self.time} ({self.get_attendance_count()}/{self.max_capacity})"


class EventManager:
    """Main system manager for events and users"""
    
    def __init__(self):
        self.events: Dict[str, Event] = {}
        self.users: Dict[str, User] = {}
        self.current_user: Optional[User] = None
        self.data_file = "event_data.json"
        self.load_data()
    
    def load_data(self):
        """Load data from JSON file"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                
                # Load events
                for event_data in data.get('events', []):
                    event = Event.from_dict(event_data)
                    self.events[event.event_id] = event

                # Load users with proper deserialization so login works after restart
                users_data = data.get('users', {})
                for user_id, u in users_data.items():
                    role = u.get('role')
                    name = u.get('name', '')
                    email = u.get('email', '')
                    if role == 'Admin':
                        self.users[user_id] = Admin(user_id, name, email)
                    elif role == 'EventOrganizer':
                        self.users[user_id] = EventOrganizer(user_id, name, email)
                    elif role == 'Student':
                        self.users[user_id] = Student(user_id, name, email)
                    elif role == 'Visitor':
                        self.users[user_id] = Visitor(user_id, name, email)

                # Rebuild organizer managed events from ownership
                for event in self.events.values():
                    organizer = self.users.get(event.organizer_id)
                    if isinstance(organizer, EventOrganizer):
                        organizer.add_managed_event(event.event_id)

                print("Data loaded successfully!")
            except Exception as e:
                print(f"Error loading data: {e}")
    
    def save_data(self):
        """Save data to JSON file"""
        try:
            data = {
                'events': [event.to_dict() for event in self.events.values()],
                'users': {
                    user_id: {
                        'name': user.name,
                        'email': user.email,
                        'role': user.role,
                        # persist managed_events for organizers (optional)
                        'managed_events': getattr(user, 'managed_events', None)
                    }
                    for user_id, user in self.users.items()
                }
            }
            with open(self.data_file, 'w') as f:
                json.dump(data, f, indent=2)
            print("Data saved successfully!")
        except Exception as e:
            print(f"Error saving data: {e}")
    
    def register_user(self, user_type: str, name: str, email: str) -> str:
        """Register a new user"""
        user_id = str(uuid.uuid4())
        
        if user_type.lower() == 'admin':
            user = Admin(user_id, name, email)
        elif user_type.lower() == 'organizer':
            user = EventOrganizer(user_id, name, email)
        elif user_type.lower() == 'student':
            user = Student(user_id, name, email)
        elif user_type.lower() == 'visitor':
            user = Visitor(user_id, name, email)
        else:
            raise ValueError("Invalid user type")
        
        self.users[user_id] = user
        return user_id
    
    def login(self, user_id: str) -> bool:
        """Login user by ID"""
        if user_id in self.users:
            self.current_user = self.users[user_id]
            return True
        return False
    
    def create_event(self, name: str, description: str, date: str, time: str, 
                    location: str, max_capacity: int) -> str:
        """Create a new event"""
        if not self.current_user or not self.current_user.has_permission("create_event"):
            raise PermissionError("You don't have permission to create events")
        
        # Input validation
        if not name or not description or not date or not time or not location:
            raise ValueError("All fields are required")
        
        if max_capacity <= 0:
            raise ValueError("Capacity must be positive")
        
        # Validate date format
        try:
            datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Date must be in YYYY-MM-DD format")
        
        event_id = str(uuid.uuid4())
        event = Event(event_id, name, description, date, time, location, 
                     max_capacity, self.current_user.user_id)
        
        self.events[event_id] = event
        
        # If current user is organizer, add to their managed events
        if isinstance(self.current_user, EventOrganizer):
            self.current_user.add_managed_event(event_id)
        
        return event_id
    
    def update_event(self, event_id: str, **kwargs) -> bool:
        """Update event details"""
        if not self.current_user:
            raise PermissionError("You must be logged in")
        
        if event_id not in self.events:
            raise ValueError("Event not found")
        
        event = self.events[event_id]
        
        # Check permissions
        can_edit = (self.current_user.has_permission("update_event") or 
                   (isinstance(self.current_user, EventOrganizer) and 
                    event_id in self.current_user.managed_events))
        
        if not can_edit:
            raise PermissionError("You don't have permission to edit this event")
        
        # Update allowed fields
        allowed_fields = ['name', 'description', 'date', 'time', 'location', 'max_capacity']
        for field, value in kwargs.items():
            if field in allowed_fields and value is not None:
                setattr(event, field, value)
        
        return True
    
    def delete_event(self, event_id: str) -> bool:
        """Delete an event"""
        if not self.current_user or not self.current_user.has_permission("delete_event"):
            raise PermissionError("You don't have permission to delete events")
        
        if event_id in self.events:
            del self.events[event_id]
            return True
        return False
    
    def register_attendee(self, event_id: str, user_id: str) -> bool:
        """Register a user for an event"""
        if event_id not in self.events:
            raise ValueError("Event not found")
        
        if user_id not in self.users:
            raise ValueError("User not found")
        
        event = self.events[event_id]
        
        # Check if user is already registered
        if user_id in event.attendees:
            raise ValueError("User is already registered for this event")
        
        # Check capacity
        if event.is_full():
            raise ValueError("Event is at full capacity")
        
        return event.add_attendee(user_id)
    
    def unregister_attendee(self, event_id: str, user_id: str) -> bool:
        """Unregister a user from an event"""
        if event_id not in self.events:
            raise ValueError("Event not found")
        
        event = self.events[event_id]
        return event.remove_attendee(user_id)
    
    def search_events(self, query: str = "", date_filter: str = None) -> List[Event]:
        """Search events by name or description"""
        if not self.current_user or not self.current_user.has_permission("search_events"):
            raise PermissionError("You don't have permission to search events")
        
        results = []
        query_lower = query.lower()
        
        for event in self.events.values():
            # Text search
            if (query_lower in event.name.lower() or 
                query_lower in event.description.lower()):
                
                # Date filter
                if date_filter:
                    if event.date == date_filter:
                        results.append(event)
                else:
                    results.append(event)
        
        return results
    
    def get_user_events(self, user_id: str) -> List[Event]:
        """Get events a user is registered for"""
        user_events = []
        for event in self.events.values():
            if user_id in event.attendees:
                user_events.append(event)
        return user_events
    
    def get_statistics(self) -> Dict:
        """Get system statistics"""
        if not self.current_user or not self.current_user.has_permission("view_statistics"):
            raise PermissionError("You don't have permission to view statistics")
        
        total_attendees = sum(len(event.attendees) for event in self.events.values())
        total_events = len(self.events)
        
        if not self.events:
            return {
                'total_events': 0,
                'total_attendees': 0,
                'highest_attendance': None,
                'lowest_attendance': None,
                'average_attendance': 0
            }
        
        attendance_counts = [len(event.attendees) for event in self.events.values()]
        highest = max(attendance_counts)
        lowest = min(attendance_counts)
        average = total_attendees / total_events
        
        # Find events with highest and lowest attendance
        highest_event = None
        lowest_event = None
        
        for event in self.events.values():
            if len(event.attendees) == highest:
                highest_event = event.name
            if len(event.attendees) == lowest:
                lowest_event = event.name
        
        return {
            'total_events': total_events,
            'total_attendees': total_attendees,
            'highest_attendance': highest_event,
            'lowest_attendance': lowest_event,
            'average_attendance': round(average, 2)
        }
    
    def export_to_csv(self, filename: str = "event_report.csv"):
        """Export event data to CSV"""
        if not self.current_user or not self.current_user.has_permission("export_data"):
            raise PermissionError("You don't have permission to export data")
        
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                
                # Write header
                writer.writerow([
                    'Event ID', 'Event Name', 'Date', 'Time', 'Location', 
                    'Max Capacity', 'Current Attendance', 'Organizer ID'
                ])
                
                # Write event data
                for event in self.events.values():
                    writer.writerow([
                        event.event_id, event.name, event.date, event.time,
                        event.location, event.max_capacity, len(event.attendees),
                        event.organizer_id
                    ])
            
            print(f"Data exported to {filename}")
            return True
        except Exception as e:
            print(f"Error exporting data: {e}")
            return False


class EventManagementSystem:
    """Main application interface"""
    
    def __init__(self):
        self.manager = EventManager()
        self.running = True
    
    def display_menu(self):
        """Display main menu based on user role"""
        if not self.manager.current_user:
            print("\n" + "="*50)
            print("CAMPUS EVENT MANAGEMENT SYSTEM")
            print("="*50)
            print("1. Register new user")
            print("2. Login")
            print("3. Exit")
            return
        
        user = self.manager.current_user
        print(f"\nWelcome, {user.name} ({user.role})")
        print("="*50)
        
        if isinstance(user, Admin):
            self.display_admin_menu()
        elif isinstance(user, EventOrganizer):
            self.display_organizer_menu()
        else:  # Student or Visitor
            self.display_student_menu()
    
    def display_admin_menu(self):
        """Display admin menu"""
        print("ADMIN MENU:")
        print("1. Create Event")
        print("2. Update Event")
        print("3. Delete Event")
        print("4. View All Events")
        print("5. View Statistics")
        print("6. Export Data")
        print("7. Logout")
        print("8. Exit")
    
    def display_organizer_menu(self):
        """Display organizer menu"""
        print("EVENT ORGANIZER MENU:")
        print("1. Create Event")
        print("2. View My Events")
        print("3. Manage Attendees")
        print("4. View Event Details")
        print("5. View Statistics")
        print("6. Logout")
        print("7. Exit")
    
    def display_student_menu(self):
        """Display student/visitor menu"""
        print("STUDENT/VISITOR MENU:")
        print("1. Search Events")
        print("2. Register for Event")
        print("3. View My Events")
        print("4. View Event Details")
        print("5. Logout")
        print("6. Exit")
    
    def handle_user_registration(self):
        """Handle user registration"""
        print("\nUser Registration")
        print("-" * 20)
        
        user_types = ['admin', 'organizer', 'student', 'visitor']
        print("Available user types:", ", ".join(user_types))
        
        user_type = input("Enter user type: ").strip().lower()
        if user_type not in user_types:
            print("Invalid user type!")
            return
        
        name = input("Enter your name: ").strip()
        email = input("Enter your email: ").strip()
        
        if not name or not email:
            print("Name and email are required!")
            return
        
        try:
            user_id = self.manager.register_user(user_type, name, email)
            print(f"User registered successfully! Your ID is: {user_id}")
            print("Please save this ID for login.")
        except Exception as e:
            print(f"Registration failed: {e}")
    
    def handle_login(self):
        """Handle user login"""
        print("\nLogin")
        print("-" * 10)
        
        user_id = input("Enter your user ID: ").strip()
        
        if self.manager.login(user_id):
            print("Login successful!")
        else:
            print("Invalid user ID!")
    
    def handle_create_event(self):
        """Handle event creation"""
        print("\nCreate New Event")
        print("-" * 20)
        
        try:
            name = input("Event name: ").strip()
            description = input("Event description: ").strip()
            date = input("Event date (YYYY-MM-DD): ").strip()
            time = input("Event time (HH:MM): ").strip()
            location = input("Event location: ").strip()
            capacity = int(input("Maximum capacity: ").strip())
            
            event_id = self.manager.create_event(name, description, date, time, location, capacity)
            print(f"Event created successfully! Event ID: {event_id}")
            
        except ValueError as e:
            print(f"Invalid input: {e}")
        except PermissionError as e:
            print(f"Permission denied: {e}")
        except Exception as e:
            print(f"Error creating event: {e}")
    
    def handle_search_events(self):
        """Handle event search"""
        print("\nSearch Events")
        print("-" * 15)
        
        query = input("Search query (leave empty for all): ").strip()
        date_filter = input("Filter by date (YYYY-MM-DD, leave empty for all): ").strip()
        
        try:
            events = self.manager.search_events(query, date_filter if date_filter else None)
            
            if not events:
                print("No events found.")
                return
            
            print(f"\nFound {len(events)} event(s):")
            for i, event in enumerate(events, 1):
                print(f"{i}. {event}")
                print(f"   Location: {event.location}")
                print(f"   Available spots: {event.get_available_spots()}")
                print()
                
        except PermissionError as e:
            print(f"Permission denied: {e}")
        except Exception as e:
            print(f"Error searching events: {e}")
    
    def handle_register_for_event(self):
        """Handle event registration"""
        print("\nRegister for Event")
        print("-" * 20)
        
        # First show available events
        try:
            events = self.manager.search_events()
            if not events:
                print("No events available.")
                return
            
            print("Available events:")
            for i, event in enumerate(events, 1):
                print(f"{i}. {event}")
            
            choice = int(input("Select event number: ").strip()) - 1
            if 0 <= choice < len(events):
                event = events[choice]
                
                if self.manager.register_attendee(event.event_id, self.manager.current_user.user_id):
                    print("Registration successful!")
                else:
                    print("Registration failed!")
            else:
                print("Invalid selection!")
                
        except (ValueError, IndexError):
            print("Invalid input!")
        except Exception as e:
            print(f"Error: {e}")
    
    def handle_view_statistics(self):
        """Handle statistics display"""
        print("\nSystem Statistics")
        print("-" * 20)
        
        try:
            stats = self.manager.get_statistics()
            
            print(f"Total Events: {stats['total_events']}")
            print(f"Total Attendees: {stats['total_attendees']}")
            print(f"Average Attendance: {stats['average_attendance']}")
            
            if stats['highest_attendance']:
                print(f"Highest Attendance: {stats['highest_attendance']}")
            if stats['lowest_attendance']:
                print(f"Lowest Attendance: {stats['lowest_attendance']}")
                
        except PermissionError as e:
            print(f"Permission denied: {e}")
        except Exception as e:
            print(f"Error: {e}")
    
    def handle_export_data(self):
        """Handle data export"""
        filename = input("Enter filename for export (default: event_report.csv): ").strip()
        if not filename:
            filename = "event_report.csv"
        
        if not filename.endswith('.csv'):
            filename += '.csv'
        
        self.manager.export_to_csv(filename)
    
    def run(self):
        """Main application loop"""
        print("Welcome to Campus Event Management System!")
        
        while self.running:
            try:
                self.display_menu()
                choice = input("\nEnter your choice: ").strip()
                
                if not self.manager.current_user:
                    self.handle_guest_choice(choice)
                else:
                    self.handle_authenticated_choice(choice)
                    
            except KeyboardInterrupt:
                print("\nExiting...")
                self.manager.save_data()
                break
            except Exception as e:
                print(f"An error occurred: {e}")
    
    def handle_guest_choice(self, choice: str):
        """Handle choices for non-authenticated users"""
        if choice == '1':
            self.handle_user_registration()
        elif choice == '2':
            self.handle_login()
        elif choice == '3':
            self.running = False
            self.manager.save_data()
        else:
            print("Invalid choice!")
    
    def handle_authenticated_choice(self, choice: str):
        """Handle choices for authenticated users"""
        user = self.manager.current_user
        
        if isinstance(user, Admin):
            self.handle_admin_choice(choice)
        elif isinstance(user, EventOrganizer):
            self.handle_organizer_choice(choice)
        else:  # Student or Visitor
            self.handle_student_choice(choice)
    
    def handle_admin_choice(self, choice: str):
        """Handle admin choices"""
        if choice == '1':
            self.handle_create_event()
        elif choice == '2':
            print("Update Event - Feature to be implemented")
        elif choice == '3':
            print("Delete Event - Feature to be implemented")
        elif choice == '4':
            self.handle_search_events()
        elif choice == '5':
            self.handle_view_statistics()
        elif choice == '6':
            self.handle_export_data()
        elif choice == '7':
            self.manager.current_user = None
            print("Logged out successfully!")
        elif choice == '8':
            self.running = False
            self.manager.save_data()
        else:
            print("Invalid choice!")
    
    def handle_organizer_choice(self, choice: str):
        """Handle organizer choices"""
        if choice == '1':
            self.handle_create_event()
        elif choice == '2':
            # List events managed by this organizer
            organizer = self.manager.current_user
            managed = []
            if isinstance(organizer, EventOrganizer):
                for event_id in organizer.managed_events:
                    if event_id in self.manager.events:
                        managed.append(self.manager.events[event_id])
            if not managed:
                print("You are not managing any events yet.")
            else:
                print(f"You manage {len(managed)} event(s):")
                for i, event in enumerate(managed, 1):
                    print(f"{i}. {event}")
        elif choice == '3':
            print("Manage Attendees - Feature to be implemented")
        elif choice == '4':
            print("View Event Details - Feature to be implemented")
        elif choice == '5':
            self.handle_view_statistics()
        elif choice == '6':
            self.manager.current_user = None
            print("Logged out successfully!")
        elif choice == '7':
            self.running = False
            self.manager.save_data()
        else:
            print("Invalid choice!")
    
    def handle_student_choice(self, choice: str):
        """Handle student/visitor choices"""
        if choice == '1':
            self.handle_search_events()
        elif choice == '2':
            self.handle_register_for_event()
        elif choice == '3':
            # Show events the current user registered for
            user_id = self.manager.current_user.user_id
            my_events = self.manager.get_user_events(user_id)
            if not my_events:
                print("You have not registered for any events.")
            else:
                print(f"You have {len(my_events)} registered event(s):")
                for i, event in enumerate(my_events, 1):
                    print(f"{i}. {event}")
        elif choice == '4':
            print("View Event Details - Feature to be implemented")
        elif choice == '5':
            self.manager.current_user = None
            print("Logged out successfully!")
        elif choice == '6':
            self.running = False
            self.manager.save_data()
        else:
            print("Invalid choice!")


def main():
    """Main function to run the application"""
    system = EventManagementSystem()
    system.run()


if __name__ == "__main__":
    main()
