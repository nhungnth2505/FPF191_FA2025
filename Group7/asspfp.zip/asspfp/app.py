"""
Campus Event Management System - Web Version
Tích hợp tất cả tính năng thành website chạy trên localhost:3000
"""

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import json
import os
import uuid
from datetime import datetime

# Helper function để kiểm tra quyền
def has_permission(permission):
    """Kiểm tra user hiện tại có quyền không"""
    if 'user_id' not in session:
        return False
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return False
    if not hasattr(event_manager.current_user, 'get_permissions'):
        return False
    return permission in event_manager.current_user.get_permissions()
import qrcode
from io import BytesIO
import base64
from werkzeug.utils import secure_filename
from PIL import Image

# Import các class từ enhanced_ass.py
from enhanced_ass import (
    EnhancedUser, EnhancedAdmin, EnhancedEventOrganizer, EnhancedStudent,
    EnhancedEvent, EnhancedEventManager, EnhancedEventManagementSystem
)
from ai_assistant import SimpleAIAssistant

app = Flask(__name__)
app.secret_key = 'campus_event_management_2024'

# Register helper function cho templates
app.jinja_env.globals.update(has_permission=has_permission)

# Cấu hình upload hình ảnh
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Tạo thư mục upload nếu chưa có
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Khởi tạo hệ thống
event_manager = EnhancedEventManager()

def allowed_file(filename):
    """Kiểm tra file có được phép upload không"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def resize_image(image_path, max_size=(800, 600)):
    """Resize hình ảnh để tối ưu"""
    try:
        with Image.open(image_path) as img:
            img.thumbnail(max_size, Image.Resampling.LANCZOS)
            img.save(image_path, optimize=True, quality=85)
    except Exception as e:
        print(f"Error resizing image: {e}")

@app.route('/')
def index():
    """Trang chủ"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Đăng nhập"""
    print(f"Debug: Login route called, method: {request.method}")
    print(f"Debug: Event manager users: {list(event_manager.users.keys())}")
    
    if request.method == 'POST':
        user_id = request.form.get('user_id')
        print(f"Debug: Login attempt with user_id: {user_id}")
        print(f"Debug: Available users: {list(event_manager.users.keys())}")
        
        # Check if user exists in event_manager
        if user_id in event_manager.users:
            print(f"Debug: User {user_id} found in event_manager")
            if event_manager.login(user_id):
                session['user_id'] = user_id
                session['user_name'] = event_manager.current_user.name
                session['user_role'] = event_manager.current_user.role
                print(f"Debug: Login successful for {user_id}")
                flash('Đăng nhập thành công!', 'success')
                
                # Redirect theo role
                user_role = event_manager.current_user.role
                if user_role in ['Student', 'EnhancedStudent']:
                    return redirect(url_for('events'))  # Student chỉ xem events
                elif user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer']:
                    return redirect(url_for('dashboard'))  # Admin/Organizer xem dashboard
                else:
                    return redirect(url_for('events'))  # Default
            else:
                print(f"Debug: Login method failed for {user_id}")
                flash('Lỗi đăng nhập!', 'error')
        else:
            print(f"Debug: User {user_id} not found in event_manager")
            flash('ID người dùng không hợp lệ!', 'error')
    else:
        print("Debug: Login GET request")
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Đăng ký người dùng mới"""
    if request.method == 'POST':
        user_type = request.form.get('user_type')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone', '')
        
        try:
            print(f"Debug: Dang dang ky user voi thong tin: {user_type}, {name}, {email}, {phone}")
            
            # Kiểm tra dữ liệu đầu vào
            if not user_type or not name or not email:
                raise ValueError("Vui long dien day du thong tin bat buoc!")
            
            user_id = event_manager.register_user(user_type, name, email, phone)
            print(f"Debug: Dang ky thanh cong, user_id: {user_id}")
            
            # Hiển thị ID trực tiếp như trang test
            return f'''
            <!DOCTYPE html>
            <html>
            <head>
                <title>Đăng ký thành công</title>
                <meta charset="utf-8">
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                    .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
                    .success {{ color: green; font-size: 24px; font-weight: bold; }}
                    .id-box {{ background: yellow; padding: 15px; margin: 20px 0; border-radius: 5px; font-weight: bold; font-size: 18px; }}
                    button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
                    .copy-btn {{ background: green; color: white; }}
                    .login-btn {{ background: blue; color: white; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="success">✅ Đăng ký thành công!</div>
                    <h2>🎯 ID của bạn: {user_id}</h2>
                    <p>Copy ID này để đăng nhập</p>
                    <div class="id-box">{user_id}</div>
                    <button class="copy-btn" onclick="navigator.clipboard.writeText('{user_id}')">📋 Copy ID</button>
                    <br>
                    <a href="/login" class="login-btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">🔑 Đăng nhập</a>
                </div>
            </body>
            </html>
            '''
        except Exception as e:
            print(f"Debug: Loi dang ky: {str(e)}")
            flash(f'Loi dang ky: {str(e)}', 'error')
    
    return render_template('register.html')

@app.route('/show-user-id')
def show_user_id():
    """Trang hiển thị ID người dùng sau khi đăng ký"""
    print(f"Debug: show_user_id called, session: {dict(session)}")
    
    if 'new_user_id' not in session:
        print("Debug: Khong tim thay new_user_id trong session")
        flash('Khong tim thay thong tin dang ky!', 'error')
        return redirect(url_for('register'))
    
    user_id = session['new_user_id']
    user_name = session.get('new_user_name', 'User')
    user_email = session.get('new_user_email', '')
    user_type = session.get('new_user_type', 'student')
    
    print(f"Debug: Rendering show_user_id with: {user_id}, {user_name}, {user_email}, {user_type}")
    
    # Xóa session data sau khi hiển thị
    session.pop('new_user_id', None)
    session.pop('new_user_name', None)
    session.pop('new_user_email', None)
    session.pop('new_user_type', None)
    
    return render_template('show_user_id.html', 
                         user_id=user_id, 
                         user_name=user_name,
                         user_email=user_email,
                         user_type=user_type)

@app.route('/debug-register', methods=['POST'])
def debug_register():
    """Debug route để kiểm tra đăng ký"""
    print("=== DEBUG REGISTER ===")
    data = request.get_json()
    print(f"Received data: {data}")
    
    try:
        user_id = event_manager.register_user(
            data.get('user_type', 'student'),
            data.get('name', 'Test User'),
            data.get('email', 'test@example.com'),
            data.get('phone', '')
        )
        
        # Lưu vào session
        session['new_user_id'] = user_id
        session['new_user_name'] = data.get('name', 'Test User')
        session['new_user_email'] = data.get('email', 'test@example.com')
        session['new_user_type'] = data.get('user_type', 'student')
        
        print(f"Debug: User created with ID: {user_id}")
        print(f"Debug: Session: {dict(session)}")
        
        return jsonify({
            'success': True,
            'user_id': user_id,
            'redirect_url': url_for('show_user_id')
        })
    except Exception as e:
        print(f"Debug: Error: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/test-session')
def test_session():
    """Test session data"""
    return f"Session data: {dict(session)}"

@app.route('/test-form', methods=['GET', 'POST'])
def test_form():
    """Test form submission"""
    if request.method == 'POST':
        print("=== FORM SUBMISSION DEBUG ===")
        print(f"Form data: {dict(request.form)}")
        print(f"Method: {request.method}")
        print(f"Content-Type: {request.content_type}")
        
        user_type = request.form.get('user_type')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone', '')
        
        print(f"Parsed data: user_type={user_type}, name={name}, email={email}, phone={phone}")
        
        try:
            user_id = event_manager.register_user(user_type, name, email, phone)
            print(f"Success: user_id = {user_id}")
            return f'''
            <h1>Form Test Success!</h1>
            <h2>ID: {user_id}</h2>
            <p>Form data received correctly!</p>
            <a href="/register">Back to Register</a>
            '''
        except Exception as e:
            print(f"Error: {str(e)}")
            return f'Error: {str(e)}'
    
    return '''
    <h2>Test Form</h2>
    <form method="post">
        <input type="text" name="user_type" placeholder="User Type" required><br><br>
        <input type="text" name="name" placeholder="Name" required><br><br>
        <input type="email" name="email" placeholder="Email" required><br><br>
        <input type="text" name="phone" placeholder="Phone"><br><br>
        <button type="submit">Test Submit</button>
    </form>
    '''

@app.route('/simple-register-page')
def simple_register_page():
    """Trang đăng ký đơn giản với form HTML thuần"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Đăng ký đơn giản</title>
        <meta charset="utf-8">
        <style>
            body { font-family: Arial, sans-serif; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .container { background: white; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }
            input, select, button { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { background: green; color: white; border: none; cursor: pointer; }
            button:hover { background: darkgreen; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Đăng ký đơn giản</h2>
            <form method="POST" action="/register">
                <select name="user_type" required>
                    <option value="">Chọn loại tài khoản</option>
                    <option value="admin">Admin</option>
                    <option value="organizer">Event Organizer</option>
                    <option value="student">Student</option>
                </select>
                
                <input type="text" name="name" placeholder="Họ và tên" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="tel" name="phone" placeholder="Số điện thoại">
                
                <button type="submit">Đăng ký</button>
            </form>
            <p><a href="/register">← Quay lại form chính</a></p>
        </div>
    </body>
    </html>
    '''

@app.route('/test-main-form')
def test_main_form():
    """Test form chính với HTML đơn giản"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Test Form Chính</title>
        <meta charset="utf-8">
        <style>
            body { font-family: Arial, sans-serif; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .container { background: white; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }
            input, select, button { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { background: green; color: white; border: none; cursor: pointer; }
            button:hover { background: darkgreen; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Test Form Chính</h2>
            <form method="POST" action="/register" id="testForm">
                <select name="user_type" required>
                    <option value="">Chọn loại tài khoản</option>
                    <option value="admin">Admin</option>
                    <option value="organizer">Event Organizer</option>
                    <option value="student">Student</option>
                </select>
                
                <input type="text" name="name" placeholder="Họ và tên" required>
                <input type="email" name="email" placeholder="Email" required>
                <input type="tel" name="phone" placeholder="Số điện thoại">
                
                <button type="submit">Đăng ký</button>
            </form>
            <p><a href="/register">← Quay lại form chính</a></p>
        </div>
        <script>
            document.getElementById('testForm').addEventListener('submit', function(e) {
                console.log('Test form submitted!');
                console.log('Form action:', this.action);
                console.log('Form method:', this.method);
            });
        </script>
    </body>
    </html>
    '''

@app.route('/bootstrap-test')
def bootstrap_test():
    """Test form Bootstrap đơn giản"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Bootstrap Test</title>
        <meta charset="utf-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 50px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h3 class="card-title text-center">Bootstrap Test</h3>
                            <form method="POST" action="/register" id="bootstrapForm">
                                <div class="mb-3">
                                    <label class="form-label">Loại tài khoản</label>
                                    <select class="form-select" name="user_type" required>
                                        <option value="">Chọn loại tài khoản</option>
                                        <option value="admin">Admin</option>
                                        <option value="organizer">Event Organizer</option>
                                        <option value="student">Student</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Họ và tên</label>
                                    <input type="text" class="form-control" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Số điện thoại</label>
                                    <input type="tel" class="form-control" name="phone">
                                </div>
                                
                                <button type="submit" class="btn btn-success w-100">Đăng ký</button>
                            </form>
                            <p class="text-center mt-3"><a href="/register">← Quay lại form chính</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            document.getElementById('bootstrapForm').addEventListener('submit', function(e) {
                console.log('Bootstrap form submitted!');
                console.log('Form action:', this.action);
                console.log('Form method:', this.method);
            });
        </script>
    </body>
    </html>
    '''

@app.route('/test-show-id')
def test_show_id():
    """Test hiển thị ID"""
    # Tạo data test
    test_data = {
        'user_id': 'TEST123456',
        'user_name': 'Test User',
        'user_email': 'test@example.com',
        'user_type': 'student'
    }
    
    print(f"Test show_id: Rendering with data: {test_data}")
    
    return render_template('show_user_id.html', **test_data)

@app.route('/test-login')
def test_login():
    """Test đăng nhập với ID có sẵn"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Test Login</title>
        <meta charset="utf-8">
        <style>
            body { font-family: Arial, sans-serif; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .container { background: white; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }
            input, button { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
            button { background: green; color: white; border: none; cursor: pointer; }
            .user-list { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Test Login</h2>
            <div class="user-list">
                <h4>Available User IDs:</h4>
                <ul>
                    <li>39eb0cc1-d1c5-49ed-8efa-7e84d8b66254 (caovanr - Event Organizer)</li>
                </ul>
            </div>
            
            <form method="POST" action="/login">
                <input type="text" name="user_id" placeholder="Nhập ID người dùng" required>
                <button type="submit">Test Login</button>
            </form>
            
            <p><a href="/login">← Quay lại trang đăng nhập chính</a></p>
        </div>
    </body>
    </html>
    '''

@app.route('/direct-test')
def direct_test():
    """Test trực tiếp không qua template"""
    try:
        user_id = event_manager.register_user('student', 'Direct Test', 'direct@test.com', '')
        return f'''
        <h1>✅ Đăng ký thành công!</h1>
        <h2>🎯 ID của bạn: {user_id}</h2>
        <p>Copy ID này để đăng nhập</p>
        <input type="text" value="{user_id}" readonly style="width: 300px; padding: 10px; font-size: 16px; font-weight: bold; background: yellow;">
        <br><br>
        <button onclick="navigator.clipboard.writeText('{user_id}')" style="padding: 10px 20px; background: green; color: white; border: none; border-radius: 5px;">📋 Copy ID</button>
        <br><br>
        <a href="/login" style="background: blue; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">🔑 Đăng nhập</a>
        '''
    except Exception as e:
        return f'❌ Lỗi: {str(e)}'

@app.route('/simple-register', methods=['GET', 'POST'])
def simple_register():
    """Đăng ký đơn giản để test"""
    if request.method == 'POST':
        name = request.form.get('name', 'Test User')
        email = request.form.get('email', 'test@example.com')
        
        try:
            user_id = event_manager.register_user('student', name, email, '')
            print(f"Simple register: Created user_id = {user_id}")
            
            # Hiển thị ID trực tiếp
            return f'''
            <!DOCTYPE html>
            <html>
            <head>
                <title>Đăng ký thành công</title>
                <meta charset="utf-8">
                <style>
                    body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                    .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
                    .success {{ color: green; font-size: 24px; font-weight: bold; }}
                    .id-box {{ background: yellow; padding: 15px; margin: 20px 0; border-radius: 5px; font-weight: bold; font-size: 18px; }}
                    button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
                    .copy-btn {{ background: green; color: white; }}
                    .login-btn {{ background: blue; color: white; }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="success">✅ Đăng ký thành công!</div>
                    <h2>🎯 ID của bạn: {user_id}</h2>
                    <p>Copy ID này để đăng nhập</p>
                    <div class="id-box">{user_id}</div>
                    <button class="copy-btn" onclick="navigator.clipboard.writeText('{user_id}')">📋 Copy ID</button>
                    <br>
                    <a href="/login" class="login-btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">🔑 Đăng nhập</a>
                </div>
            </body>
            </html>
            '''
        except Exception as e:
            print(f"Simple register error: {str(e)}")
            return f'Lỗi: {str(e)}'
    
    return '''
    <h2>Đăng ký Test</h2>
    <form method="post">
        <input type="text" name="name" placeholder="Tên" required><br><br>
        <input type="email" name="email" placeholder="Email" required><br><br>
        <button type="submit">Đăng ký</button>
    </form>
    <br>
    <a href="/test-session">Kiểm tra Session</a>
    '''

@app.route('/registration-success')
def registration_success():
    """Trang hiển thị sau khi đăng ký thành công"""
    print(f"Debug: Kiểm tra session data: {session}")
    
    if 'new_user_id' not in session:
        print("Debug: Không có new_user_id trong session, redirect về register")
        return redirect(url_for('register'))
    
    user_id = session['new_user_id']
    user_name = session.get('new_user_name', 'User')
    user_email = session.get('new_user_email', '')
    user_type = session.get('new_user_type', 'student')
    
    print(f"Debug: Hiển thị trang thành công cho user: {user_name}, ID: {user_id}")
    
    # Xóa session data sau khi hiển thị
    session.pop('new_user_id', None)
    session.pop('new_user_name', None)
    session.pop('new_user_email', None)
    session.pop('new_user_type', None)
    
    return render_template('registration_success.html', 
                         user_id=user_id, 
                         user_name=user_name,
                         user_email=user_email,
                         user_type=user_type)

@app.route('/registration-success-fallback')
def registration_success_fallback():
    """Fallback trang thành công nếu không có session"""
    return render_template('registration_success_fallback.html')

@app.route('/dashboard')
def dashboard():
    """Trang chính sau khi đăng nhập - CHỈ DÀNH CHO ADMIN VÀ ORGANIZER"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Đảm bảo user được login trong event_manager
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    user = event_manager.current_user
    user_role = getattr(user, 'role', 'student')
    
    # Kiểm tra quyền truy cập dashboard
    if user_role in ['Student', 'EnhancedStudent']:
        flash('Sinh viên không có quyền truy cập dashboard!', 'error')
        return redirect(url_for('events'))
    
    # Chỉ Admin và Organizer mới được xem dashboard
    if user_role not in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer']:
        flash('Bạn không có quyền truy cập dashboard!', 'error')
        return redirect(url_for('events'))
    
    events = list(event_manager.events.values())
    
    # Tính toán thống kê
    total_events = len(events)
    total_attendees = sum(len(event.attendees) for event in events)
    user_events = len([event for event in events if user.user_id in event.attendees])
    
    return render_template('dashboard.html', 
                         user=user, 
                         events=events,
                         total_events=total_events,
                         total_attendees=total_attendees,
                         user_events=user_events)

@app.route('/logout')
def logout():
    """Đăng xuất"""
    session.clear()
    flash('Đã đăng xuất thành công!', 'success')
    return redirect(url_for('login'))

@app.route('/gps-location', methods=['GET', 'POST'])
def gps_location():
    """GPS Location picker"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        latitude = float(request.form.get('latitude', 0))
        longitude = float(request.form.get('longitude', 0))
        
        if latitude and longitude:
            event_manager.current_user.set_location(latitude, longitude)
            flash(f'Đã cập nhật vị trí GPS: {latitude}, {longitude}', 'success')
        else:
            flash('Vui lòng chọn vị trí trên bản đồ!', 'error')
        
        return redirect(url_for('gps_location'))
    
    # Get current location if available
    current_location = None
    if hasattr(event_manager.current_user, 'gps_location') and event_manager.current_user.gps_location:
        current_location = event_manager.current_user.gps_location
    
    return render_template('gps_location.html', current_location=current_location)

@app.route('/create-event', methods=['GET', 'POST'])
def create_event():
    """Tạo sự kiện mới"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Đảm bảo user được login trong event_manager
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    # Kiểm tra quyền tạo sự kiện
    user_permissions = event_manager.current_user.get_permissions() if hasattr(event_manager.current_user, 'get_permissions') else []
    user_role = getattr(event_manager.current_user, 'role', 'Unknown')
    print(f"Debug: User role: {user_role}, permissions: {user_permissions}")
    
    if 'create_event' not in user_permissions and user_role not in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer']:
        flash(f'Bạn không có quyền tạo sự kiện! Role hiện tại: {user_role}. Chỉ Event Organizer và Admin mới có thể tạo sự kiện.', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        # Xử lý tạo sự kiện
        name = request.form.get('name')
        description = request.form.get('description')
        date = request.form.get('date')
        time = request.form.get('time')
        location = request.form.get('location')
        max_capacity = int(request.form.get('max_capacity', 0))
        category = request.form.get('category', 'general')
        latitude = request.form.get('latitude')
        longitude = request.form.get('longitude')
        
        # Tạo sự kiện
        event_id = event_manager.create_event(
            name=name,
            description=description,
            date=date,
            time=time,
            location=location,
            max_capacity=max_capacity,
            category=category,
            latitude=float(latitude) if latitude else None,
            longitude=float(longitude) if longitude else None
        )
        
        # Xử lý upload hình ảnh
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file and image_file.filename:
                # Lưu hình ảnh
                filename = secure_filename(image_file.filename)
                if filename:
                    # Tạo thư mục uploads nếu chưa có
                    upload_folder = 'static/uploads'
                    os.makedirs(upload_folder, exist_ok=True)
                    
                    # Tạo tên file unique
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    filename = f"{timestamp}_{filename}"
                    filepath = os.path.join(upload_folder, filename)
                    
                    # Lưu file
                    image_file.save(filepath)
                    
                    # Cập nhật event với đường dẫn hình ảnh (chỉ lưu tên file, không lưu đường dẫn đầy đủ)
                    if event_id in event_manager.events:
                        event_manager.events[event_id].image_path = f"uploads/{filename}"
                        event_manager.save_data()
        
        flash(f'🎉 Tạo sự kiện "{name}" thành công!', 'success')
        return redirect(url_for('events'))
    
    return render_template('create_event_standalone.html')

@app.route('/events')
def events():
    """Danh sách sự kiện"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Đảm bảo user được login trong event_manager
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    user = event_manager.current_user
    user_role = getattr(user, 'role', 'student')
    
    search_query = request.args.get('search', '')
    date_filter = request.args.get('date', '')
    
    # Tìm kiếm sự kiện
    all_events = list(event_manager.events.values())
    filtered_events = all_events
    
    if search_query:
        filtered_events = [e for e in filtered_events 
                          if search_query.lower() in e.name.lower() 
                          or search_query.lower() in e.description.lower()]
    
    if date_filter:
        filtered_events = [e for e in filtered_events if e.date == date_filter]
    
    return render_template('events.html', 
                         events=filtered_events,
                         search_query=search_query,
                         date_filter=date_filter,
                         user=user,
                         user_role=user_role)

@app.route('/events/create', methods=['GET', 'POST'])
def create_event_form():
    """Tạo sự kiện mới"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not event_manager.current_user.has_permission("create_event"):
        flash('Bạn không có quyền tạo sự kiện!', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            description = request.form.get('description')
            date = request.form.get('date')
            time = request.form.get('time')
            location = request.form.get('location')
            max_capacity = int(request.form.get('max_capacity'))
            latitude = request.form.get('latitude')
            longitude = request.form.get('longitude')
            category = request.form.get('category', 'general')
            
            # Xử lý GPS coordinates
            lat = float(latitude) if latitude else None
            lon = float(longitude) if longitude else None
            
            event_id = event_manager.create_event(
                name, description, date, time, location, 
                max_capacity, lat, lon, category
            )
            
            # Xử lý upload hình ảnh
            if 'image' in request.files:
                file = request.files['image']
                if file and file.filename and allowed_file(file.filename):
                    filename = secure_filename(f"{event_id}_{file.filename}")
                    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(file_path)
                    
                    # Resize hình ảnh
                    resize_image(file_path)
                    
                    # Lưu đường dẫn hình ảnh vào event (chỉ lưu tên file, không lưu đường dẫn đầy đủ)
                    if event_id in event_manager.events:
                        event_manager.events[event_id].image_path = f"uploads/{filename}"
                        event_manager.save_data()
            
            flash('Sự kiện được tạo thành công!', 'success')
            return redirect(url_for('events'))
            
        except Exception as e:
            flash(f'Lỗi tạo sự kiện: {str(e)}', 'error')
    
    return render_template('create_event.html')

@app.route('/events/<event_id>')
def event_details(event_id):
    """Chi tiết sự kiện"""
    print(f"DEBUG Event Details Route Called:")
    print(f"  Event ID: {event_id}")
    print(f"  Available events: {list(event_manager.events.keys())}")
    
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if event_id not in event_manager.events:
        print(f"DEBUG: Event {event_id} not found in events!")
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    user = event_manager.current_user
    
    # Debug: Kiểm tra event data
    print(f"DEBUG Event Data:")
    print(f"  Event ID: {event_id}")
    print(f"  Event Name: {event.name}")
    print(f"  Event Description: {event.description}")
    print(f"  Event Date: {event.date}")
    print(f"  Event Time: {event.time}")
    print(f"  Event Location: {event.location}")
    print(f"  Event Category: {event.category}")
    print(f"  Event Organizer: {getattr(event, 'organizer_id', 'N/A')}")
    
    # Debug: Kiểm tra user role
    print(f"DEBUG User Info:")
    print(f"  User ID: {session.get('user_id')}")
    print(f"  User Role: {session.get('user_role')}")
    print(f"  Current User: {user}")
    if user:
        print(f"  User Role from object: {getattr(user, 'role', 'N/A')}")
    
    # Kiểm tra xem user đã đăng ký chưa
    is_registered = False
    if user and hasattr(user, 'user_id'):
        is_registered = user.user_id in event.attendees
    
    return render_template('event_details.html', 
                         event=event, 
                         user=user,
                         is_registered=is_registered,
                         user_role=session.get('user_role', 'student'))

@app.route('/events/<event_id>/register', methods=['POST'])
def register_for_event(event_id):
    """Đăng ký tham gia sự kiện"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if event_id not in event_manager.events:
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    user = event_manager.current_user
    
    if user.user_id in event.attendees:
        flash('⚠️ Bạn đã đăng ký sự kiện này rồi!', 'warning')
    elif event.is_full():
        flash('❌ Sự kiện đã đầy! Không thể đăng ký thêm.', 'error')
    else:
        if event.add_attendee(user.user_id):
            flash(f'✅ Đăng ký sự kiện "{event.name}" thành công!', 'success')
        else:
            flash('❌ Đăng ký thất bại! Vui lòng thử lại.', 'error')
    
    return redirect(url_for('event_details', event_id=event_id))

@app.route('/unregister/<event_id>')
def unregister_from_event(event_id):
    """Hủy đăng ký sự kiện"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if event_id not in event_manager.events:
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    user = event_manager.current_user
    
    if user.user_id not in event.attendees:
        flash('⚠️ Bạn chưa đăng ký sự kiện này!', 'warning')
    else:
        if event.remove_attendee(user.user_id):
            flash(f'✅ Hủy đăng ký sự kiện "{event.name}" thành công!', 'success')
        else:
            flash('❌ Hủy đăng ký thất bại! Vui lòng thử lại.', 'error')
    
    return redirect(url_for('event_details', event_id=event_id))

@app.route('/debug-events')
def debug_events():
    """Debug route để kiểm tra events"""
    print("DEBUG: Debug events route called")
    print(f"DEBUG: Available events: {list(event_manager.events.keys())}")
    print(f"DEBUG: Number of events: {len(event_manager.events)}")
    
    result = f"""
    <h2>Debug Events</h2>
    <p>Number of events: {len(event_manager.events)}</p>
    <ul>
    """
    for event_id, event in event_manager.events.items():
        result += f"<li><strong>{event_id}</strong>: {event.name}</li>"
    result += "</ul>"
    
    return result

@app.route('/create-admin')
def create_admin():
    """Tạo tài khoản admin mặc định để test"""
    try:
        admin_id = event_manager.register_user('admin', 'System Admin', 'admin@system.com', '0000000000')
        print(f"DEBUG: Created admin user with ID: {admin_id}")
        
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Admin Created</title>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
                .success {{ color: green; font-size: 24px; font-weight: bold; }}
                .id-box {{ background: yellow; padding: 15px; margin: 20px 0; border-radius: 5px; font-weight: bold; font-size: 18px; }}
                button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
                .copy-btn {{ background: green; color: white; }}
                .login-btn {{ background: blue; color: white; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="success">✅ Tạo Admin thành công!</div>
                <h2>🎯 Admin ID: {admin_id}</h2>
                <p>Copy ID này để đăng nhập với quyền Admin</p>
                <div class="id-box">{admin_id}</div>
                <button class="copy-btn" onclick="navigator.clipboard.writeText('{admin_id}')">📋 Copy Admin ID</button>
                <br>
                <a href="/login" class="login-btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">🔑 Đăng nhập Admin</a>
                <br><br>
                <a href="/debug-user-info" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: orange; color: white; border-radius: 5px;">🔍 Debug User Info</a>
            </div>
        </body>
        </html>
        '''
    except Exception as e:
        return f'❌ Lỗi tạo admin: {str(e)}'

@app.route('/debug-user-info')
def debug_user_info():
    """Debug route để kiểm tra thông tin user"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    print(f"DEBUG: User ID from session: {user_id}")
    
    # Kiểm tra user trong event_manager
    if user_id not in event_manager.users:
        return f"❌ User {user_id} không tồn tại trong event_manager!"
    
    user = event_manager.users[user_id]
    print(f"DEBUG: User object: {user}")
    print(f"DEBUG: User role: {getattr(user, 'role', 'N/A')}")
    print(f"DEBUG: User permissions: {getattr(user, 'get_permissions', lambda: [])()}")
    
    # Kiểm tra login
    login_success = event_manager.login(user_id)
    print(f"DEBUG: Login success: {login_success}")
    
    if login_success:
        current_user = event_manager.current_user
        print(f"DEBUG: Current user: {current_user}")
        print(f"DEBUG: Current user role: {getattr(current_user, 'role', 'N/A')}")
        print(f"DEBUG: Current user permissions: {getattr(current_user, 'get_permissions', lambda: [])()}")
    
    # Kiểm tra events và organizer
    events_info = []
    for event_id, event in event_manager.events.items():
        events_info.append(f"""
        <div style="border: 1px solid #ccc; padding: 10px; margin: 10px 0;">
            <h4>{event.name} (ID: {event_id})</h4>
            <p><strong>Organizer ID:</strong> {getattr(event, 'organizer_id', 'N/A')}</p>
            <p><strong>Current User ID:</strong> {user_id}</p>
            <p><strong>Can Edit:</strong> {'✅' if (getattr(current_user, 'role', '') == 'EnhancedAdmin' or getattr(event, 'organizer_id', '') == user_id) else '❌'}</p>
            <p><strong>Can Delete:</strong> {'✅' if getattr(current_user, 'role', '') == 'EnhancedAdmin' else '❌'}</p>
        </div>
        """)
    
    return f"""
    <h2>🔍 Debug User Information</h2>
    <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <h3>📋 Session Information</h3>
        <p><strong>User ID:</strong> {user_id}</p>
        <p><strong>User Name:</strong> {session.get('user_name', 'N/A')}</p>
        <p><strong>User Role:</strong> {session.get('user_role', 'N/A')}</p>
    </div>
    
    <div style="background: #e8f4fd; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <h3>👤 User Object Information</h3>
        <p><strong>User Role:</strong> {getattr(user, 'role', 'N/A')}</p>
        <p><strong>User Permissions:</strong> {getattr(user, 'get_permissions', lambda: [])()}</p>
        <p><strong>Login Success:</strong> {'✅' if login_success else '❌'}</p>
    </div>
    
    <div style="background: #fff3cd; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <h3>🎯 Events Permission Check</h3>
        {''.join(events_info)}
    </div>
    
    <div style="background: #d1ecf1; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <h3>🔧 Quick Actions</h3>
        <p><a href="/events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">📋 Xem danh sách sự kiện</a></p>
        <p><a href="/dashboard" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">🏠 Dashboard</a></p>
    </div>
    """

@app.route('/test-edit-delete')
def test_edit_delete():
    """Test route để kiểm tra edit/delete functionality"""
    return '''
    <html>
    <head><title>Test Edit/Delete</title></head>
    <body>
        <h2>Test Edit/Delete Functionality</h2>
        
        <h3>Test Edit Form:</h3>
        <form method="POST" action="/edit-event/test-event-id">
            <input type="text" name="name" value="Test Event" required>
            <input type="text" name="description" value="Test Description" required>
            <input type="date" name="date" value="2025-12-31" required>
            <input type="time" name="time" value="10:00" required>
            <input type="text" name="location" value="Test Location" required>
            <input type="number" name="max_capacity" value="100" required>
            <select name="category" required>
                <option value="tech">Tech</option>
            </select>
            <button type="submit">Test Edit</button>
        </form>
        
        <h3>Test Delete Form:</h3>
        <form method="POST" action="/delete-event/test-event-id">
            <button type="submit">Test Delete</button>
        </form>
        
        <h3>Simple Delete Test:</h3>
        <button onclick="testDelete()">Test Delete Function</button>
        
        <script>
            console.log('Test page loaded');
            
            function testDelete() {
                console.log('Testing delete function...');
                fetch('/delete-event/test-event-id', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'test=1'
                })
                .then(response => {
                    console.log('Response status:', response.status);
                    return response.text();
                })
                .then(data => {
                    console.log('Response data:', data);
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            }
        </script>
    </body>
    </html>
    '''

@app.route('/my-events')
def my_events():
    """Sự kiện đã đăng ký"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = event_manager.current_user
    my_events = []
    
    for event in event_manager.events.values():
        if user.user_id in event.attendees:
            my_events.append(event)
    
    return render_template('my_events.html', events=my_events)

@app.route('/statistics')
def statistics():
    """Thống kê hệ thống"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if not event_manager.current_user.has_permission("view_statistics"):
        flash('Bạn không có quyền xem thống kê!', 'error')
        return redirect(url_for('dashboard'))
    
    try:
        event_manager.display_statistics_with_ui()
        stats = event_manager.get_statistics()
        return render_template('statistics.html', stats=stats)
    except Exception as e:
        flash(f'Lỗi hiển thị thống kê: {str(e)}', 'error')
        return redirect(url_for('dashboard'))

@app.route('/ai-assistant', methods=['GET', 'POST'])
def ai_assistant():
    """Trợ lý AI"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    response = None
    if request.method == 'POST':
        question = request.form.get('question', '')
        if question:
            # Khởi tạo AI Assistant
            assistant = SimpleAIAssistant(lambda: list(event_manager.events.values()))
            response = assistant.answer(question)
    
    return render_template('ai_assistant.html', response=response)

@app.route('/qr-checkin', methods=['GET', 'POST'])
def qr_checkin():
    """Check-in bằng QR code"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        # Xử lý QR code scan
        qr_data = request.form.get('qr_data', '')
        if qr_data:
            try:
                success = event_manager.scan_qr_checkin(qr_data)
                if success:
                    flash('✅ Check-in thành công!', 'success')
                else:
                    flash('❌ Check-in thất bại! Có thể bạn đã check-in rồi hoặc sự kiện đã đầy.', 'error')
            except Exception as e:
                flash(f'Lỗi check-in: {str(e)}', 'error')
        
        # Xử lý manual check-in
        event_id = request.form.get('event_id', '')
        user_id = request.form.get('user_id', '')
        latitude = request.form.get('latitude', '')
        longitude = request.form.get('longitude', '')
        
        # Debug GPS data
        print(f"DEBUG GPS Check-in:")
        print(f"  Event ID: {event_id}")
        print(f"  User ID: {user_id}")
        print(f"  Latitude: {latitude}")
        print(f"  Longitude: {longitude}")
        
        if event_id and user_id:
            try:
                # Kiểm tra sự kiện có tồn tại không
                if event_id in event_manager.events:
                    event = event_manager.events[event_id]
                    print(f"  Event found: {event.name}")
                    print(f"  Event GPS: {event.latitude}, {event.longitude}")
                    
                    # Kiểm tra user có tồn tại không
                    if user_id in event_manager.users:
                        # GPS verification - BẮT BUỘC cho tất cả check-in
                        if latitude and longitude and event.latitude and event.longitude:
                            from mobile_features import GPSLocation
                            user_lat = float(latitude)
                            user_lon = float(longitude)
                            event_lat = float(event.latitude)
                            event_lon = float(event.longitude)
                            
                            print(f"  GPS Verification:")
                            print(f"    User location: {user_lat}, {user_lon}")
                            print(f"    Event location: {event_lat}, {event_lon}")
                            
                            # Kiểm tra trong bán kính 100m
                            if not GPSLocation.is_within_radius(user_lat, user_lon, event_lat, event_lon, 0.1):
                                distance = GPSLocation.calculate_distance(user_lat, user_lon, event_lat, event_lon)
                                print(f"    Distance: {distance:.3f}km - BLOCKED!")
                                flash(f'Bạn phải ở vị trí sự kiện để check-in! Khoảng cách hiện tại: {distance:.3f}km (cho phép: 0.1km)', 'error')
                                return redirect(url_for('qr_checkin'))
                            else:
                                distance = GPSLocation.calculate_distance(user_lat, user_lon, event_lat, event_lon)
                                print(f"    Distance: {distance:.3f}km - ALLOWED!")
                                flash(f'GPS verification thành công! Khoảng cách: {distance:.3f}km', 'info')
                        else:
                            print(f"  GPS verification SKIPPED - missing coordinates")
                            flash('GPS verification không thể thực hiện - thiếu tọa độ!', 'error')
                            return redirect(url_for('qr_checkin'))
                        
                        # Thêm user vào danh sách attendees
                        if user_id not in event.attendees:
                            if len(event.attendees) < event.max_capacity:
                                event.attendees.append(user_id)
                                event_manager.save_data()
                                flash('✅ Check-in thành công!', 'success')
                            else:
                                flash('❌ Sự kiện đã đầy!', 'error')
                        else:
                            flash('⚠️ Bạn đã check-in sự kiện này rồi!', 'warning')
                    else:
                        flash('ID người dùng không hợp lệ!', 'error')
                else:
                    flash('ID sự kiện không hợp lệ!', 'error')
            except Exception as e:
                print(f"  ERROR: {str(e)}")
                flash(f'Lỗi check-in: {str(e)}', 'error')
    
    # Lấy danh sách sự kiện có QR code
    events_with_qr = [event for event in event_manager.events.values() if event.qr_code]
    
    return render_template('qr_checkin.html', events=events_with_qr)

@app.route('/user-management')
def user_management():
    """Quản lý người dùng"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Kiểm tra quyền admin
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    if not hasattr(event_manager.current_user, 'role') or event_manager.current_user.role != 'EnhancedAdmin':
        flash('Bạn không có quyền truy cập trang này!', 'error')
        return redirect(url_for('dashboard'))
    
    # Lấy danh sách tất cả users
    users = list(event_manager.users.values())
    
    return render_template('user_management.html', users=users)

@app.route('/logout2')
def logout2():
    """Đăng xuất"""
    session.clear()
    flash('Đăng xuất thành công!', 'success')
    return redirect(url_for('index'))

@app.route('/generate_qr/<event_id>')
def generate_qr(event_id):
    """Tạo QR code cho sự kiện"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Đảm bảo user được login trong event_manager
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    # Kiểm tra sự kiện có tồn tại không
    if event_id not in event_manager.events:
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    
    # Tạo QR code
    try:
        qr_data = f"Event:{event_id}|CheckIn:{datetime.now().isoformat()}"
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(qr_data)
        qr.make(fit=True)
        
        # Tạo hình ảnh QR code
        qr_image = qr.make_image(fill_color="black", back_color="white")
        
        # Lưu QR code
        qr_filename = f"qr_event_{event_id}.png"
        qr_path = f"qr_codes/{qr_filename}"
        
        # Tạo thư mục nếu chưa có
        os.makedirs(os.path.join('static', 'qr_codes'), exist_ok=True)
        
        # Lưu file
        full_path = os.path.join('static', 'qr_codes', qr_filename)
        qr_image.save(full_path)
        
        # Cập nhật event với đường dẫn QR code (sử dụng / thay vì \\)
        event.qr_code = qr_path
        event_manager.save_data()
        
        flash('QR code đã được tạo thành công!', 'success')
        return redirect(url_for('event_details', event_id=event_id))
        
    except Exception as e:
        flash(f'Lỗi tạo QR code: {str(e)}', 'error')
        return redirect(url_for('event_details', event_id=event_id))

# API endpoints cho AJAX
@app.route('/api/events')
def api_events():
    """API lấy danh sách sự kiện"""
    events = []
    for event in event_manager.events.values():
        events.append({
            'id': event.event_id,
            'name': event.name,
            'date': event.date,
            'time': event.time,
            'location': event.location,
            'capacity': f"{len(event.attendees)}/{event.max_capacity}",
            'available_spots': event.get_available_spots()
        })
    return jsonify(events)

@app.route('/api/ai-chat', methods=['POST'])
def api_ai_chat():
    """API chat với AI Assistant"""
    data = request.get_json()
    question = data.get('question', '')
    
    if question:
        assistant = SimpleAIAssistant(lambda: list(event_manager.events.values()))
        response = assistant.answer(question)
        return jsonify({'response': response})
    
    return jsonify({'response': 'Vui lòng nhập câu hỏi!'})

@app.route('/edit-event/<event_id>')
def edit_event_form(event_id):
    """Form sửa sự kiện - VERSION MỚI"""
    print(f"DEBUG: Edit form GET called for event_id: {event_id}")
    
    if 'user_id' not in session:
        print("DEBUG: No user in session")
        return redirect(url_for('login'))
    
    # Kiểm tra quyền
    user_id = session['user_id']
    if not event_manager.login(user_id):
        print("DEBUG: Login failed")
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    # Kiểm tra sự kiện có tồn tại không
    if event_id not in event_manager.events:
        print(f"DEBUG: Event {event_id} not found")
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    
    # Debug: Log event data
    print(f"DEBUG Event Data:")
    print(f"  Event ID: {event_id}")
    print(f"  Event Name: {event.name}")
    print(f"  Event Category: {event.category}")
    print(f"  Event Description: {event.description}")
    print(f"  Event Date: {event.date}")
    print(f"  Event Time: {event.time}")
    print(f"  Event Location: {event.location}")
    print(f"  Event Max Capacity: {event.max_capacity}")
    print(f"  Event Organizer: {getattr(event, 'organizer_id', 'N/A')}")
    
    # Kiểm tra quyền sửa (admin, organizer hoặc người tạo sự kiện)
    current_user_role = getattr(event_manager.current_user, 'role', '')
    event_organizer = getattr(event, 'organizer_id', '')
    
    can_edit = (current_user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer'] or event_organizer == user_id)
    print(f"DEBUG: Can edit: {can_edit}")
    
    if not can_edit:
        flash('Bạn không có quyền sửa sự kiện này!', 'error')
        return redirect(url_for('event_details', event_id=event_id))
    
    # Tạo form HTML trực tiếp để tránh vấn đề template
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Sửa sự kiện - {event.name}</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            body {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }}
            .form-container {{ background: white; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }}
            .form-header {{ background: linear-gradient(45deg, #ff6b6b, #feca57); color: white; border-radius: 15px 15px 0 0; }}
        </style>
    </head>
    <body>
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="form-container">
                        <div class="form-header p-4">
                            <h2 class="mb-0"><i class="fas fa-edit me-2"></i>Sửa sự kiện</h2>
                            <p class="mb-0">Event ID: <code>{event_id}</code></p>
                        </div>
                        
                        <div class="p-4">
                            <form method="POST" action="/edit-event/{event_id}" enctype="multipart/form-data" id="editForm">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="name" class="form-label"><strong>Tên sự kiện *</strong></label>
                                        <input type="text" class="form-control" id="name" name="name" 
                                               value="{event.name}" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="category" class="form-label"><strong>Thể loại *</strong></label>
                                        <select class="form-select" id="category" name="category" required>
                                            <option value="tech" {'selected' if event.category == 'tech' else ''}>Công nghệ</option>
                                            <option value="sports" {'selected' if event.category == 'sports' else ''}>Thể thao</option>
                                            <option value="academic" {'selected' if event.category == 'academic' else ''}>Học thuật</option>
                                            <option value="social" {'selected' if event.category == 'social' else ''}>Xã hội</option>
                                            <option value="general" {'selected' if event.category == 'general' else ''}>Khác</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="description" class="form-label"><strong>Mô tả sự kiện *</strong></label>
                                    <textarea class="form-control" id="description" name="description" 
                                              rows="4" required>{event.description}</textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label for="date" class="form-label"><strong>Ngày tổ chức *</strong></label>
                                        <input type="date" class="form-control" id="date" name="date" 
                                               value="{event.date}" required>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="time" class="form-label"><strong>Giờ bắt đầu *</strong></label>
                                        <input type="time" class="form-control" id="time" name="time" 
                                               value="{event.time}" required>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label for="max_capacity" class="form-label"><strong>Sức chứa *</strong></label>
                                        <input type="number" class="form-control" id="max_capacity" name="max_capacity" 
                                               value="{event.max_capacity}" min="1" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="location" class="form-label"><strong>Địa điểm *</strong></label>
                                    <input type="text" class="form-control" id="location" name="location" 
                                           value="{event.location}" required>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="latitude" class="form-label">Vĩ độ (Latitude)</label>
                                        <input type="number" step="any" class="form-control" id="latitude" name="latitude" 
                                               value="{event.latitude if event.latitude else ''}" 
                                               placeholder="Ví dụ: 10.762622">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="longitude" class="form-label">Kinh độ (Longitude)</label>
                                        <input type="number" step="any" class="form-control" id="longitude" name="longitude" 
                                               value="{event.longitude if event.longitude else ''}" 
                                               placeholder="Ví dụ: 106.660172">
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="image" class="form-label">Ảnh sự kiện</label>
                                    <input type="file" class="form-control" id="image" name="image" 
                                           accept="image/*">
                                    <div class="form-text">Để trống nếu không muốn thay đổi ảnh hiện tại</div>
                                    {'<div class="mt-2"><small class="text-muted">Ảnh hiện tại:</small><br><img src="/static/' + event.image_path + '" class="img-thumbnail" style="max-width: 200px; max-height: 150px;"></div>' if hasattr(event, 'image_path') and event.image_path else ''}
                                </div>
                                
                                <div class="d-flex gap-2">
                                    <button type="submit" class="btn btn-warning btn-lg">
                                        <i class="fas fa-save me-2"></i>Cập nhật sự kiện
                                    </button>
                                    <a href="/events/{event_id}" class="btn btn-secondary btn-lg">
                                        <i class="fas fa-times me-2"></i>Hủy
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        document.addEventListener('DOMContentLoaded', function() {{
            console.log('Edit form loaded for event: {event_id}');
            console.log('Event name: {event.name}');
            console.log('Event category: {event.category}');
            
            const form = document.getElementById('editForm');
            if (form) {{
                form.addEventListener('submit', function(e) {{
                    console.log('Form submitted!');
                    console.log('Name:', document.getElementById('name').value);
                    console.log('Category:', document.getElementById('category').value);
                    console.log('Description:', document.getElementById('description').value);
                }});
            }}
        }});
        </script>
    </body>
    </html>
    '''

@app.route('/edit-event/<event_id>', methods=['POST'])
def edit_event(event_id):
    """Xử lý sửa sự kiện - VERSION MỚI"""
    print(f"DEBUG: Edit event POST called for event_id: {event_id}")
    print(f"DEBUG: Request method: {request.method}")
    print(f"DEBUG: Form data: {dict(request.form)}")
    
    if 'user_id' not in session:
        print("DEBUG: No user in session")
        return redirect(url_for('login'))
    
    # Kiểm tra quyền
    user_id = session['user_id']
    if not event_manager.login(user_id):
        print("DEBUG: Login failed")
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    # Kiểm tra sự kiện có tồn tại không
    if event_id not in event_manager.events:
        print(f"DEBUG: Event {event_id} not found")
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    
    # Kiểm tra quyền sửa (admin, organizer hoặc người tạo sự kiện)
    current_user_role = getattr(event_manager.current_user, 'role', '')
    event_organizer = getattr(event, 'organizer_id', '')
    
    can_edit = (current_user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer'] or event_organizer == user_id)
    print(f"DEBUG: Can edit: {can_edit}")
    
    if not can_edit:
        flash('Bạn không có quyền sửa sự kiện này!', 'error')
        return redirect(url_for('event_details', event_id=event_id))
    
    # Lấy dữ liệu từ form
    name = request.form.get('name', '').strip()
    description = request.form.get('description', '').strip()
    date = request.form.get('date', '').strip()
    time = request.form.get('time', '').strip()
    location = request.form.get('location', '').strip()
    max_capacity = int(request.form.get('max_capacity', 0))
    category = request.form.get('category', '').strip()
    latitude = request.form.get('latitude', '').strip()
    longitude = request.form.get('longitude', '').strip()
    
    print(f"DEBUG Form Data Received:")
    print(f"  Name: '{name}'")
    print(f"  Description: '{description[:50]}...'")
    print(f"  Date: '{date}'")
    print(f"  Time: '{time}'")
    print(f"  Location: '{location}'")
    print(f"  Max Capacity: {max_capacity}")
    print(f"  Category: '{category}'")
    print(f"  Latitude: '{latitude}'")
    print(f"  Longitude: '{longitude}'")
    
    # Validate required fields
    if not name or not description or not date or not time or not location or not category:
        flash('Vui lòng điền đầy đủ thông tin bắt buộc!', 'error')
        return redirect(url_for('edit_event_form', event_id=event_id))
    
    try:
        # Xử lý ảnh
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename:
                filename = secure_filename(file.filename)
                if filename:
                    # Tạo thư mục uploads nếu chưa có
                    os.makedirs('static/uploads', exist_ok=True)
                    file_path = os.path.join('static/uploads', filename)
                    file.save(file_path)
                    
                    # Resize ảnh
                    try:
                        from PIL import Image
                        with Image.open(file_path) as img:
                            img.thumbnail((800, 600))
                            img.save(file_path, 'JPEG', quality=85)
                    except:
                        pass
                    
                    event.image_path = f"uploads/{filename}"
                    print(f"DEBUG: Image updated: {event.image_path}")
        
        # Cập nhật thông tin sự kiện
        old_name = event.name
        event.name = name
        event.description = description
        event.date = date
        event.time = time
        event.location = location
        event.max_capacity = max_capacity
        event.category = category
        
        # Cập nhật GPS nếu có
        if latitude and longitude:
            try:
                event.latitude = float(latitude)
                event.longitude = float(longitude)
                print(f"DEBUG: GPS updated: {event.latitude}, {event.longitude}")
            except ValueError:
                print(f"DEBUG: Invalid GPS coordinates: {latitude}, {longitude}")
        
        # Lưu dữ liệu
        event_manager.save_data()
        print(f"DEBUG: Data saved successfully")
        
        # Debug: Kiểm tra dữ liệu sau khi lưu
        print(f"DEBUG: Event updated successfully:")
        print(f"  Old name: '{old_name}'")
        print(f"  New name: '{event.name}'")
        print(f"  New category: '{event.category}'")
        print(f"  New description: '{event.description[:50]}...'")
        
        flash(f'✅ Cập nhật sự kiện "{name}" thành công!', 'success')
        return redirect(url_for('event_details', event_id=event_id))
        
    except Exception as e:
        print(f"DEBUG: Error updating event: {str(e)}")
        flash(f'❌ Lỗi cập nhật sự kiện: {str(e)}', 'error')
        return redirect(url_for('edit_event_form', event_id=event_id))

@app.route('/delete-event/<event_id>')
def delete_event_confirm(event_id):
    """Xác nhận xóa sự kiện"""
    print(f"DEBUG: Delete confirm GET route called for event_id: {event_id}")
    print(f"DEBUG: Available events: {list(event_manager.events.keys())}")
    
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Kiểm tra quyền
    user_id = session['user_id']
    if not event_manager.login(user_id):
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    # Kiểm tra sự kiện có tồn tại không
    if event_id not in event_manager.events:
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    
    # Kiểm tra quyền xóa (chỉ admin)
    if not hasattr(event_manager.current_user, 'role') or event_manager.current_user.role != 'EnhancedAdmin':
        flash('Bạn không có quyền xóa sự kiện!', 'error')
        return redirect(url_for('event_details', event_id=event_id))
    
    return render_template('delete_event_confirm.html', event=event)

@app.route('/delete-event/<event_id>', methods=['POST'])
def delete_event(event_id):
    """Xóa sự kiện"""
    print(f"DEBUG: Delete event POST route called for event_id: {event_id}")
    print(f"DEBUG: Request method: {request.method}")
    print(f"DEBUG: Form data: {request.form}")
    print(f"DEBUG: Session data: {dict(session)}")
    print(f"DEBUG: Request headers: {dict(request.headers)}")
    
    # Kiểm tra xem có phải là AJAX request không
    if request.is_json:
        data = request.get_json()
        print(f"DEBUG: JSON data: {data}")
    else:
        print(f"DEBUG: Form data keys: {list(request.form.keys())}")
    
    if 'user_id' not in session:
        print("DEBUG: No user_id in session")
        flash('Vui lòng đăng nhập!', 'error')
        return redirect(url_for('login'))
    
    # Kiểm tra quyền
    user_id = session['user_id']
    print(f"DEBUG: User ID from session: {user_id}")
    
    if not event_manager.login(user_id):
        print("DEBUG: Login failed")
        flash('Lỗi xác thực người dùng!', 'error')
        return redirect(url_for('login'))
    
    print(f"DEBUG: Login successful, current user: {event_manager.current_user}")
    print(f"DEBUG: Current user role: {getattr(event_manager.current_user, 'role', 'N/A')}")
    
    # Kiểm tra sự kiện có tồn tại không
    if event_id not in event_manager.events:
        print(f"DEBUG: Event {event_id} not found in events")
        flash('Sự kiện không tồn tại!', 'error')
        return redirect(url_for('events'))
    
    event = event_manager.events[event_id]
    print(f"DEBUG: Event found: {event.name}")
    print(f"DEBUG: Event organizer: {getattr(event, 'organizer_id', 'N/A')}")
    
    # Kiểm tra quyền xóa (admin hoặc người tạo sự kiện)
    current_user_role = getattr(event_manager.current_user, 'role', '')
    event_organizer = getattr(event, 'organizer_id', '')
    
    print(f"DEBUG: Permission check:")
    print(f"  Current user role: {current_user_role}")
    print(f"  Event organizer: {event_organizer}")
    print(f"  User ID: {user_id}")
    print(f"  Is admin: {current_user_role == 'EnhancedAdmin'}")
    print(f"  Is organizer: {event_organizer == user_id}")
    
    # Chỉ Admin mới được xóa sự kiện
    can_delete = (current_user_role == 'EnhancedAdmin')
    print(f"DEBUG: Can delete: {can_delete}")
    
    if not can_delete:
        print("DEBUG: Permission denied - Only Admin can delete events")
        flash('Chỉ Admin mới có quyền xóa sự kiện!', 'error')
        return redirect(url_for('event_details', event_id=event_id))
    
    # Xóa sự kiện
    event_name = event.name
    print(f"DEBUG: Deleting event: {event_name}")
    
    try:
        del event_manager.events[event_id]
        event_manager.save_data()
        
        print(f"DEBUG: Event deleted successfully")
        print(f"DEBUG: Remaining events: {list(event_manager.events.keys())}")
        
        flash(f'🗑️ Đã xóa sự kiện "{event_name}" thành công!', 'success')
        
        # Trả về JSON response nếu là AJAX request
        if request.is_json:
            return jsonify({
                'success': True,
                'message': f'Đã xóa sự kiện "{event_name}" thành công!',
                'redirect_url': url_for('events')
            })
        
        return redirect(url_for('events'))
        
    except Exception as e:
        print(f"DEBUG: Error deleting event: {str(e)}")
        flash(f'Lỗi xóa sự kiện: {str(e)}', 'error')
        return redirect(url_for('event_details', event_id=event_id))

@app.route('/test-delete-all')
def test_delete_all():
    """Test route để xem tất cả sự kiện và quyền"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    current_user_role = getattr(event_manager.current_user, 'role', '')
    
    events_html = []
    for event_id, event in event_manager.events.items():
        event_organizer = getattr(event, 'organizer_id', 'N/A')
        can_edit = (current_user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer'] or event_organizer == user_id)
        can_delete = (current_user_role in ['Admin', 'EnhancedAdmin'] or event_organizer == user_id)
        
        events_html.append(f"""
        <div style="border: 1px solid #ccc; padding: 15px; margin: 10px 0; border-radius: 5px;">
            <h4>{event.name}</h4>
            <p><strong>ID:</strong> {event_id}</p>
            <p><strong>Organizer:</strong> {event_organizer}</p>
            <p><strong>Your ID:</strong> {user_id}</p>
            <p><strong>Your Role:</strong> {current_user_role}</p>
            <p><strong>Can Edit:</strong> {'✅' if can_edit else '❌'}</p>
            <p><strong>Can Delete:</strong> {'✅' if can_delete else '❌'}</p>
            <div style="margin-top: 10px;">
                <a href="/simple-delete/{event_id}" 
                   style="background: red; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px; margin-right: 5px;"
                   onclick="return confirm('Xóa {event.name}?')">
                   🗑️ Xóa nhanh
                </a>
                <a href="/edit-event/{event_id}" 
                   style="background: orange; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;">
                   ✏️ Sửa
                </a>
                <a href="/events/{event_id}" 
                   style="background: blue; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;">
                   👁️ Xem
                </a>
            </div>
        </div>
        """)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Test Delete All Events</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .event-card {{ background: white; margin: 10px 0; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🧪 Test Delete All Events</h1>
                <p><strong>User ID:</strong> {user_id}</p>
                <p><strong>User Role:</strong> {current_user_role}</p>
                <p><strong>Total Events:</strong> {len(event_manager.events)}</p>
                <a href="/events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">📋 Xem danh sách sự kiện</a>
                <a href="/debug-user-info" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-left: 10px;">🔍 Debug User Info</a>
            </div>
            {''.join(events_html)}
        </div>
    </body>
    </html>
    '''

@app.route('/test-edit/<event_id>')
def test_edit(event_id):
    """Test route để kiểm tra edit event"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    if event_id not in event_manager.events:
        return f"❌ Sự kiện {event_id} không tồn tại!"
    
    event = event_manager.events[event_id]
    current_user_role = getattr(event_manager.current_user, 'role', '')
    event_organizer = getattr(event, 'organizer_id', '')
    
    can_edit = (current_user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer'] or event_organizer == user_id)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Test Edit Event</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 5px; }}
            .info {{ background: #e8f4fd; padding: 15px; border-radius: 5px; margin: 10px 0; }}
            .success {{ background: #d4edda; color: #155724; }}
            .error {{ background: #f8d7da; color: #721c24; }}
            button {{ padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; }}
            .btn-primary {{ background: blue; color: white; }}
            .btn-warning {{ background: orange; color: white; }}
            .btn-secondary {{ background: gray; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🧪 Test Edit Event</h1>
            
            <div class="info">
                <h3>📋 Event Information</h3>
                <p><strong>Name:</strong> {event.name}</p>
                <p><strong>ID:</strong> {event_id}</p>
                <p><strong>Organizer:</strong> {event_organizer}</p>
            </div>
            
            <div class="info">
                <h3>👤 User Information</h3>
                <p><strong>User ID:</strong> {user_id}</p>
                <p><strong>User Role:</strong> {current_user_role}</p>
                <p><strong>Can Edit:</strong> {'✅' if can_edit else '❌'}</p>
            </div>
            
            <div class="info {'success' if can_edit else 'error'}">
                <h3>🔧 Actions</h3>
                {'<p>✅ Bạn có thể sửa sự kiện này!</p>' if can_edit else '<p>❌ Bạn không có quyền sửa sự kiện này!</p>'}
            </div>
            
            <div>
                <a href="/edit-event/{event_id}" class="btn btn-warning">✏️ Edit Event Form</a>
                <a href="/events/{event_id}" class="btn btn-primary">👁️ View Event</a>
                <a href="/test-delete-all" class="btn btn-secondary">📋 Test All Events</a>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/list-all-events')
def list_all_events():
    """Liệt kê tất cả sự kiện hiện có"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    events_html = []
    for event_id, event in event_manager.events.items():
        events_html.append(f"""
        <div style="border: 1px solid #ccc; padding: 15px; margin: 10px 0; border-radius: 5px; background: white;">
            <h4>{event.name}</h4>
            <p><strong>ID:</strong> <code>{event_id}</code></p>
            <p><strong>Mô tả:</strong> {event.description[:100]}...</p>
            <p><strong>Ngày:</strong> {event.date} {event.time}</p>
            <p><strong>Địa điểm:</strong> {event.location}</p>
            <p><strong>Thể loại:</strong> {event.category}</p>
            <p><strong>Organizer:</strong> {getattr(event, 'organizer_id', 'N/A')}</p>
            <div style="margin-top: 10px;">
                <a href="/events/{event_id}" 
                   style="background: blue; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px; margin-right: 5px;">
                   👁️ Xem
                </a>
                <a href="/edit-event/{event_id}" 
                   style="background: orange; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px; margin-right: 5px;">
                   ✏️ Sửa
                </a>
                <a href="/test-edit/{event_id}" 
                   style="background: green; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px; margin-right: 5px;">
                   🧪 Test Edit
                </a>
                <a href="/simple-delete/{event_id}" 
                   style="background: red; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;"
                   onclick="return confirm('Xóa {event.name}?')">
                   🗑️ Xóa
                </a>
            </div>
        </div>
        """)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Danh sách tất cả sự kiện</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .event-card {{ background: white; margin: 10px 0; }}
            code {{ background: #f8f9fa; padding: 2px 4px; border-radius: 3px; font-family: monospace; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>📋 Danh sách tất cả sự kiện</h1>
                <p><strong>User ID:</strong> {user_id}</p>
                <p><strong>User Role:</strong> {getattr(event_manager.current_user, 'role', 'N/A')}</p>
                <p><strong>Tổng số sự kiện:</strong> {len(event_manager.events)}</p>
                <div style="margin-top: 15px;">
                    <a href="/events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">📋 Xem danh sách chính</a>
                    <a href="/debug-user-info" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">🔍 Debug User Info</a>
                    <a href="/create-admin" style="background: orange; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">👑 Tạo Admin</a>
                </div>
            </div>
            {''.join(events_html) if events_html else '<div style="text-align: center; padding: 50px; background: white; border-radius: 5px;"><h3>Không có sự kiện nào!</h3><p>Hãy tạo sự kiện mới.</p></div>'}
        </div>
    </body>
    </html>
    '''

@app.route('/debug-all-events')
def debug_all_events():
    """Debug tất cả sự kiện để kiểm tra dữ liệu"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    events_debug = []
    for event_id, event in event_manager.events.items():
        events_debug.append(f"""
        <div style="border: 2px solid #ccc; padding: 20px; margin: 15px 0; border-radius: 8px; background: white;">
            <h3>🎯 Event ID: <code>{event_id}</code></h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 15px 0;">
                <div>
                    <p><strong>Name:</strong> {event.name}</p>
                    <p><strong>Description:</strong> {event.description[:50]}...</p>
                    <p><strong>Date:</strong> {event.date}</p>
                    <p><strong>Time:</strong> {event.time}</p>
                </div>
                <div>
                    <p><strong>Location:</strong> {event.location}</p>
                    <p><strong>Category:</strong> {event.category}</p>
                    <p><strong>Capacity:</strong> {event.max_capacity}</p>
                    <p><strong>Organizer:</strong> {getattr(event, 'organizer_id', 'N/A')}</p>
                </div>
            </div>
            <div style="margin-top: 15px;">
                <a href="/events/{event_id}" 
                   style="background: blue; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;">
                   👁️ View Details
                </a>
                <a href="/edit-event/{event_id}" 
                   style="background: orange; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px; margin-right: 10px;">
                   ✏️ Edit
                </a>
                <a href="/test-edit/{event_id}" 
                   style="background: green; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px;">
                   🧪 Test
                </a>
            </div>
        </div>
        """)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Debug All Events</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 1400px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            code {{ background: #f8f9fa; padding: 4px 8px; border-radius: 4px; font-family: monospace; font-size: 14px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔍 Debug All Events</h1>
                <p><strong>User ID:</strong> {user_id}</p>
                <p><strong>User Role:</strong> {getattr(event_manager.current_user, 'role', 'N/A')}</p>
                <p><strong>Total Events:</strong> {len(event_manager.events)}</p>
                <div style="margin-top: 15px;">
                    <a href="/events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">📋 Events List</a>
                    <a href="/list-all-events" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">📊 List All</a>
                    <a href="/force-refresh-events" style="background: orange; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">🔄 Refresh</a>
                </div>
            </div>
            {''.join(events_debug) if events_debug else '<div style="text-align: center; padding: 50px; background: white; border-radius: 8px;"><h3>Không có sự kiện nào!</h3></div>'}
        </div>
    </body>
    </html>
    '''

@app.route('/check-data-file')
def check_data_file():
    """Kiểm tra file dữ liệu JSON"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    data_file = "enhanced_event_data.json"
    
    try:
        # Kiểm tra file có tồn tại không
        if not os.path.exists(data_file):
            return f"❌ File {data_file} không tồn tại!"
        
        # Đọc file JSON
        with open(data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        events_data = data.get('events', [])
        users_data = data.get('users', {})
        
        # Tạo HTML hiển thị dữ liệu
        events_html = []
        for i, event_data in enumerate(events_data):
            events_html.append(f"""
            <div style="border: 2px solid #ccc; padding: 15px; margin: 10px 0; border-radius: 5px; background: white;">
                <h4>Event {i+1}: {event_data.get('name', 'N/A')}</h4>
                <p><strong>ID:</strong> <code>{event_data.get('event_id', 'N/A')}</code></p>
                <p><strong>Description:</strong> {event_data.get('description', 'N/A')[:100]}...</p>
                <p><strong>Date:</strong> {event_data.get('date', 'N/A')}</p>
                <p><strong>Time:</strong> {event_data.get('time', 'N/A')}</p>
                <p><strong>Location:</strong> {event_data.get('location', 'N/A')}</p>
                <p><strong>Category:</strong> {event_data.get('category', 'N/A')}</p>
                <p><strong>Organizer:</strong> {event_data.get('organizer_id', 'N/A')}</p>
            </div>
            """)
        
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Check Data File</title>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
                .container {{ max-width: 1200px; margin: 0 auto; }}
                .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
                code {{ background: #f8f9fa; padding: 2px 4px; border-radius: 3px; font-family: monospace; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>📁 Check Data File</h1>
                    <p><strong>File:</strong> {data_file}</p>
                    <p><strong>File exists:</strong> ✅ Yes</p>
                    <p><strong>Events in file:</strong> {len(events_data)}</p>
                    <p><strong>Users in file:</strong> {len(users_data)}</p>
                    <p><strong>Events in memory:</strong> {len(event_manager.events)}</p>
                    <div style="margin-top: 15px;">
                        <a href="/debug-all-events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">🔍 Debug All Events</a>
                        <a href="/force-refresh-events" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">🔄 Force Refresh</a>
                    </div>
                </div>
                <h2>📋 Events in JSON File:</h2>
                {''.join(events_html) if events_html else '<div style="text-align: center; padding: 50px; background: white; border-radius: 5px;"><h3>Không có sự kiện nào trong file!</h3></div>'}
            </div>
        </body>
        </html>
        '''
        
    except Exception as e:
        return f"❌ Lỗi đọc file: {str(e)}"

@app.route('/force-refresh-events')
def force_refresh_events():
    """Force refresh events data"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    try:
        # Force reload data from file
        event_manager.load_data()
        print(f"DEBUG: Events data reloaded")
        print(f"DEBUG: Current events: {list(event_manager.events.keys())}")
        
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Force Refresh Events</title>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
                .success {{ color: green; font-size: 24px; font-weight: bold; }}
                button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
                .btn {{ background: blue; color: white; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="success">✅ Đã refresh dữ liệu sự kiện!</div>
                <h2>🔄 Dữ liệu đã được tải lại</h2>
                <p>Số sự kiện hiện tại: {len(event_manager.events)}</p>
                <a href="/events" class="btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">📋 Xem danh sách sự kiện</a>
                <br>
                <a href="/list-all-events" class="btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: green; color: white; border-radius: 5px; margin-top: 10px;">🔍 Xem tất cả sự kiện</a>
            </div>
        </body>
        </html>
        '''
    except Exception as e:
        return f"❌ Lỗi refresh dữ liệu: {str(e)}"

@app.route('/reset-events-data')
def reset_events_data():
    """Reset events data (XÓA TẤT CẢ DỮ LIỆU)"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    # Kiểm tra quyền admin
    current_user_role = getattr(event_manager.current_user, 'role', '')
    if current_user_role != 'EnhancedAdmin':
        return "❌ Chỉ Admin mới có thể reset dữ liệu!"
    
    try:
        # Xóa tất cả sự kiện
        event_manager.events.clear()
        event_manager.save_data()
        
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Reset Events Data</title>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
                .warning {{ color: red; font-size: 24px; font-weight: bold; }}
                button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
                .btn {{ background: blue; color: white; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="warning">⚠️ Đã reset dữ liệu sự kiện!</div>
                <h2>🗑️ Tất cả sự kiện đã bị xóa</h2>
                <p>Số sự kiện hiện tại: {len(event_manager.events)}</p>
                <a href="/events" class="btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">📋 Xem danh sách sự kiện</a>
                <br>
                <a href="/create-event" class="btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: green; color: white; border-radius: 5px; margin-top: 10px;">➕ Tạo sự kiện mới</a>
            </div>
        </body>
        </html>
        '''
    except Exception as e:
        return f"❌ Lỗi reset dữ liệu: {str(e)}"

@app.route('/find-duplicate-events')
def find_duplicate_events():
    """Tìm và xóa các sự kiện trùng lặp"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    # Kiểm tra quyền admin
    current_user_role = getattr(event_manager.current_user, 'role', '')
    if current_user_role != 'EnhancedAdmin':
        return "❌ Chỉ Admin mới có thể quản lý duplicate events!"
    
    # Tìm các sự kiện trùng lặp
    events_by_content = {}
    duplicates = []
    
    for event_id, event in event_manager.events.items():
        # Tạo key dựa trên nội dung (không bao gồm event_id)
        content_key = f"{event.name}|{event.description}|{event.date}|{event.time}|{event.location}|{event.category}|{event.organizer_id}"
        
        if content_key in events_by_content:
            # Đây là duplicate
            duplicates.append({
                'original_id': events_by_content[content_key],
                'duplicate_id': event_id,
                'event': event,
                'content_key': content_key
            })
        else:
            events_by_content[content_key] = event_id
    
    # Tạo HTML hiển thị duplicates
    duplicates_html = []
    for i, dup in enumerate(duplicates):
        duplicates_html.append(f"""
        <div style="border: 2px solid red; padding: 15px; margin: 10px 0; border-radius: 5px; background: #ffe6e6;">
            <h4>🔴 Duplicate {i+1}</h4>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div>
                    <h5>Original Event:</h5>
                    <p><strong>ID:</strong> <code>{dup['original_id']}</code></p>
                    <p><strong>Name:</strong> {event_manager.events[dup['original_id']].name}</p>
                </div>
                <div>
                    <h5>Duplicate Event:</h5>
                    <p><strong>ID:</strong> <code>{dup['duplicate_id']}</code></p>
                    <p><strong>Name:</strong> {dup['event'].name}</p>
                </div>
            </div>
            <div style="margin-top: 10px;">
                <a href="/simple-delete/{dup['duplicate_id']}" 
                   style="background: red; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px; margin-right: 5px;"
                   onclick="return confirm('Xóa duplicate event {dup['event'].name}?')">
                   🗑️ Xóa Duplicate
                </a>
                <a href="/events/{dup['original_id']}" 
                   style="background: blue; color: white; padding: 5px 10px; text-decoration: none; border-radius: 3px;">
                   👁️ Xem Original
                </a>
            </div>
        </div>
        """)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Find Duplicate Events</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            code {{ background: #f8f9fa; padding: 2px 4px; border-radius: 3px; font-family: monospace; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔍 Find Duplicate Events</h1>
                <p><strong>Total Events:</strong> {len(event_manager.events)}</p>
                <p><strong>Duplicates Found:</strong> {len(duplicates)}</p>
                <div style="margin-top: 15px;">
                    <a href="/debug-all-events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">🔍 Debug All Events</a>
                    <a href="/force-refresh-events" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">🔄 Refresh</a>
                </div>
            </div>
            <h2>🔴 Duplicate Events:</h2>
            {''.join(duplicates_html) if duplicates_html else '<div style="text-align: center; padding: 50px; background: white; border-radius: 5px;"><h3>✅ Không có sự kiện trùng lặp!</h3></div>'}
        </div>
    </body>
    </html>
    '''

@app.route('/find-similar-events')
def find_similar_events():
    """Tìm các sự kiện có tên và thể loại giống nhau"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    # Kiểm tra quyền admin
    current_user_role = getattr(event_manager.current_user, 'role', '')
    if current_user_role != 'EnhancedAdmin':
        return "❌ Chỉ Admin mới có thể quản lý similar events!"
    
    # Tìm các sự kiện có tên và thể loại giống nhau
    events_by_name_category = {}
    similar_groups = []
    
    for event_id, event in event_manager.events.items():
        # Tạo key dựa trên tên và thể loại
        name_category_key = f"{event.name}|{event.category}"
        
        if name_category_key in events_by_name_category:
            # Đây là sự kiện tương tự
            if name_category_key not in [group['key'] for group in similar_groups]:
                # Tạo group mới
                similar_groups.append({
                    'key': name_category_key,
                    'name': event.name,
                    'category': event.category,
                    'events': [events_by_name_category[name_category_key], event_id]
                })
            else:
                # Thêm vào group đã có
                for group in similar_groups:
                    if group['key'] == name_category_key:
                        group['events'].append(event_id)
                        break
        else:
            events_by_name_category[name_category_key] = event_id
    
    # Tạo HTML hiển thị similar groups
    similar_html = []
    for i, group in enumerate(similar_groups):
        events_in_group = []
        for event_id in group['events']:
            event = event_manager.events[event_id]
            events_in_group.append(f"""
            <div style="border: 1px solid #ddd; padding: 10px; margin: 5px 0; border-radius: 3px; background: #f9f9f9;">
                <p><strong>ID:</strong> <code>{event_id}</code></p>
                <p><strong>Name:</strong> {event.name}</p>
                <p><strong>Description:</strong> {event.description[:50]}...</p>
                <p><strong>Date:</strong> {event.date} {event.time}</p>
                <p><strong>Location:</strong> {event.location}</p>
                <p><strong>Organizer:</strong> {getattr(event, 'organizer_id', 'N/A')}</p>
                <div style="margin-top: 5px;">
                    <a href="/events/{event_id}" 
                       style="background: blue; color: white; padding: 3px 8px; text-decoration: none; border-radius: 3px; margin-right: 5px; font-size: 12px;">
                       👁️ View
                    </a>
                    <a href="/edit-event/{event_id}" 
                       style="background: orange; color: white; padding: 3px 8px; text-decoration: none; border-radius: 3px; margin-right: 5px; font-size: 12px;">
                       ✏️ Edit
                    </a>
                    <a href="/simple-delete/{event_id}" 
                       style="background: red; color: white; padding: 3px 8px; text-decoration: none; border-radius: 3px; font-size: 12px;"
                       onclick="return confirm('Xóa sự kiện {event.name}?')">
                       🗑️ Delete
                    </a>
                </div>
            </div>
            """)
        
        similar_html.append(f"""
        <div style="border: 2px solid orange; padding: 15px; margin: 15px 0; border-radius: 5px; background: #fff3cd;">
            <h4>🟡 Similar Group {i+1}: "{group['name']}" ({group['category']})</h4>
            <p><strong>Count:</strong> {len(group['events'])} events with same name and category</p>
            <div style="margin-top: 10px;">
                {''.join(events_in_group)}
            </div>
        </div>
        """)
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Find Similar Events</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            code {{ background: #f8f9fa; padding: 2px 4px; border-radius: 3px; font-family: monospace; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔍 Find Similar Events</h1>
                <p><strong>Total Events:</strong> {len(event_manager.events)}</p>
                <p><strong>Similar Groups Found:</strong> {len(similar_groups)}</p>
                <div style="margin-top: 15px;">
                    <a href="/debug-all-events" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">🔍 Debug All Events</a>
                    <a href="/find-duplicate-events" style="background: red; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">🔍 Find Duplicates</a>
                    <a href="/force-refresh-events" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">🔄 Refresh</a>
                </div>
            </div>
            <h2>🟡 Similar Events (Same Name & Category):</h2>
            {''.join(similar_html) if similar_html else '<div style="text-align: center; padding: 50px; background: white; border-radius: 5px;"><h3>✅ Không có sự kiện tương tự!</h3></div>'}
        </div>
    </body>
    </html>
    '''

@app.route('/debug-edit-form/<event_id>')
def debug_edit_form(event_id):
    """Debug form sửa sự kiện để kiểm tra dữ liệu"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    if event_id not in event_manager.events:
        return f"❌ Sự kiện {event_id} không tồn tại!"
    
    event = event_manager.events[event_id]
    
    # Debug: Kiểm tra dữ liệu event
    print(f"DEBUG Edit Form Data:")
    print(f"  Event ID: {event_id}")
    print(f"  Event Name: {event.name}")
    print(f"  Event Category: {event.category}")
    print(f"  Event Description: {event.description}")
    print(f"  Event Date: {event.date}")
    print(f"  Event Time: {event.time}")
    print(f"  Event Location: {event.location}")
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Debug Edit Form</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 800px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .form-debug {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
            .data-comparison {{ background: #e8f4fd; padding: 15px; border-radius: 5px; margin: 10px 0; }}
            code {{ background: #f8f9fa; padding: 2px 4px; border-radius: 3px; font-family: monospace; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔍 Debug Edit Form</h1>
                <p><strong>Event ID:</strong> <code>{event_id}</code></p>
                <div style="margin-top: 15px;">
                    <a href="/edit-event/{event_id}" style="background: blue; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">✏️ Edit Form</a>
                    <a href="/events/{event_id}" style="background: green; color: white; padding: 10px; text-decoration: none; border-radius: 5px; margin-right: 10px;">👁️ View Event</a>
                    <a href="/debug-all-events" style="background: orange; color: white; padding: 10px; text-decoration: none; border-radius: 5px;">🔍 All Events</a>
                </div>
            </div>
            
            <div class="form-debug">
                <h3>📋 Event Data in Memory:</h3>
                <div class="data-comparison">
                    <p><strong>Name:</strong> {event.name}</p>
                    <p><strong>Category:</strong> {event.category}</p>
                    <p><strong>Description:</strong> {event.description}</p>
                    <p><strong>Date:</strong> {event.date}</p>
                    <p><strong>Time:</strong> {event.time}</p>
                    <p><strong>Location:</strong> {event.location}</p>
                    <p><strong>Max Capacity:</strong> {event.max_capacity}</p>
                    <p><strong>Organizer:</strong> {getattr(event, 'organizer_id', 'N/A')}</p>
                </div>
            </div>
            
            <div class="form-debug">
                <h3>🔧 Form Values (What should be displayed):</h3>
                <div class="data-comparison">
                    <p><strong>Input Name Value:</strong> <code>value="{event.name}"</code></p>
                    <p><strong>Select Category Value:</strong> <code>value="{event.category}"</code></p>
                    <p><strong>Textarea Description:</strong> <code>{event.description}</code></p>
                    <p><strong>Input Date Value:</strong> <code>value="{event.date}"</code></p>
                    <p><strong>Input Time Value:</strong> <code>value="{event.time}"</code></p>
                    <p><strong>Input Location Value:</strong> <code>value="{event.location}"</code></p>
                    <p><strong>Input Capacity Value:</strong> <code>value="{event.max_capacity}"</code></p>
                </div>
            </div>
            
            <div class="form-debug">
                <h3>🧪 Test Form Submission:</h3>
                <form method="POST" action="/edit-event/{event_id}" style="background: #f8f9fa; padding: 15px; border-radius: 5px;">
                    <div style="margin-bottom: 10px;">
                        <label><strong>Name:</strong></label><br>
                        <input type="text" name="name" value="{event.name}" style="width: 100%; padding: 5px;">
                    </div>
                    <div style="margin-bottom: 10px;">
                        <label><strong>Category:</strong></label><br>
                        <select name="category" style="width: 100%; padding: 5px;">
                            <option value="tech" {'selected' if event.category == 'tech' else ''}>Công nghệ</option>
                            <option value="sports" {'selected' if event.category == 'sports' else ''}>Thể thao</option>
                            <option value="academic" {'selected' if event.category == 'academic' else ''}>Học thuật</option>
                            <option value="social" {'selected' if event.category == 'social' else ''}>Xã hội</option>
                            <option value="general" {'selected' if event.category == 'general' else ''}>Khác</option>
                        </select>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <label><strong>Description:</strong></label><br>
                        <textarea name="description" rows="3" style="width: 100%; padding: 5px;">{event.description}</textarea>
                    </div>
                    <button type="submit" style="background: blue; color: white; padding: 10px 20px; border: none; border-radius: 5px;">Test Submit</button>
                </form>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/create-organizer')
def create_organizer():
    """Tạo organizer user để test"""
    try:
        # Tạo organizer user
        organizer_id = event_manager.register_user('organizer', 'Event Organizer', 'organizer@example.com', '0987654321')
        print(f"Organizer user created with ID: {organizer_id}")
        
        return f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Create Organizer</title>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
                .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
                .success {{ color: green; font-size: 24px; font-weight: bold; }}
                button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
                .btn {{ background: blue; color: white; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="success">✅ Organizer user created!</div>
                <h2>Organizer User Details</h2>
                <p><strong>ID:</strong> {organizer_id}</p>
                <p><strong>Name:</strong> Event Organizer</p>
                <p><strong>Email:</strong> organizer@example.com</p>
                <p><strong>Role:</strong> EnhancedEventOrganizer</p>
                <a href="/login" class="btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">🔑 Login as Organizer</a>
            </div>
        </body>
        </html>
        '''
    except Exception as e:
        return f"Error creating organizer: {str(e)}"

@app.route('/user-info')
def user_info():
    """Hiển thị thông tin user hiện tại"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    user = event_manager.current_user
    user_role = getattr(user, 'role', 'student')
    
    # Kiểm tra quyền
    can_view_dashboard = user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer']
    can_create_events = user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer']
    can_edit_events = user_role in ['Admin', 'EnhancedAdmin', 'EventOrganizer', 'EnhancedEventOrganizer']
    can_delete_events = user_role in ['Admin', 'EnhancedAdmin']  # Chỉ Admin mới được xóa tất cả sự kiện
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>User Info</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 800px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .permissions {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .permission {{ display: flex; justify-content: space-between; padding: 10px; margin: 5px 0; border-radius: 3px; }}
            .allowed {{ background: #d4edda; color: #155724; }}
            .denied {{ background: #f8d7da; color: #721c24; }}
            .btn {{ padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }}
            .btn-primary {{ background: blue; color: white; }}
            .btn-success {{ background: green; color: white; }}
            .btn-warning {{ background: orange; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>👤 User Information</h1>
                <p><strong>User ID:</strong> {user_id}</p>
                <p><strong>Name:</strong> {getattr(user, 'name', 'N/A')}</p>
                <p><strong>Email:</strong> {getattr(user, 'email', 'N/A')}</p>
                <p><strong>Role:</strong> <span style="background: #007bff; color: white; padding: 2px 8px; border-radius: 3px;">{user_role}</span></p>
            </div>
            
            <div class="permissions">
                <h3>🔐 Permissions</h3>
                <div class="permission {'allowed' if can_view_dashboard else 'denied'}">
                    <span>View Dashboard</span>
                    <span>{'✅ Allowed' if can_view_dashboard else '❌ Denied'}</span>
                </div>
                <div class="permission {'allowed' if can_create_events else 'denied'}">
                    <span>Create Events</span>
                    <span>{'✅ Allowed' if can_create_events else '❌ Denied'}</span>
                </div>
                <div class="permission {'allowed' if can_edit_events else 'denied'}">
                    <span>Edit Events</span>
                    <span>{'✅ Allowed' if can_edit_events else '❌ Denied'}</span>
                </div>
                <div class="permission {'allowed' if can_delete_events else 'denied'}">
                    <span>Delete Events</span>
                    <span>{'✅ Allowed' if can_delete_events else '❌ Denied'}</span>
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="/events" class="btn btn-primary">📋 View Events</a>
                {'<a href="/dashboard" class="btn btn-success">📊 Dashboard</a>' if can_view_dashboard else ''}
                {'<a href="/create-event" class="btn btn-warning">➕ Create Event</a>' if can_create_events else ''}
                <a href="/logout" class="btn" style="background: red; color: white;">🚪 Logout</a>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/role-permissions')
def role_permissions():
    """Hiển thị phân quyền theo role"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Role Permissions</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .role-card {{ background: white; padding: 20px; border-radius: 5px; margin: 10px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .student {{ border-left: 5px solid #28a745; }}
            .organizer {{ border-left: 5px solid #ffc107; }}
            .admin {{ border-left: 5px solid #dc3545; }}
            .permission {{ display: flex; justify-content: space-between; padding: 8px; margin: 5px 0; border-radius: 3px; }}
            .allowed {{ background: #d4edda; color: #155724; }}
            .denied {{ background: #f8d7da; color: #721c24; }}
            .btn {{ padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }}
            .btn-primary {{ background: blue; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔐 Role Permissions</h1>
                <p>Phân quyền chi tiết theo từng vai trò trong hệ thống</p>
                <a href="/user-info" class="btn btn-primary">👤 My Info</a>
            </div>
            
            <div class="role-card student">
                <h2>👨‍🎓 Student (EnhancedStudent)</h2>
                <p><strong>Mô tả:</strong> Sinh viên tham gia sự kiện</p>
                <div class="permission denied">
                    <span>View Dashboard</span>
                    <span>❌ Denied</span>
                </div>
                <div class="permission denied">
                    <span>Create Events</span>
                    <span>❌ Denied</span>
                </div>
                <div class="permission denied">
                    <span>Edit Events</span>
                    <span>❌ Denied</span>
                </div>
                <div class="permission denied">
                    <span>Delete Events</span>
                    <span>❌ Denied</span>
                </div>
                <div class="permission allowed">
                    <span>View Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Register for Events</span>
                    <span>✅ Allowed</span>
                </div>
            </div>
            
            <div class="role-card organizer">
                <h2>👨‍💼 Event Organizer (EnhancedEventOrganizer)</h2>
                <p><strong>Mô tả:</strong> Người tổ chức sự kiện</p>
                <div class="permission allowed">
                    <span>View Dashboard</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Create Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Edit Own Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission denied">
                    <span>Delete Events</span>
                    <span>❌ Denied (Admin only)</span>
                </div>
                <div class="permission allowed">
                    <span>View All Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Register for Events</span>
                    <span>✅ Allowed</span>
                </div>
            </div>
            
            <div class="role-card admin">
                <h2>👑 Admin (EnhancedAdmin)</h2>
                <p><strong>Mô tả:</strong> Quản trị viên hệ thống</p>
                <div class="permission allowed">
                    <span>View Dashboard</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Create Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Edit All Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Delete All Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>View All Events</span>
                    <span>✅ Allowed</span>
                </div>
                <div class="permission allowed">
                    <span>Manage Users</span>
                    <span>✅ Allowed</span>
                </div>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/debug-role')
def debug_role():
    """Debug role của user hiện tại"""
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    user = event_manager.current_user
    user_role = getattr(user, 'role', 'student')
    
    # Debug chi tiết
    print(f"DEBUG Role Information:")
    print(f"  User ID: {user_id}")
    print(f"  User Name: {getattr(user, 'name', 'N/A')}")
    print(f"  User Role: {user_role}")
    print(f"  User Role Type: {type(user_role)}")
    print(f"  User Object: {user}")
    print(f"  User Object Type: {type(user)}")
    
    # Kiểm tra các role có thể
    possible_roles = ['EnhancedStudent', 'EnhancedEventOrganizer', 'EnhancedAdmin']
    role_checks = {}
    for role in possible_roles:
        role_checks[role] = user_role == role
    
    # Kiểm tra quyền dashboard
    can_view_dashboard = user_role in ['EnhancedAdmin', 'EnhancedEventOrganizer']
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Debug Role</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }}
            .container {{ max-width: 800px; margin: 0 auto; }}
            .header {{ background: white; padding: 20px; border-radius: 5px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .debug-info {{ background: white; padding: 20px; border-radius: 5px; margin: 10px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }}
            .role-check {{ display: flex; justify-content: space-between; padding: 10px; margin: 5px 0; border-radius: 3px; }}
            .match {{ background: #d4edda; color: #155724; }}
            .no-match {{ background: #f8d7da; color: #721c24; }}
            .btn {{ padding: 10px 20px; margin: 5px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }}
            .btn-primary {{ background: blue; color: white; }}
            .btn-success {{ background: green; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔍 Debug Role Information</h1>
                <p>Kiểm tra role và quyền của user hiện tại</p>
            </div>
            
            <div class="debug-info">
                <h3>👤 User Information</h3>
                <p><strong>User ID:</strong> {user_id}</p>
                <p><strong>User Name:</strong> {getattr(user, 'name', 'N/A')}</p>
                <p><strong>User Role:</strong> <code>{user_role}</code></p>
                <p><strong>User Role Type:</strong> <code>{type(user_role)}</code></p>
                <p><strong>User Object Type:</strong> <code>{type(user)}</code></p>
            </div>
            
            <div class="debug-info">
                <h3>🔍 Role Checks</h3>
                <div class="role-check {'match' if role_checks['EnhancedStudent'] else 'no-match'}">
                    <span>EnhancedStudent</span>
                    <span>{'✅ Match' if role_checks['EnhancedStudent'] else '❌ No Match'}</span>
                </div>
                <div class="role-check {'match' if role_checks['EnhancedEventOrganizer'] else 'no-match'}">
                    <span>EnhancedEventOrganizer</span>
                    <span>{'✅ Match' if role_checks['EnhancedEventOrganizer'] else '❌ No Match'}</span>
                </div>
                <div class="role-check {'match' if role_checks['EnhancedAdmin'] else 'no-match'}">
                    <span>EnhancedAdmin</span>
                    <span>{'✅ Match' if role_checks['EnhancedAdmin'] else '❌ No Match'}</span>
                </div>
            </div>
            
            <div class="debug-info">
                <h3>🔐 Dashboard Permission</h3>
                <p><strong>Can View Dashboard:</strong> {'✅ Yes' if can_view_dashboard else '❌ No'}</p>
                <p><strong>Expected Roles:</strong> EnhancedAdmin, EnhancedEventOrganizer</p>
                <p><strong>Current Role:</strong> {user_role}</p>
            </div>
            
            <div style="text-align: center;">
                <a href="/dashboard" class="btn btn-primary">📊 Try Dashboard</a>
                <a href="/user-info" class="btn btn-success">👤 User Info</a>
                <a href="/role-permissions" class="btn" style="background: orange; color: white;">🔐 Role Permissions</a>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/simple-delete/<event_id>')
def simple_delete(event_id):
    """Xóa sự kiện đơn giản (không cần form)"""
    print(f"DEBUG: Simple delete called for event_id: {event_id}")
    
    if 'user_id' not in session:
        return "❌ Chưa đăng nhập!"
    
    user_id = session['user_id']
    print(f"DEBUG: User ID: {user_id}")
    
    if not event_manager.login(user_id):
        return "❌ Lỗi đăng nhập!"
    
    if event_id not in event_manager.events:
        return f"❌ Sự kiện {event_id} không tồn tại!"
    
    event = event_manager.events[event_id]
    current_user_role = getattr(event_manager.current_user, 'role', '')
    event_organizer = getattr(event, 'organizer_id', '')
    
    print(f"DEBUG: Role: {current_user_role}, Organizer: {event_organizer}")
    
    # Chỉ Admin mới được xóa sự kiện
    if current_user_role != 'EnhancedAdmin':
        return f"❌ Chỉ Admin mới có quyền xóa sự kiện! Role hiện tại: {current_user_role}"
    
    # Xóa sự kiện
    event_name = event.name
    del event_manager.events[event_id]
    event_manager.save_data()
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Xóa thành công</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; text-align: center; padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }}
            .container {{ background: white; color: black; padding: 30px; border-radius: 10px; max-width: 500px; margin: 0 auto; }}
            .success {{ color: green; font-size: 24px; font-weight: bold; }}
            button {{ padding: 10px 20px; margin: 10px; border: none; border-radius: 5px; cursor: pointer; }}
            .btn {{ background: blue; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="success">✅ Xóa sự kiện thành công!</div>
            <h2>🗑️ Đã xóa: {event_name}</h2>
            <p>Event ID: {event_id}</p>
            <a href="/events" class="btn" style="text-decoration: none; display: inline-block; padding: 10px 20px; background: blue; color: white; border-radius: 5px;">📋 Xem danh sách sự kiện</a>
        </div>
    </body>
    </html>
    '''

if __name__ == '__main__':
    # Tạo thư mục templates nếu chưa có
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static/css', exist_ok=True)
    os.makedirs('static/js', exist_ok=True)
    
    print("=== Khoi dong Campus Event Management System ===")
    print("Truy cap: http://localhost:3000")
    print("He thong quan ly su kien campus voi AI Assistant")
    
    app.run(host='0.0.0.0', port=3000, debug=True)
