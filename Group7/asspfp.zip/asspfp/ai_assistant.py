"""
Simple rule-based AI Assistant for the Campus Event Management System
No external dependencies. Works offline.
"""

from datetime import datetime
from typing import List, Dict
import unicodedata


class SimpleAIAssistant:
    """A tiny rule-based assistant that can:
    - Answer FAQs about the system
    - Recommend events based on keywords/date/category
    """

    def __init__(self, get_all_events_callable):
        # get_all_events_callable: () -> List[Event]
        self.get_all_events = get_all_events_callable

    @staticmethod
    def _normalize(text: str) -> str:
        if text is None:
            return ""
        # Lowercase + remove quotes + strip diacritics for robust matching
        t = str(text).strip().lower()
        t = t.replace('“', '').replace('”', '').replace('"', '').replace("'", "")
        # Strip Unicode diacritics
        t = unicodedata.normalize('NFD', t)
        t = ''.join(ch for ch in t if unicodedata.category(ch) != 'Mn')
        return t

    def answer(self, question: str) -> str:
        # Normalize input
        q = self._normalize(question)
        q = q.replace('dang ki', 'dang ky')  # normalize common variant (non-diacritic)
        if not q:
            return "Bạn hãy nhập câu hỏi về sự kiện hoặc gõ 'gợi ý' để được đề xuất."

        # Greetings
        if any(greeting in q for greeting in ["hello", "hi", "xin chao", "chao", "hey"]):
            return "Xin chào! Tôi là AI Assistant của hệ thống quản lý sự kiện. Tôi có thể giúp bạn:\n- Tìm sự kiện: 'workshop', 'tech', 'seminar'\n- Xem lịch: 'hôm nay', 'tuần này'\n- Hỏi đáp: 'cách đăng ký', 'tạo sự kiện'\n- Gợi ý: 'gợi ý workshop'"

        # FAQs
        if "dang ky" in q or "register" in q:
            return "Vào Student menu → Register for Event, chọn sự kiện và xác nhận."
        # List events when user asks chung chung "sự kiện"
        if "su kien" in q or "event" in q:
            return self._list_all()
        if "tạo sự kiện" in q or "create event" in q:
            return "Đăng nhập Admin/Organizer → Create Event và điền thông tin cần thiết."
        if "bao nhiêu chỗ" in q or "capacity" in q:
            # Try to find specific event mentioned in the question
            events = list(self.get_all_events())
            for event in events:
                event_name_normalized = self._normalize(event.name)
                if event_name_normalized in q:
                    return f"Sự kiện '{event.name}' có {len(event.attendees)}/{event.max_capacity} chỗ (còn {event.max_capacity - len(event.attendees)} chỗ trống)."
            return "Mỗi thẻ sự kiện hiển thị 'Capacity: hiện_tại/tối_đa' ngay trong danh sách."

        # Recommendations (keyword + capacity constraints)
        if "gợi ý" in q or "suggest" in q or "recommend" in q:
            # extract simple keyword after 'gợi ý' if present
            import re
            kw = None
            m = re.search(r"gợi ý\s+(.*)", q)
            if m:
                kw = m.group(1).strip()
            return self._recommend(keyword=kw)

        # Relative dates (today/this week/next week)
        if any(x in q for x in ["hôm nay", "today", "tuần này", "this week", "tuần sau", "next week"]):
            return self._filter_by_relative_date(q)
        # Absolute date
        if "ngày" in q or "date" in q:
            return self._filter_by_date(q)

        # Filter by category keywords
        for key in ["tech", "workshop", "academic", "sports", "social", "cultural", "seminar"]:
            if key in q:
                return self._filter_by_keyword(key)

        # If no specific pattern matches, try generic keyword search
        # But only if it looks like a search term (not a question)
        if len(q.split()) <= 3 and not any(word in q for word in ["cách", "how", "what", "where", "when", "why"]):
            return self._filter_by_keyword(q)
        
        # Default response for unrecognized questions
        return "Tôi có thể giúp bạn:\n- Tìm sự kiện: 'workshop', 'tech', 'seminar'\n- Xem lịch: 'hôm nay', 'tuần này'\n- Hỏi đáp: 'cách đăng ký', 'tạo sự kiện'\n- Gợi ý: 'gợi ý workshop'"

    def _recommend(self, keyword: str = None) -> str:
        events = list(self.get_all_events())
        if not events:
            return "Hiện chưa có sự kiện nào. Hãy tạo sự kiện trước."
        # Simple heuristic: future events sorted by soonest and with remaining seats
        future_events: List[Dict] = []
        for e in events:
            try:
                dt = datetime.strptime(f"{e.date} {e.time}", "%Y-%m-%d %H:%M")
            except Exception:
                try:
                    dt = datetime.strptime(e.date, "%Y-%m-%d")
                except Exception:
                    dt = datetime.max
            if len(e.attendees) < e.max_capacity:
                if keyword and keyword not in e.name.lower() and keyword not in e.description.lower():
                    continue
                future_events.append({"event": e, "dt": dt})
        future_events.sort(key=lambda x: x["dt"])
        top = future_events[:3] if future_events else []
        if not top:
            return "Các sự kiện hiện đã đầy. Hãy tạo thêm sự kiện mới."
        lines = ["Gợi ý sự kiện cho bạn:"]
        for i, item in enumerate(top, 1):
            e = item["event"]
            lines.append(f"{i}. {e.name} — {e.date} {e.time} tại {e.location}")
        return "\n".join(lines)

    def _filter_by_keyword(self, kw: str) -> str:
        kw = self._normalize(kw)
        events = list(self.get_all_events())
        def text(val: str) -> str:
            return self._normalize(val)
        matched = [
            e for e in events
            if kw in text(e.name)
            or kw in text(getattr(e, 'description', ''))
            or kw in text(getattr(e, 'category', ''))
            or kw in text(getattr(e, 'location', ''))
        ]
        if not matched:
            return "Không tìm thấy sự kiện phù hợp. Thử từ khóa khác (ví dụ: 'workshop', 'tech')."
        lines = ["Sự kiện phù hợp:"]
        for i, e in enumerate(matched[:5], 1):
            lines.append(f"{i}. {e.name} — {e.date} {e.time} tại {e.location}")
        return "\n".join(lines)

    def _list_all(self) -> str:
        events = list(self.get_all_events())
        if not events:
            return "Hiện chưa có sự kiện nào. Hãy tạo sự kiện trước."
        events.sort(key=lambda e: (e.date, e.time))
        lines = ["Danh sách sự kiện:"]
        for i, e in enumerate(events[:5], 1):
            lines.append(f"{i}. {e.name} — {e.date} {e.time} tại {e.location}")
        return "\n".join(lines)

    def _filter_by_date(self, q: str) -> str:
        # Extract YYYY-MM-DD if present
        import re
        m = re.search(r"(20\d{2}-\d{2}-\d{2})", q)
        if not m:
            return "Bạn hãy nhập ngày dạng YYYY-MM-DD, ví dụ: 'sự kiện ngày 2025-12-15'."
        day = m.group(1)
        events = list(self.get_all_events())
        matched = [e for e in events if e.date == day]
        if not matched:
            return f"Không có sự kiện vào ngày {day}."
        lines = [f"Sự kiện vào ngày {day}:"]
        for i, e in enumerate(matched, 1):
            lines.append(f"{i}. {e.name} — {e.time} tại {e.location}")
        return "\n".join(lines)

    def _filter_by_relative_date(self, q: str) -> str:
        from datetime import timedelta
        today = datetime.now().date()
        start = end = today
        label = "hôm nay"
        if "tuần này" in q or "this week" in q:
            start = today - timedelta(days=today.weekday())
            end = start + timedelta(days=6)
            label = "tuần này"
        elif "tuần sau" in q or "next week" in q:
            start = today - timedelta(days=today.weekday()) + timedelta(days=7)
            end = start + timedelta(days=6)
            label = "tuần sau"

        events = list(self.get_all_events())
        matched = []
        for e in events:
            try:
                d = datetime.strptime(e.date, "%Y-%m-%d").date()
            except Exception:
                continue
            if start <= d <= end:
                matched.append(e)

        if not matched:
            return f"Không có sự kiện trong {label}."
        matched.sort(key=lambda ev: (ev.date, ev.time))
        lines = [f"Sự kiện trong {label}:"]
        for i, e in enumerate(matched, 1):
            lines.append(f"{i}. {e.name} — {e.date} {e.time} tại {e.location}")
        return "\n".join(lines)


